# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_commentmeta`
#

DROP TABLE IF EXISTS `wpMTAL_commentmeta`;


#
# Table structure of table `wpMTAL_commentmeta`
#

CREATE TABLE `wpMTAL_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_commentmeta (0 records)
#

#
# End of data contents of table wpMTAL_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_comments`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_comments`
#

DROP TABLE IF EXISTS `wpMTAL_comments`;


#
# Table structure of table `wpMTAL_comments`
#

CREATE TABLE `wpMTAL_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_comments (1 records)
#
 
INSERT INTO `wpMTAL_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-08-10 15:17:52', '2014-08-10 15:17:52', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wpMTAL_comments
# --------------------------------------------------------

# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_events`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_eo_events`
#

DROP TABLE IF EXISTS `wpMTAL_eo_events`;


#
# Table structure of table `wpMTAL_eo_events`
#

CREATE TABLE `wpMTAL_eo_events` (
  `event_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `StartTime` time NOT NULL,
  `FinishTime` time NOT NULL,
  `event_occurrence` bigint(20) NOT NULL,
  PRIMARY KEY (`event_id`),
  KEY `StartDate` (`StartDate`),
  KEY `EndDate` (`EndDate`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_eo_events (4 records)
#
 
INSERT INTO `wpMTAL_eo_events` VALUES (1, 27, '2014-09-13', '2014-09-13', '10:00:00', '12:00:00', 0) ; 
INSERT INTO `wpMTAL_eo_events` VALUES (2, 28, '2014-10-01', '2014-10-01', '00:00:00', '00:00:00', 0) ; 
INSERT INTO `wpMTAL_eo_events` VALUES (3, 32, '2014-10-05', '2014-10-05', '10:30:00', '13:30:00', 0) ; 
INSERT INTO `wpMTAL_eo_events` VALUES (4, 33, '2014-11-15', '2014-11-15', '00:00:00', '00:00:00', 0) ;
#
# End of data contents of table wpMTAL_eo_events
# --------------------------------------------------------

# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_events`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_venuemeta`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_eo_venuemeta`
#

DROP TABLE IF EXISTS `wpMTAL_eo_venuemeta`;


#
# Table structure of table `wpMTAL_eo_venuemeta`
#

CREATE TABLE `wpMTAL_eo_venuemeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `eo_venue_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `eo_venue_id` (`eo_venue_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_eo_venuemeta (14 records)
#
 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (1, 2, '_lat', '0.000000') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (2, 2, '_lng', '0.000000') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (3, 3, '_address', '2 Convent Road') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (4, 3, '_city', 'Morristown') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (5, 3, '_state', 'NJ') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (6, 3, '_postcode', '07960') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (7, 3, '_country', 'USA') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (8, 3, '_lat', '40.779928') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (9, 3, '_lng', '-74.439952') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (10, 4, '_city', 'Jersey City') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (11, 4, '_state', 'NJ') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (12, 4, '_country', 'United States') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (13, 4, '_lat', '40.779350') ; 
INSERT INTO `wpMTAL_eo_venuemeta` VALUES (14, 4, '_lng', '-74.511172') ;
#
# End of data contents of table wpMTAL_eo_venuemeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_events`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_venuemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_links`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_links`
#

DROP TABLE IF EXISTS `wpMTAL_links`;


#
# Table structure of table `wpMTAL_links`
#

CREATE TABLE `wpMTAL_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_links (0 records)
#

#
# End of data contents of table wpMTAL_links
# --------------------------------------------------------

# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_events`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_venuemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_options`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_options`
#

DROP TABLE IF EXISTS `wpMTAL_options`;


#
# Table structure of table `wpMTAL_options`
#

CREATE TABLE `wpMTAL_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=289 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_options (147 records)
#
 
INSERT INTO `wpMTAL_options` VALUES (1, 'siteurl', 'http://localhost:8888/muthetaatlarge.org', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (2, 'blogname', 'Mu Theta At Large', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (3, 'blogdescription', 'Just another WordPress site', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (5, 'admin_email', 'sportzhulei@gmail.com', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (20, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (21, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (25, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (26, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (27, 'permalink_structure', '', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (28, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (29, 'hack_file', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (30, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (31, 'moderation_keys', '', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (32, 'active_plugins', 'a:5:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:37:"custom-content-type-manager/index.php";i:3;s:35:"event-organiser/event-organiser.php";i:4;s:55:"super-simple-contact-form/super-simple-contact-form.php";}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (33, 'home', 'http://localhost:8888/muthetaatlarge.org', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (40, 'recently_edited', '', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (41, 'template', 'mtal', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (42, 'stylesheet', 'mtal', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (49, 'db_version', '27916', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (52, 'blog_public', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (54, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (80, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (81, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (82, 'uninstall_plugins', 'a:1:{s:35:"event-organiser/event-organiser.php";s:24:"eventorganiser_uninstall";}', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (83, 'timezone_string', '', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (84, 'page_for_posts', '2', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (85, 'page_on_front', '4', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (88, 'initial_db_version', '27916', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (89, 'wpMTAL_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:70:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:11:"edit_events";b:1;s:14:"publish_events";b:1;s:13:"delete_events";b:1;s:18:"edit_others_events";b:1;s:20:"delete_others_events";b:1;s:19:"read_private_events";b:1;s:13:"manage_venues";b:1;s:23:"manage_event_categories";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (95, 'sidebars_widgets', 'a:7:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:11:"footer_left";a:0:{}s:13:"footer_middle";a:0:{}s:12:"footer_right";a:0:{}s:15:"upcoming_events";a:1:{i:0;s:22:"eo_event_list_widget-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (96, 'cron', 'a:7:{i:1408202275;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1408204147;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1408204180;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1408216020;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1408230000;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1408244400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (98, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.2.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.2.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-3.9.2-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-3.9.2-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.9.2";s:7:"version";s:5:"3.9.2";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1408191316;s:15:"version_checked";s:5:"3.9.2";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (103, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1408191316;s:7:"checked";a:4:{s:4:"mtal";s:9:"1.0-wpcom";s:14:"twentyfourteen";s:3:"1.1";s:14:"twentythirteen";s:3:"1.2";s:12:"twentytwelve";s:3:"1.4";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (104, '_site_transient_timeout_browser_e031bbc6802ffa5eb9cf57849f48e69b', '1408288684', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (105, '_site_transient_browser_e031bbc6802ffa5eb9cf57849f48e69b', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"36.0.1985.125";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (106, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (126, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1407685752;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (127, 'current_theme', 'Mu Theta At Large', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (128, 'theme_mods_mtal', 'a:1:{i:0;b:0;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (129, 'theme_switched', '', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (141, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (147, 'cctm_data', 'a:8:{s:5:"flash";a:0:{}s:5:"locks";a:0:{}s:14:"post_type_defs";a:2:{s:4:"news";a:39:{s:24:"cctm_hierarchical_custom";s:0:"";s:33:"cctm_hierarchical_includes_drafts";s:0:"";s:28:"cctm_hierarchical_post_types";a:0:{}s:27:"cctm_custom_columns_enabled";i:0;s:8:"supports";a:2:{i:0;s:5:"title";i:1;s:6:"editor";}s:10:"taxonomies";a:0:{}s:23:"original_post_type_name";s:0:"";s:9:"post_type";s:4:"news";s:6:"labels";a:11:{s:9:"menu_name";s:4:"News";s:13:"singular_name";s:4:"News";s:7:"add_new";s:7:"Add New";s:12:"add_new_item";s:12:"Add New News";s:9:"edit_item";s:9:"Edit News";s:8:"new_item";s:8:"New News";s:9:"view_item";s:9:"View News";s:12:"search_items";s:11:"Search News";s:9:"not_found";s:13:"No news found";s:18:"not_found_in_trash";s:22:"No news found in trash";s:17:"parent_item_colon";s:11:"Parent Page";}s:11:"description";s:0:"";s:21:"use_default_menu_icon";b:1;s:5:"label";s:4:"News";s:17:"cctm_show_in_menu";s:1:"1";s:24:"cctm_show_in_menu_custom";s:0:"";s:17:"show_in_admin_bar";b:1;s:13:"menu_position";N;s:18:"rewrite_with_front";b:1;s:16:"permalink_action";s:3:"Off";s:12:"rewrite_slug";s:0:"";s:9:"query_var";b:0;s:6:"public";b:1;s:7:"show_ui";b:1;s:17:"show_in_nav_menus";b:1;s:18:"publicly_queryable";b:1;s:17:"include_in_search";b:1;s:14:"include_in_rss";b:1;s:15:"capability_type";s:4:"post";s:12:"capabilities";s:0:"";s:20:"register_meta_box_cb";s:0:"";s:10:"can_export";b:1;s:21:"cctm_enable_right_now";s:1:"1";s:14:"custom_orderby";s:0:"";s:12:"custom_order";s:3:"ASC";s:12:"hierarchical";b:0;s:12:"map_meta_cap";b:0;s:11:"has_archive";b:0;s:12:"show_in_menu";s:0:"";s:7:"rewrite";b:0;s:9:"is_active";i:1;}s:6:"events";a:39:{s:24:"cctm_hierarchical_custom";s:0:"";s:33:"cctm_hierarchical_includes_drafts";s:0:"";s:28:"cctm_hierarchical_post_types";a:0:{}s:27:"cctm_custom_columns_enabled";i:0;s:8:"supports";a:2:{i:0;s:5:"title";i:1;s:6:"editor";}s:10:"taxonomies";a:0:{}s:23:"original_post_type_name";s:0:"";s:9:"post_type";s:6:"events";s:6:"labels";a:11:{s:9:"menu_name";s:6:"Events";s:13:"singular_name";s:6:"Events";s:7:"add_new";s:7:"Add New";s:12:"add_new_item";s:14:"Add New Events";s:9:"edit_item";s:11:"Edit Events";s:8:"new_item";s:10:"New Events";s:9:"view_item";s:11:"View Events";s:12:"search_items";s:13:"Search Events";s:9:"not_found";s:15:"No events found";s:18:"not_found_in_trash";s:24:"No events found in trash";s:17:"parent_item_colon";s:11:"Parent Page";}s:11:"description";s:0:"";s:21:"use_default_menu_icon";b:1;s:5:"label";s:6:"Events";s:17:"cctm_show_in_menu";s:1:"1";s:24:"cctm_show_in_menu_custom";s:0:"";s:17:"show_in_admin_bar";b:1;s:13:"menu_position";N;s:18:"rewrite_with_front";b:1;s:16:"permalink_action";s:3:"Off";s:12:"rewrite_slug";s:0:"";s:9:"query_var";b:0;s:6:"public";b:1;s:7:"show_ui";b:1;s:17:"show_in_nav_menus";b:1;s:18:"publicly_queryable";b:1;s:17:"include_in_search";b:1;s:14:"include_in_rss";b:1;s:15:"capability_type";s:4:"post";s:12:"capabilities";s:0:"";s:20:"register_meta_box_cb";s:0:"";s:10:"can_export";b:1;s:21:"cctm_enable_right_now";s:1:"1";s:14:"custom_orderby";s:0:"";s:12:"custom_order";s:3:"ASC";s:12:"hierarchical";b:0;s:12:"map_meta_cap";b:0;s:11:"has_archive";b:0;s:12:"show_in_menu";s:0:"";s:7:"rewrite";b:0;s:9:"is_active";i:1;}}s:17:"custom_field_defs";a:0:{}s:27:"cctm_installation_timestamp";i:1407713213;s:11:"export_info";a:5:{s:5:"title";s:9:"CCTM Site";s:6:"author";s:21:"sportzhulei@gmail.com";s:3:"url";s:40:"http://localhost:8888/muthetaatlarge.org";s:12:"template_url";s:0:"";s:11:"description";s:67:"This site was created in part using the Custom Content Type Manager";}s:21:"cctm_update_timestamp";i:1407713213;s:12:"cctm_version";s:11:"0.9.7.13-pl";}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (149, 'acf_version', '4.3.8', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (157, 'eventorganiser_options', 'a:17:{s:8:"supports";a:8:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:6:"author";i:3;s:9:"thumbnail";i:4;s:7:"excerpt";i:5;s:13:"custom-fields";i:6;s:8:"comments";i:7;s:8:"eventtag";}s:14:"event_redirect";s:6:"events";s:10:"dateformat";s:5:"dd-mm";s:9:"prettyurl";i:1;s:9:"templates";i:1;s:9:"addtomenu";i:0;s:17:"excludefromsearch";i:0;s:8:"showpast";i:0;s:12:"group_events";s:0:"";s:9:"url_venue";s:13:"events/venues";s:7:"url_cat";s:15:"events/category";s:7:"url_tag";s:10:"events/tag";s:8:"navtitle";s:6:"Events";s:8:"eventtag";i:1;s:4:"feed";i:1;s:16:"runningisnotpast";i:0;s:13:"deleteexpired";i:0;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (158, 'eventorganiser_admin_notices', 'a:2:{i:0;s:15:"autofillvenue17";i:1;s:17:"changedtemplate17";}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (159, 'eventorganiser_version', '2.8.3', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (177, 'widget_eo_events_agenda_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (178, 'widget_eo_event_list_widget', 'a:2:{i:2;a:10:{s:5:"title";s:0:"";s:11:"numberposts";i:10;s:14:"event-category";s:0:"";s:5:"venue";s:0:"";s:5:"order";s:3:"asc";s:7:"orderby";s:10:"eventstart";s:14:"showpastevents";i:0;s:15:"group_events_by";s:0:"";s:8:"template";s:0:"";s:9:"no_events";s:9:"No Events";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (181, '_transient_eo_is_multi_event_organiser', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (226, '_transient_is_multi_author', '0', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (254, '_site_transient_timeout_theme_roots', '1408193018', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (255, '_site_transient_theme_roots', 'a:4:{s:4:"mtal";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (259, '_site_transient_timeout_browser_49d5d8dd1140256727a340c38a742f7f', '1408796071', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (260, '_site_transient_browser_49d5d8dd1140256727a340c38a742f7f', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"36.0.1985.143";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (261, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1408234472', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (262, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 05:06:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/?v=4.0-beta4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/08/wordpress-4-0-beta-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/08/wordpress-4-0-beta-4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 05:06:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3280";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:353:"The fourth and likely final beta for WordPress 4.0 is now available. We&#8217;ve made more than 250 changes in the past month, including: Further improvements to the editor scrolling experience, especially when it comes to the second column of boxes. Better handling of small screens in the media library modals. A separate bulk selection mode [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1999:"<p>The fourth and likely final beta for WordPress 4.0 is now available. We&#8217;ve made <a href="https://core.trac.wordpress.org/log?rev=29496&amp;stop_rev=29229&amp;limit=300">more than 250 changes</a> in the past month, including:</p>
<ul>
<li>Further improvements to the editor scrolling experience, especially when it comes to the second column of boxes.</li>
<li>Better handling of small screens in the media library modals.</li>
<li>A separate bulk selection mode for the media library grid view.</li>
<li>Improvements to the installation language selector.</li>
<li>Visual tweaks to plugin details and customizer panels.</li>
</ul>
<p><strong>We need your help</strong>. We’re still aiming for a release this month, which means the next week will be critical for identifying and squashing bugs. If you’re just joining us, please see <a href="http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven’t tested WordPress 4.0 yet, now is the time — and be sure to update the “tested up to” version for your plugins so they’re listed as compatible with 4.0.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-4.0-beta4.zip">download the beta here</a> (zip).</p>
<p><em>We are working hard</em><br />
<em>To finish up 4.0<br />
</em><em>Will you help us too?</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/08/wordpress-4-0-beta-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.9.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/08/wordpress-3-9-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/08/wordpress-3-9-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Aug 2014 19:04:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3269";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:377:"WordPress 3.9.2 is now available as a security release for all previous versions. We strongly encourage you to update your sites immediately. This release fixes a possible denial of service issue in PHP&#8217;s XML processing, reported by Nir Goldshlager of the Salesforce.com Product Security Team. It  was fixed by Michael Adams and Andrew Nacin of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2352:"<p>WordPress 3.9.2 is now available as a security release for all previous versions. We strongly encourage you to update your sites immediately.</p>
<p>This release fixes a possible denial of service issue in PHP&#8217;s XML processing, reported by <a href="https://twitter.com/nirgoldshlager">Nir Goldshlager</a> of the Salesforce.com Product Security Team. It  was fixed by Michael Adams and Andrew Nacin of the WordPress security team and David Rothstein of the <a href="https://www.drupal.org/SA-CORE-2014-004">Drupal security team</a>. This is the first time our two projects have coordinated joint security releases.</p>
<p>WordPress 3.9.2 also contains other security changes:</p>
<ul>
<li>Fixes a possible but unlikely code execution when processing widgets (WordPress is not affected by default), discovered by <a href="http://www.buayacorp.com/">Alex Concha</a> of the WordPress security team.</li>
<li>Prevents information disclosure via XML entity attacks in the external GetID3 library, reported by <a href="http://onsec.ru/en/">Ivan Novikov</a> of ONSec.</li>
<li>Adds protections against brute attacks against CSRF tokens, reported by <a href="http://systemoverlord.com/">David Tomaschik</a> of the Google Security Team.</li>
<li>Contains some additional security hardening, like preventing cross-site scripting that could be triggered only by administrators.</li>
</ul>
<p>We appreciated responsible disclosure of these issues directly to our security team. For more information, see the <a href="http://codex.wordpress.org/Version_3.9.2">release notes</a> or consult the <a href="https://core.trac.wordpress.org/log/branches/3.9?stop_rev=29383&amp;rev=29411">list of changes</a>.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 3.9.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now&#8221;.</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.9.2 within 12 hours. (If you are still on WordPress 3.8.3 or 3.7.3, you will also be updated to 3.8.4 or 3.7.4. We don&#8217;t support older versions, so please update to 3.9.2 for the latest and greatest.)</p>
<p>Already testing WordPress 4.0? The third beta is <a href="https://wordpress.org/wordpress-4.0-beta3.zip">now available</a> (zip) and it contains these security fixes.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/08/wordpress-3-9-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Jul 2014 21:15:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3261";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:374:"WordPress 4.0 Beta 2 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. To get the beta, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can download the beta here (zip). For more of what’s new in version 4.0, check out [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1738:"<p>WordPress 4.0 Beta 2 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. To get the beta, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-4.0-beta2.zip">download the beta here</a> (zip).</p>
<p>For more of what’s new in version 4.0, <a href="http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">check out the Beta 1 blog post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Further refinements for the the plugin installation and media library experiences.</li>
<li>Updated TinyMCE, which now includes better indentation for lists and the restoration of the color picker.</li>
<li>Cookies are now tied to a session internally, so if you have trouble logging in, <a href="https://core.trac.wordpress.org/ticket/20276">#20276</a> may be the culprit.</li>
<li>Various bug fixes (there were <a href="https://core.trac.wordpress.org/log?rev=29228&amp;stop_rev=29060&amp;limit=200">nearly 170 changes</a> since last week).</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.0">everything we’ve fixed</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.0 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Jul 2014 10:17:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3248";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"WordPress 4.0 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4025:"<p>WordPress 4.0 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-beta1.zip">download the beta here</a> (zip).</p>
<p>4.0 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Previews of <a href="http://codex.wordpress.org/Embeds">embedding via URLs</a></strong> in the visual editor and the &#8220;Insert from URL&#8221; tab in the media modal. Try pasting a URL (such as a <a href="http://wordpress.tv/">WordPress.tv</a> or YouTube video) onto its own line in the visual editor. (<a href="https://core.trac.wordpress.org/ticket/28195">#28195</a>, <a href="https://core.trac.wordpress.org/ticket/15490">#15490</a>)</li>
<li>The <strong>Media Library</strong> now has a &#8220;grid&#8221; view in addition to the existing list view. Clicking on an item takes you into a modal where you can see a larger preview and edit information about that attachment, and you can navigate between items right from the modal without closing it. (<a href="https://core.trac.wordpress.org/ticket/24716">#24716</a>)</li>
<li>We&#8217;re freshening up the <strong>plugin install experience</strong>. You&#8217;ll see some early visual changes as well as more information when searching for plugins and viewing details. (<a href="https://core.trac.wordpress.org/ticket/28785">#28785</a>, <a href="https://core.trac.wordpress.org/ticket/27440">#27440</a>)</li>
<li><strong>Selecting a language</strong> when you run the installation process. (<a href="https://core.trac.wordpress.org/ticket/28577">#28577</a>)</li>
<li>The <strong>editor</strong> intelligently resizes and its top and bottom bars pin when needed. Browsers don&#8217;t like to agree on where to put things like cursors, so if you find a bug here, please also let us know your browser and operating system. (<a href="https://core.trac.wordpress.org/ticket/28328">#28328</a>)</li>
<li>We&#8217;ve made some improvements to how your keyboard and cursor interact with <strong>TinyMCE views</strong> such as the gallery preview. Much like the editor resizing and scrolling improvements, knowing about your setup is particularly important for bug reports here. (<a href="https://core.trac.wordpress.org/ticket/28595">#28595</a>)</li>
<li><strong>Widgets in the Customizer</strong> are now loaded in a separate panel. (<a href="https://core.trac.wordpress.org/ticket/27406">#27406</a>)</li>
<li>We&#8217;ve also made some changes to some <strong>formatting</strong> functions, so if you see quotes curling in the wrong direction, please file a bug report.</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.0">everything we’ve fixed</a> so far.</p>
<p><strong>Developers:</strong> Never fear, we haven&#8217;t forgotten you. There&#8217;s plenty for you, too &#8211; more on that in upcoming posts. In the meantime, check out the <a href="http://make.wordpress.org/core/2014/07/08/customizer-improvements-in-4-0/#customizer-panels">API for panels in the Customizer</a>.</p>
<p>Happy testing!</p>
<p><em>Plugins, editor</em><br />
<em>Media, things in between</em><br />
<em>Please help look for bugs</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.9.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/05/wordpress-3-9-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/05/wordpress-3-9-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3241";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:385:"After three weeks and more than 9 million downloads of WordPress 3.9, we&#8217;re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3077:"<p>After three weeks and more than 9 million downloads of <a title="WordPress 3.9 “Smith”" href="http://wordpress.org/news/2014/04/smith/">WordPress 3.9</a>, we&#8217;re pleased to announce that WordPress 3.9.1 is now available.</p>
<p>This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video playlists feature and made some adjustments to improve performance. For a full list of changes, consult the <a href="https://core.trac.wordpress.org/query?milestone=3.9.1">list of tickets</a> and the <a href="https://core.trac.wordpress.org/log/branches/3.9?rev=28353&amp;stop_rev=28154">changelog</a>.</p>
<p>If you are one of the millions already running WordPress 3.9, we&#8217;ve started rolling out automatic background updates for 3.9.1. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.9.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.9.1: <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/imath">imath</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="http://profiles.wordpress.org/clorith">Marius Jensen</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinić</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, and <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/05/wordpress-3-9-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2014/04/smith/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:411:"Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23297:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>
<embed src="//v0.wordpress.com/player.swf?v=1.03" type="application/x-shockwave-flash" width="640" height="360" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true" flashvars="guid=sAiXhCfV&amp;isDynamicSeeking=true" title=""></embed>
<h2 class="about-headline-callout" style="text-align: center">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="//wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3170" src="//wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3187" src="//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="//wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2 style="text-align: center">Do more with audio and video</h2>

<a href=\'http://wordpress.org/news/files/2014/04/AintMisbehavin.mp3\'>Ain\'t Misbehavin\'</a>
<a href=\'http://wordpress.org/news/files/2014/04/DavenportBlues.mp3\'>Davenport Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3\'>Buddy Bolden\'s Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3\'>Squaty Roo</a>
<a href=\'http://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3\'>Dixie Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/WolverineBlues.mp3\'>Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2 style="text-align: center">Live widget and header previews</h2>
<div style="width: 692px; height: 448px; " class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3154-1" width="692" height="448" preload="metadata" controls="controls"><source type="video/mp4" src="//wordpress.org/news/files/2014/04/widgets.mp4?_=1" /><a href="//wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></video></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2 style="text-align: center">Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="//wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2 style="text-align: center">The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="http://profiles.wordpress.org/adelval">adelval</a>, <a href="http://profiles.wordpress.org/ajay">Ajay</a>, <a href="http://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="http://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="http://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bramd">bramd</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="http://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="http://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="http://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="http://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/ciantic">ciantic</a>, <a href="http://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="http://profiles.wordpress.org/dpe415">DaveE</a>, <a href="http://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="http://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="http://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="http://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="http://profiles.wordpress.org/plocha">edik</a>, <a href="http://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="http://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/genkisan">genkisan</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="http://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky (@tivnet)</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="http://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="http://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jaycc">JayCC</a>, <a href="http://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jesin">Jesin A</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="http://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="http://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kerikae">kerikae</a>, <a href="http://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/klihelp">klihelp</a>, <a href="http://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lpointet">lpointet</a>, <a href="http://profiles.wordpress.org/ldebrouwer">Luc De Brouwer</a>, <a href="http://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="http://profiles.wordpress.org/lkwdwrd">Luke Woodward</a>, <a href="http://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/marventus">Marventus</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="http://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/meloniq">meloniq</a>, <a href="http://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nivijah">Nivi Jah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="http://profiles.wordpress.org/olivm">olivM</a>, <a href="http://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/oso96_2000">oso96_2000</a>, <a href="http://profiles.wordpress.org/patricknami">patricknami</a>, <a href="http://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="http://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="http://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="http://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="http://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/richard2222">richard2222</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/robmiller">robmiller</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="http://profiles.wordpress.org/roothorick">roothorick</a>, <a href="http://profiles.wordpress.org/ruudjoyo">Ruud Laan</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="http://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="http://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/sdasse">sdasse</a>, <a href="http://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="http://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="http://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="http://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tbrams">tbrams</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="http://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="http://profiles.wordpress.org/topquarky">topquarky</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/toru">Toru</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="http://profiles.wordpress.org/wawco">wawco</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="http://profiles.wordpress.org/xsonic">xsonic</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="http://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="http://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="http://make.wordpress.org/">Make WordPress</a> and our <a href="http://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2014/04/smith/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.9 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 09:47:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3151";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:356:"The second release candidate for WordPress 3.9 is now available for testing. If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the first release candidate, and those changes are all helpfully summarized in our weekly post on the development blog. Probably the biggest fixes are to live [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2273:"<p>The second release candidate for WordPress 3.9 is now available for testing.</p>
<p>If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the <a title="WordPress 3.9 Release Candidate" href="//wordpress.org/news/2014/04/wordpress-3-9-release-candidate/">first release candidate</a>, and those changes are all helpfully summarized <a href="//make.wordpress.org/core/?p=10237">in our weekly post</a> on the development blog. Probably the biggest fixes are to live widget previews and the new theme browser, along with some extra TinyMCE compatibility and some RTL fixes.</p>
<p><strong>Plugin authors:</strong> Could you test your plugins against 3.9, and if they&#8217;re compatible, make sure they are marked as tested up to 3.9? It only takes a few minutes and this really helps make launch easier. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example: <a href="//make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5</a>, <a href="//make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">symlinks</a>, <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL</a>, <a href="//make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload</a>.)</p>
<p>To test WordPress 3.9 RC2, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC2.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the nearly complete About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><em>This is for testing,</em><br />
<em>so not recommended for<br />
production sites—yet.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.3 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 19:29:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3145";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"WordPress 3.8.3 is now available to fix a small but unfortunate bug in the WordPress 3.8.2 security release. The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2339:"<p>WordPress 3.8.3 is now available to fix a small but unfortunate bug in the <a title="WordPress 3.8.2 Security Release" href="http://wordpress.org/news/2014/04/wordpress-3-8-2/">WordPress 3.8.2 security release</a>.</p>
<p>The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using this tool, <em>any</em> loss of content is unacceptable to us.</p>
<p>We recognize how much trust you place in us to safeguard your content, and we take this responsibility very seriously. We&#8217;re sorry we let you down.</p>
<p>We&#8217;ve all lost words we&#8217;ve written before, like an email thanks to a cat on the keyboard or a term paper to a blue screen of death. Over the last few WordPress releases, we&#8217;ve made a number of improvements to features like autosaves and revisions. With revisions, an old edit can always be restored. We&#8217;re trying our hardest to save your content somewhere even if your power goes out or your browser crashes. We even monitor your internet connection and prevent you from hitting that &#8220;Publish&#8221; button at the exact moment the coffee shop Wi-Fi has a hiccup.</p>
<p>It&#8217;s <em>possible</em> that the quick draft you lost last week is still in the database, and just hidden from view. As an added complication, these &#8220;discarded drafts&#8221; normally get deleted after seven days, and it&#8217;s already been six days since the release. If we were able to rescue your draft, you&#8217;ll see it on the &#8220;All Posts&#8221; screen after you update to 3.8.3. (We&#8217;ll also be pushing 3.8.3 out as a background update, so you may just see a draft appear.)</p>
<p>So, if you tried to jot down a quick idea last week, I hope WordPress has recovered it for you. Maybe it&#8217;ll turn into that novella.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.3</a> or click &#8220;Update Now&#8221; on Dashboard → Updates.</p>
<p><em>This affected version 3.7.2 as well, so we&#8217;re pushing a 3.7.3 to these installs, but we&#8217;d encourage you to update to the latest and greatest.</em></p>
<hr />
<p><em>Now for some good news:<br />
WordPress 3.9 is near.<br />
Expect it this week</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.9 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 21:05:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3129";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"As teased earlier, the first release candidate for WordPress 3.9 is now available for testing! We hope to ship WordPress 3.9 next week, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.) To test WordPress 3.9 [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2967:"<p><a href="//wordpress.org/news/2014/04/wordpress-3-8-2/">As teased earlier</a>, the first release candidate for WordPress 3.9 is now available for testing!</p>
<p>We hope to ship WordPress 3.9 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>To test WordPress 3.9 RC1, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the work-in-progress About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="//wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="//core.trac.wordpress.org/report/5">find them here</a>.</p>
<p><strong>If you&#8217;re a plugin author</strong>, there are two important changes in particular to be aware of:</p>
<ul>
<li>TinyMCE received a major update, to version 4.0. Any editor plugins written for TinyMCE 3.x might require some updates. (If things broke, we&#8217;d like to hear about them so we can make adjustments.) For more, see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">migration guide</a> and <a href="http://www.tinymce.com/wiki.php/api4:index">API documentation</a>, and the notes on the <a href="//make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/">core development blog</a>.</li>
<li>WordPress 3.9 now uses the MySQLi Improved extension for sites running PHP 5.5. Any plugins that made direct calls to <code>mysql_*</code> functions will experience some problems on these sites. For more information, see the notes on the <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">core development blog</a>.</li>
</ul>
<p>Be sure to follow along the core development blog, where we will be continuing to post <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example, read <a href="//make.wordpress.org/core/2014/03/27/masonry-in-wordpress-3-9/">this</a> if you are using Masonry in your theme.) And please, please update your plugin&#8217;s <em>Tested up to</em> version in the readme to 3.9 before April 16.</p>
<p><em>Release candidate<br />
This haiku&#8217;s the easy one<br />
3.9 is near</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.8.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 19:04:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3124";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:355:"WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately. This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by Jon Cave of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2272:"<p>WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by <a href="http://joncave.co.uk/">Jon Cave</a> of the WordPress security team.</p>
<p>It also contains a fix to prevent a user with the Contributor role from improperly publishing posts. Reported by <a href="http://edik.ch/">edik</a>.</p>
<p>This release also fixes nine bugs and contains three other security hardening changes:</p>
<ul>
<li>Pass along additional information when processing pingbacks to help hosts identify potentially abusive requests.</li>
<li>Fix a low-impact SQL injection by trusted users. Reported by <a href="http://www.dxw.com/">Tom Adams</a> of dxw.</li>
<li>Prevent possible cross-domain scripting through Plupload, the third-party library WordPress uses for uploading files. Reported by <a href="http://szgru.website.pl/">Szymon Gruszecki</a>.</li>
</ul>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these security issues directly to our security team. For more information on all of the changes, see the <a href="http://codex.wordpress.org/Version_3.8.2">release notes</a> or consult <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=28057&amp;stop_rev=27024">the list of changes</a>.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.8.2 within 12 hours. If you are still on WordPress 3.7.1, you will be updated to 3.7.2, which contains the same security fixes as 3.8.2. We don&#8217;t support older versions, so please update to 3.8.2 for the latest and greatest.</p>
<p>Already testing WordPress 3.9? The first release candidate is <a href="https://wordpress.org/wordpress-3.9-RC1.zip">now available</a> (zip) and it contains these security fixes. Look for a full announcement later today; we expect to release 3.9 next week.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 16 Aug 2014 12:14:32 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Fri, 15 Aug 2014 05:06:19 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20130911080210";}', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (263, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1408234472', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (264, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1408191272', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (265, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1408234473', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (266, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WPTavern: Time To Move On From The “Is WordPress A CMS” Debate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28493";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:164:"http://wptavern.com/time-to-move-on-from-the-is-wordpress-a-cms-debate?utm_source=rss&utm_medium=rss&utm_campaign=time-to-move-on-from-the-is-wordpress-a-cms-debate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3023:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/WordPressIsaCMSDebateFeaturedImage.png" rel="prettyphoto[28493]"><img class="size-full wp-image-28526" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/WordPressIsaCMSDebateFeaturedImage.png?resize=639%2C270" alt="WordPress Is A CMS Featured Image" /></a>photo credit: <a href="https://www.flickr.com/photos/cesarmaia/5029920602/">Cesar Maia</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a>
<p>In the realm of WordPress, there is a <a title="http://lists.automattic.com/pipermail/wp-hackers/2008-February/017888.html" href="http://lists.automattic.com/pipermail/wp-hackers/2008-February/017888.html">particular debate that has been going on for years</a> on whether WordPress is a CMS or not. CMSCritic has a great article by Kaya Ismail, that explains why <a title="http://www.cmscritic.com/wordpress-is-a-cms-whether-you-like-it-or-not/" href="http://www.cmscritic.com/wordpress-is-a-cms-whether-you-like-it-or-not/">WordPress is a CMS (Whether You Like it or Not)</a>. It&#8217;s one of the most refreshing perspectives I&#8217;ve read on the subject. The definition of a Content Management System is <em>a web application designed to make it easy for non-technical users to add, edit and manage a website</em>. WordPress fits that definition rather well and in many respects, excels at it. The problem as Ismail explains, is that the acronym has become muddied over the years.</p>
<blockquote><p>The issue arises when the stripped down, true meaning of &#8220;CMS&#8221; is blown up with unnecessary jargon. In reality, those definitions hold very little weight, other than when they describe added marketing or administrative extras. The fact of the matter is, WordPress fits the definition of a CMS perfectly.</p></blockquote>
<p>WordPress has grown up to be far more than just a blogging tool. It&#8217;s used to power apps, run large content heavy websites, and e-commerce. The reputation that it&#8217;s just a blogging tool and not a CMS is false.</p>
<p>If you&#8217;re curious on how to use WordPress as a CMS, <a title="http://planetozh.com/blog/2009/09/the-definitive-guide-to-using-wordpress-as-a-cms/" href="http://planetozh.com/blog/2009/09/the-definitive-guide-to-using-wordpress-as-a-cms/">read this guide</a> published by Ozh Richards that contains a simple four step process. It&#8217;s a process nearly all WordPress users go through everyday.</p>
<blockquote><p>It isn&#8217;t particularly amazing in any niche other than blogging, and it sacrifices being a powerhouse when it comes to things like <a href="http://www.cmscritic.com/dir/dam/">digital asset management</a> for the sake of simplicity. Yet at the same time, WordPress <strong> is </strong> a content management system, and a good one at that.</p>
<p><strong>So, maybe it&#8217;s time everybody got over it</strong>.</p></blockquote>
<p>Ismail sums it up rather well. I think it&#8217;s time to kick this debate to the curb.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 20:38:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WPTavern: Under the Hood of Semplice: A New Portfolio System Based on WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=27810";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:200:"http://wptavern.com/under-the-hood-of-semplice-a-new-portfolio-system-based-on-wordpress?utm_source=rss&utm_medium=rss&utm_campaign=under-the-hood-of-semplice-a-new-portfolio-system-based-on-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7120:"<p><a href="http://www.semplicelabs.com/" target="_blank">Semplice</a> has soft-launched its new WordPress-powered portfolio system. The commercial project popped up on our radar after debuting its extraordinary implementation of the WordPress content editor. Founded by German designers <a href="http://www.style-force.net/" target="_blank">Michael Schmidt</a> and <a href="http://www.vanschneider.com/" target="_blank">Tobias van Schneider</a>, Semplice is breaking onto the scene with high impact designs and its own radically simplified content editor.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/semplice.png" rel="prettyphoto[27810]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/semplice.png?resize=1025%2C749" alt="semplice" class="aligncenter size-full wp-image-28495" /></a></p>
<p>&#8220;Semplice is and was built based on our own needs to create beautiful case studies and branded pages, mainly for designer and artist portfolios,&#8221; Van Schneider told the Tavern. &#8220;Our goal is to create a completely new high quality experience on top of WordPress, something you haven’t seen before,&#8221; he said. So far they appear to be achieving exactly that. <a href="http://www.verenamichelitsch.com/" target="_blank">Example</a> <a href="http://ph7labs.com/" target="_blank">portfolios</a> <a href="http://dannyjongerius.nl/" target="_blank">built</a> with Semplice are nothing less than stunning.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/semplice_adam.jpg" rel="prettyphoto[27810]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/semplice_adam.jpg?resize=1025%2C641" alt="semplice_adam" class="aligncenter size-full wp-image-28502" /></a></p>
<h3>A Unique Content Editor</h3>
<p>Semplice incorporates its own visual content editor which allows users to create unique branded pages or extensive case studies for their projects, without a single line of code. &#8220;We aim to create a flexible system, not a template,&#8221; Van Schneider said. &#8220;With Semplice you start mostly with a white canvas, not a template or theme where you just fill in the blanks.&#8221; Every project is 100% responsive and the content editor is completely tailored to creating a portfolio.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/semplice-content-editor.png" rel="prettyphoto[27810]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/semplice-content-editor.png?resize=720%2C618" alt="semplice-content-editor" class="aligncenter size-full wp-image-27813" /></a></p>
<h2>So what&#8217;s under the hood?</h2>
<p>As beautiful as the front-end results are, we were most curious about what&#8217;s under the hood and assumed it was based on custom post types. On the contrary, the Semplice crew has taken a different route to create this unique editing experience.</p>
<p>&#8220;For the basic theme options we use <a href="http://www.advancedcustomfields.com/" target="_blank">Advanced Custom Fields</a> from <a href="https://twitter.com/elliotcondon" target="_blank">Elliot Condon</a>,&#8221; Van Schneider said. &#8220;The Content Editor itself is a combination of a Javascript frontend that uses the WordPress Ajax functions to communicate with the PHP backend.</p>
<p>&#8220;As we worked on different Semplice iterations we quickly learned that we need something more than just Custom Post Types, especially since the performance suffered a lot in the beginning,&#8221; he explained. The Semplice content editor is optional and can be activated when creating new pages in WordPress. It includes a live preview as you edit on the frontend, as you can see in the video example below.</p>
<p></p>
<p>&#8220;What you build is exactly what you get,&#8221; he said. &#8220;This allows you to create very flexible editorial layouts for designers or artists who want to present their work in the best light possible.&#8221;</p>
<p>Semplice also allows users the ability to brand every page with a unique visual look. Instead of having pages follow a set template, elements such as background color, navigation, and typography can be customized for each.</p>
<p>The regular WordPress admin is still in play, for example, when a user adds new work. It starts off in the backend with branding and image options.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/add-new-work.png" rel="prettyphoto[27810]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/add-new-work.png?resize=1025%2C740" alt="add-new-work" class="aligncenter size-full wp-image-28517" /></a></p>
<p>One unique feature of Semplice is the ability to easily add a new custom fontset to WordPress using the web service of your choice. This is especially important for designers who require unique fonts for presenting their work.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/custom-fontset.png" rel="prettyphoto[27810]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/custom-fontset.png?resize=1025%2C739" alt="custom-fontset" class="aligncenter size-full wp-image-28520" /></a></p>
<p>Semplice is geared toward both experienced WordPress users, as well as those who are totally new to the platform. &#8220;Yes, we do aim for people who are familiar with WordPress since they will be able to take Semplice even further than what we offer,&#8221; Van Schneider said. &#8220;But with our Semplice Content Editor we even aim at people who don’t have that much experience with WordPress itself since you don’t really need it.&#8221;</p>
<h3>Licensing, Pricing, and Support</h3>
<p>Introductory <a href="http://www.semplicelabs.com/get-semplice" target="_blank">Semplice pricing</a> for a single domain is $69 and $299 for an agency. Semplice will be launching without offering customer support and is unusual in that it doesn&#8217;t offer any refunds. Support is limited to the first seven days after purchase. The team will assist with anything related to the default Semplice features and is currently working on establishing a pool of <a href="https://vimeo.com/semplicelabs" target="_blank">video tutorials</a> for documentation.</p>
<p>While the Semplice team cannot yet offer full product support, they are committed to delivering critical free updates to existing customers. The software is licensed under the GPL. Although Semplice hasn&#8217;t launched yet, early adopters can purchase the software now for a reduced price.</p>
<p>While the Semplice content editor appeals to new WordPress users, they will still need to overcome the hurdle of installing and setting up a WordPress site on their own domains. Even with 1-click installers, the process can be more difficult than you might imagine for designers and artists with no WordPress experience. Without a fully hosted Semplice platform, the software is going to have to appeal to seasoned WordPress users who appreciate its unique take on building a fullscreen branded portfolio. Do you think Semplice can win out over other theme and plugin-based options?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 20:05:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: A Survival Guide To WordCamps For First Time Attendees";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28486";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:172:"http://wptavern.com/a-survival-guide-to-wordcamps-for-first-time-attendees?utm_source=rss&utm_medium=rss&utm_campaign=a-survival-guide-to-wordcamps-for-first-time-attendees";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2348:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/SurvivalGuideFeaturedImage.png" rel="prettyphoto[28486]"><img class="size-full wp-image-28489" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/SurvivalGuideFeaturedImage.png?resize=639%2C207" alt="Survival Guide Featured Image" /></a>photo credit: <a href="https://www.flickr.com/photos/ari/4166542615/">Steve Rhodes</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a>
<p><a title="http://central.wordcamp.org/" href="http://central.wordcamp.org/">WordCamps</a> are excellent opportunities to learn WordPress and have of face-to-face interaction with a lot of different people. They can also be exhausting and possibly stressful for first timers. Carrie Dils has an awesome <a title="http://www.carriedils.com/wordcamp-tips/" href="http://www.carriedils.com/wordcamp-tips/">WordCamp Survival Guide</a> filled with tips and information on how to get the most out of these events.</p>
<p>Tip number five (don&#8217;t sit by yourself at lunch) routinely happens to me at WordCamps.</p>
<blockquote><p>When the last morning session breaks, there will be a mad dash to the lunch line (did someone say “food?!”). You’ll grab a sack lunch lovingly provided by some volunteer and then you’ll stand there, possibly awkward and not sure where to go. It’s lunch on the first day at a new school all over again.</p>
<p>Try this: Head over to any table with open spots and simply ask to sit down. Unless you just really need that lunch break for personal time, don’t miss an opportunity to meet folks over lunch!</p></blockquote>
<p>I struggle with introducing myself to people I&#8217;ve never met before. At WordCamps, I&#8217;m generally extroverted but I&#8217;ve noticed at larger camps, I become introverted. It&#8217;s a personality thing I&#8217;ve been fighting with for the past few years with mild success. I keep telling myself that I&#8217;m going to introduce myself to everyone I see at a WordCamp but it never works out that way. I end up finding a group of people I&#8217;m familiar with and stick with them. Does anyone else struggle with introversion at WordCamps?</p>
<p>The survival guide is filled with great information but I think the most important point is the last and that&#8217;s to <strong>have fun</strong>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 19:00:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:92:"WPTavern: WPWeekly Episode 158 – Interview With Pippin Willamson Of Easy Digital Downloads";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=28482&preview_id=28482";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:220:"http://wptavern.com/wpweekly-episode-158-interview-with-pippin-willamson-of-easy-digital-downloads?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-158-interview-with-pippin-willamson-of-easy-digital-downloads";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3212:"<p><a title="https://pippinsplugins.com/" href="https://pippinsplugins.com/">Pippin Williamson</a> of <a title="https://easydigitaldownloads.com/" href="https://easydigitaldownloads.com/">Easy Digital Downloads</a> joined <a title="http://marcuscouch.com/" href="http://marcuscouch.com/">Marcus Couch</a> and I to discuss a variety of topics. Williamson tells his story of how he got involved with WordPress. Later in the show, we discuss what it&#8217;s like to be a remote worker. Williamson tells us which tools he uses for project management and how important it is for him to have a disciplined routine.</p>
<p>As a volunteer moderator of the WordPress.org plugin directory, he&#8217;s seen his fair share of plugin submissions. He tells us which types of plugins are automatically rejected and what it&#8217;s like being a gatekeeper for the plugin directory.</p>
<h2>Stories Discussed:</h2>
<p><a title="http://wptavern.com/wp-site-care-acquires-audit-wp" href="http://wptavern.com/wp-site-care-acquires-audit-wp">WP Site Care Acquires Audit WP</a><br />
<a title="http://wptavern.com/new-wordpress-plugin-spell-checks-post-titles-before-publishing" href="http://wptavern.com/new-wordpress-plugin-spell-checks-post-titles-before-publishing">New WordPress Plugin Spell Checks Post Titles Before Publishing</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a title="https://wordpress.org/plugins/html5-slideshow-presentations/" href="https://wordpress.org/plugins/html5-slideshow-presentations/">HTML5 Slideshow Presentations</a> &#8211; With this plugin, you&#8217;ll be able to create a presentation in no time using WordPress&#8217; familiar built-in toolset and the best part is, you won&#8217;t need to upload to slideshare when you&#8217;re done! You host your own presentations allowing you to share or present them at anytime.</p>
<p><a title="https://wordpress.org/plugins/sidebarautomizer/" href="https://wordpress.org/plugins/sidebarautomizer/">Sidebar Automizer</a> &#8211; This little plugin will remove the last widget or widgets from the sidebar if the content area height is smaller than the height of the sidebar area.</p>
<p><a title="https://wordpress.org/plugins/update-from-bottom/" href="https://wordpress.org/plugins/update-from-bottom/">Update from Bottom</a> &#8211; This plug shows two extra buttons (Scroll to top and Publish/Update) in the bottom of the screen when a user scrolls near the bottom of the site. Suitable for posts and pages with a lot of meta boxes or when edit.php just tends to get very long.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, August 20th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #158:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 18:07:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WordPress.tv: Panel Discussion: WordPress for Big Media Organizations";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=37491";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:86:"http://wordpress.tv/2014/08/15/panel-discussion-wordpress-for-big-media-organizations/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:686:"<div id="v-vVgOWPkK-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/37491/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/37491/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=37491&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/15/panel-discussion-wordpress-for-big-media-organizations/"><img alt="Panel Discussion: WordPress for Big Media Organizations" src="http://videos.videopress.com/vVgOWPkK/video-c0bcaf711e_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 15:53:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WordPress.tv: Paul Clark: Performance, Scale, and WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=37135";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.tv/2014/08/15/paul-clark-performance-scale-and-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:664:"<div id="v-t0sytuGQ-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/37135/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/37135/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=37135&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/15/paul-clark-performance-scale-and-wordpress/"><img alt="Paul Clark: Performance, Scale, and WordPress" src="http://videos.videopress.com/t0sytuGQ/video-5e029c807c_scruberthumbnail_3.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 15:50:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WordPress.tv: WordCamp Organizers’ Orientation Hangout Mar 5, 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36459";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wordpress.tv/2014/08/15/wordcamp-organizers-orientation-hangout-mar-5-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:685:"<div id="v-3sKUuCF6-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36459/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36459/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36459&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/15/wordcamp-organizers-orientation-hangout-mar-5-2014/"><img alt="WordCamp Organizers&#8217; Orientation Hangout Mar 5, 2014" src="http://videos.videopress.com/3sKUuCF6/video-00c1d49ee5_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 15:49:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WordPress.tv: Simon Dickson: One Theme, One Multisite, 30+ Unique Websites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=37715";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://wordpress.tv/2014/08/15/simon-dickson-one-theme-one-multisite-30-unique-websites/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:687:"<div id="v-Ry12puOO-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/37715/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/37715/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=37715&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/15/simon-dickson-one-theme-one-multisite-30-unique-websites/"><img alt="Simon Dickson: One Theme, One Multisite, 30+ Unique Websites" src="http://videos.videopress.com/Ry12puOO/video-409f282d42_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 15:20:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"Matt: SmartThings &amp; Samsung";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44005";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://ma.tt/2014/08/smartthings-samsung/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1419:"<p><a href="http://blog.smartthings.com/news/smartthings-updates/smartthings-samsung-open-platform/">SmartThings announced</a> (on their WP-powered blog) that they&#8217;re joining forces with Samsung to continue working on their mission of becoming an operating system for your home. I&#8217;m both <a href="http://audrey.co/">an investor</a> and a fan of the company, which I even <a href="http://blog.smartthings.com/video/the-ultimate-connected-home/">let take over my home in SF earlier this year for CNN</a>. As a tinkerer most of what I do with <a href="http://smartthings.com/">SmartThings</a> so far is relatively basic, I feel like it&#8217;s still the very early days of the platform and what&#8217;s going to come down the line. Samsung makes so much technology (<a href="http://www.samsung.com/us/shop/">and appliances, and TVs, and&#8230;</a>) I can&#8217;t wait to see how they open it up and connect. I also wanted to take this opportunity to congratulate other Audrey companies <a href="http://recode.net/2014/05/19/google-buys-an-enterprise-android-company-divide-formerly-known-as-enterproid/">Divide which joined Google</a> and <a href="https://creativemarket.com/blog/2014/03/19/building-the-worlds-marketplace-for-design">Creative Market which joined Autodesk</a> earlier in 2014. I wasn&#8217;t as good about blogging before and didn&#8217;t get a chance to publicly congratulate those teams.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 13:49:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: Automatically Tweet an Announcement for WordPress Plugin Version Updates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28459";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:208:"http://wptavern.com/automatically-tweet-an-announcement-for-wordpress-plugin-version-updates?utm_source=rss&utm_medium=rss&utm_campaign=automatically-tweet-an-announcement-for-wordpress-plugin-version-updates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2517:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/megaphone.jpg" rel="prettyphoto[28459]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/megaphone.jpg?resize=1024%2C484" alt="photo credit: MACSwriter - cc" class="size-full wp-image-28480" /></a>photo credit: <a href="https://www.flickr.com/photos/88758069@N08/8445004895/">MACSwriter</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a>
<p>Here&#8217;s a quick tip for WordPress.org plugin authors and users, <a href="https://twitter.com/paul_wp/status/500064487047577600" target="_blank">courtesy of Paul de Wouters</a>: With the help of a task automation service like Zapier or IFTTT, you can automatically send out a tweet every time an updated version of your plugin is available. Simply set up an RSS -> Twitter action, like <a href="https://zapier.com/zapbook/rss/twitter/35895/rss-new-item-in-feed-to-twitter-create-tweet/" target="_blank">this one</a> with Zapier:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/rss-tweet.png" rel="prettyphoto[28459]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/rss-tweet.png?resize=1025%2C207" alt="rss-tweet" class="aligncenter size-full wp-image-28465" /></a></p>
<p>Users of <a href="https://ifttt.com/" target="_blank">IFTTT</a> can do the same by creating an RSS to Twitter recipe. You&#8217;ll want to use the <strong>development log feed</strong> on the developers tab of the plugin page. Connecting RSS to Twitter via a service will automate the little tasks involved in promoting your plugin and keeping users up-to-date.</p>
<h4>Get Notified When a Plugin is Updated</h4>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/rss-to-email.png" rel="prettyphoto[28459]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/rss-to-email.png?resize=1025%2C426" alt="rss-to-email" class="aligncenter size-full wp-image-28474" /></a></p>
<p>Plugin users can also harness the same feed URL to send themselves updates via email. Let&#8217;s say you&#8217;ve got a few specific plugins that you are watching intently for an update. Perhaps you&#8217;ve notified the plugin author of a bug and are waiting for a fix or a new feature that&#8217;s in development. Instead of checking your site or the plugin&#8217;s page on WordPress.org for updates, you can set up an RSS to Email automated task to pull from the plugin&#8217;s development log feed and shoot a notice to your inbox.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 05:14:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Dev Blog: WordPress 4.0 Beta 4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3280";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/08/wordpress-4-0-beta-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1990:"<p>The fourth and likely final beta for WordPress 4.0 is now available. We&#8217;ve made <a href="https://core.trac.wordpress.org/log?rev=29496&stop_rev=29229&limit=300">more than 250 changes</a> in the past month, including:</p>
<ul>
<li>Further improvements to the editor scrolling experience, especially when it comes to the second column of boxes.</li>
<li>Better handling of small screens in the media library modals.</li>
<li>A separate bulk selection mode for the media library grid view.</li>
<li>Improvements to the installation language selector.</li>
<li>Visual tweaks to plugin details and customizer panels.</li>
</ul>
<p><strong>We need your help</strong>. We’re still aiming for a release this month, which means the next week will be critical for identifying and squashing bugs. If you’re just joining us, please see <a href="http://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven’t tested WordPress 4.0 yet, now is the time — and be sure to update the “tested up to” version for your plugins so they’re listed as compatible with 4.0.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.0, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-4.0-beta4.zip">download the beta here</a> (zip).</p>
<p><em>We are working hard</em><br />
<em>To finish up 4.0<br />
</em><em>Will you help us too?</em></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Aug 2014 05:06:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WPTavern: Clear Tranquil: A Free Minimalist WordPress Theme for Bloggers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28368";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:186:"http://wptavern.com/clear-tranquil-a-free-minimalist-wordpress-theme-for-bloggers?utm_source=rss&utm_medium=rss&utm_campaign=clear-tranquil-a-free-minimalist-wordpress-theme-for-bloggers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2956:"<p><a href="http://wordpress.org/themes/clear-tranquil" target="_blank">Clear Tranquil</a> is one of the cleanest, most elegant blogging themes to hit WordPress.org in recent days. The theme was created by Woo Themes designer <a href="http://jameskoster.co.uk/" target="_blank">James Koster</a> as a child theme for his responsive <a href="http://wordpress.org/themes/highwind" target="_blank">Highwind</a> parent theme.</p>
<p>Clear Tranquil lives up to its name, inspiring a light, peaceful reading experience that is clutter-free. The design puts your content in focus.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/clear-tranquil.png" rel="prettyphoto[28368]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/clear-tranquil.png?resize=600%2C450" alt="clear-tranquil" class="aligncenter size-full wp-image-28372" /></a></p>
<p>Koster gives meticulous attention to typography and highlights the first character of each post with elegant block letter styles. The theme includes a sticky, understated top navigation menu (optional), and zero widget areas. That&#8217;s right, Clear Tranquil is a completely widget-free zone.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/single-post.png" rel="prettyphoto[28368]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/single-post.png?resize=1025%2C737" alt="single-post" class="aligncenter size-full wp-image-28451" /></a></p>
<p>The theme includes a handful of customization options built into WordPress&#8217; native customizer. You can personalize it with a custom header, background, and your own color selections for text, links, and backgrounds.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/clear-tranquil-customizer.png" rel="prettyphoto[28368]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/clear-tranquil-customizer.png?resize=1025%2C767" alt="clear-tranquil-customizer" class="aligncenter size-full wp-image-28371" /></a></p>
<p>Clear Tranquil includes no additional features, because everything has been intentionally stripped back to keep things simple. Koster hasn&#8217;t set up a live demo of the theme. Ordinarily, the WordPress.org demo gives an unrealistic representation of what a theme will look like. However, in this case, it&#8217;s fairly accurate.</p>
<p>One of the things that I love about the WordPress theme installation process is that it will automatically install the parent theme for a child theme, if you don&#8217;t already have it installed. In this scenario, if you install Clear Tranquil without Highwind already in place, it will be automatically downloaded for you.</p>
<p>If your blog has gotten bloated with widgets and is in need of a minimalist makeover, Clear Tranquil might be just the ticket. <a href="http://wordpress.org/themes/clear-tranquil" target="_blank">Download</a> it for free from the WordPress Themes Directory.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Aug 2014 23:04:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"WPTavern: Foster Me: A WordPress Plugin to Help Shelter Animals in Need";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28267";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:184:"http://wptavern.com/foster-me-a-wordpress-plugin-to-help-shelter-animals-in-need?utm_source=rss&utm_medium=rss&utm_campaign=foster-me-a-wordpress-plugin-to-help-shelter-animals-in-need";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5833:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/dog.jpg" rel="prettyphoto[28267]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/dog.jpg?resize=800%2C397" alt="photo credit: puck90 - cc" class="size-full wp-image-28424" /></a>photo credit: <a href="https://www.flickr.com/photos/puck90/426370372/">puck90</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a>
<p>Everybody knows that animals need homes. There are far more pets available for adoption than there are people lining up to adopt them. Call your local animal shelter and they&#8217;ll probably tell you that they&#8217;re at or over capacity. That&#8217;s where foster homes can help to provide quality care for animals in the interim, until they find their forever homes.</p>
<p><a href="http://wordpress.org/plugins/foster-me-seek-shelter-an-animal-in-need/" target="_blank">Foster Me</a> is a new WordPress plugin designed to help rescues and shelters make available pets more visible and easier to search. It was created by <a href="http://digitalmediagirl.com/" target="_blank">Stephanie Chow</a>, a front-end developer and animal advocate located in Asheville, NC. Her <a href="http://www.lendingapaw.org/" target="_blank">Lending a Paw</a> site features open source plugins and graphics for animal rescue organizations.</p>
<p>Foster Me makes it easy to list and manage animals in WordPress where they can be searched with advanced pet-specific filters, such as age, type, gender, temperament, special needs, etc.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/foster-me.jpg" rel="prettyphoto[28267]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/foster-me.jpg?resize=1025%2C792" alt="foster-me" class="aligncenter size-full wp-image-28392" /></a></p>
<p>When a visitor clicks on an available pet, the listing launches in a modal window. Individual pet listings display a full description, a slider with multiple photographs, and any applicable pet categories.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/pet-listing.jpg" rel="prettyphoto[28267]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/pet-listing.jpg?resize=1025%2C522" alt="pet-listing" class="aligncenter size-full wp-image-28407" /></a></p>
<p>The plugin also makes it easy to list fostering information and to post your foster application. Chow has made every effort to make Foster Me a user-friendly plugin for rescues and shelters that may not have a WordPress expert on staff. The settings page allows you to easily customize the color and appearance of the header, pet options, pet grid and modal window.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/foster-me-settings.jpg" rel="prettyphoto[28267]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/foster-me-settings.jpg?resize=658%2C764" alt="foster-me-settings" class="aligncenter size-full wp-image-28411" /></a></p>
<p>Foster Me also includes an image widget for showcasing foster pets as well as a Recently Added widget to display new additions.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/foster-me-widget.jpg" rel="prettyphoto[28267]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/foster-me-widget.jpg?resize=756%2C722" alt="foster-me-widget" class="aligncenter size-full wp-image-28412" /></a></p>
<p>The plugin adds a whole suite of pet listing features that are general enough to be used in any kind of shelter or rescue website:</p>
<ul>
<li><strong>Filterable</strong> &#8211; filter by Type, Age, Size, Gender, Temperament, and Special Needs</li>
<li><strong>Searchable</strong> &#8211; list is narrowed with every letter you type into search bar</li>
<li><strong>Click On Any Pet</strong> &#8211; to view more information and photos</li>
<li><strong>List Your Fostering Info</strong> &#8211; show how it works what to expect when you foster</li>
<li><strong>Colors</strong> &#8211; are completely customizable to match your brand</li>
<li><strong>Image Widget</strong> &#8211; place in sidebar to display a linkable, rotating image of foster pets</li>
<li><strong>Recently Added Widget</strong> &#8211; place in sidebar to display your most recently added fosters</li>
</ul>
<p>Check out a <a href="http://www.lendingapaw.org/foster-me-demo/" target="_blank">live demo</a> of Foster Me to test out the pet searching and filtering capabilities.</p>
<p>Chow&#8217;s first plugin, <a href="http://wordpress.org/plugins/petfinder-search-rescue/" target="_blank">Petfinder: Search and Rescue</a>, is very similar to her latest release, except it requires the animals to be listed on Petfinder. If you already have your shelter or rescue pets listed on Petfinder, then this alternative will be a better option for automatically pulling in your existing listings.</p>
<h3>Saving Animals with WordPress</h3>
<p>The <a href="http://wordpress.org/plugins/foster-me-seek-shelter-an-animal-in-need/" target="_blank">Foster Me</a> plugin is an awesome open source tool that any shelter or rescue can use for free in combination with an existing WordPress site. When it comes to helping animals find their forever homes, open source software may not be the first thing that comes to mind, but Stephanie Chow is knocking it out of the park with her user-friendly tools designed to serve people who are rescuing creatures in need. Open source tools are more accessible to shelters and rescues that are spending every last dime to help animals find homes. If you have WordPress skills and are able to hook up a shelter with a website, then the <a href="http://wordpress.org/plugins/foster-me-seek-shelter-an-animal-in-need/" target="_blank">Foster Me</a> plugin will put you well on your way.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Aug 2014 20:57:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:80:"WordPress.tv: Tom Harness and Leigh Caldwell: Business Blogging Like a Rock Star";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36918";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wordpress.tv/2014/08/14/tom-harness-and-leigh-caldwell-business-blogging-like-a-rock-star/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:702:"<div id="v-zwSAV7EI-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36918/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36918/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36918&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/14/tom-harness-and-leigh-caldwell-business-blogging-like-a-rock-star/"><img alt="Tom Harness and Leigh Caldwell: Business Blogging Like a Rock Star" src="http://videos.videopress.com/zwSAV7EI/video-b28b50d146_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Aug 2014 15:47:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WordPress.tv: Zoe Rooney: Automating Theme Development with Gulp, Yeoman, and Friends";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36937";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:100:"http://wordpress.tv/2014/08/14/zoe-rooney-automating-theme-development-with-gulp-yeoman-and-friends/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:716:"<div id="v-YMRqf8Ju-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36937/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36937/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36937&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/14/zoe-rooney-automating-theme-development-with-gulp-yeoman-and-friends/"><img alt="Zoe Rooney: Automating Theme Development with Gulp, Yeoman, and Friends" src="http://videos.videopress.com/YMRqf8Ju/video-93a9170cc7_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Aug 2014 15:42:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WordPress.tv: WordCamp Organizers’ Orientation Hangout Feb 18, 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36462";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://wordpress.tv/2014/08/14/wordcamp-organizers-orientation-hangout-feb-18-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:687:"<div id="v-w9AvqlDI-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36462/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36462/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36462&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/14/wordcamp-organizers-orientation-hangout-feb-18-2014/"><img alt="WordCamp Organizers&#8217; Orientation Hangout Feb 18, 2014" src="http://videos.videopress.com/w9AvqlDI/video-bc9fa9adb7_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Aug 2014 15:39:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:83:"WordPress.tv: Taylor Buley: How Parade.com Uses the WordPress Theme Customizer API";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=37713";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:99:"http://wordpress.tv/2014/08/14/taylor-buley-how-parade-com-uses-the-wordpress-theme-customizer-api/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:713:"<div id="v-8Uap5hMd-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/37713/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/37713/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=37713&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/14/taylor-buley-how-parade-com-uses-the-wordpress-theme-customizer-api/"><img alt="Taylor Buley: How Parade.com Uses the WordPress Theme Customizer API" src="http://videos.videopress.com/8Uap5hMd/video-1c7ae055fe_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Aug 2014 15:15:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: WebDevStudios Names Dre Armeda Vice President of Operations";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28328";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:182:"http://wptavern.com/webdevstudios-names-dre-armeda-vice-president-of-operations?utm_source=rss&utm_medium=rss&utm_campaign=webdevstudios-names-dre-armeda-vice-president-of-operations";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6086:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/DreArmedaBradWilliamsFeaturedImage.png" rel="prettyphoto[28328]"><img class="size-full wp-image-28375" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/DreArmedaBradWilliamsFeaturedImage.png?resize=650%2C200" alt="Dre Armeda and Brad Williams Join Forces Featured Image" /></a>Dre Armeda and Brad Williams Join Forces
<p>In the time Dre Armeda spent with <a title="https://sucuri.net/" href="https://sucuri.net/">Sucuri</a>, he turned a two-person part-time hobby into a multi-million dollar, 30+ employee company. When Armeda <a title="http://dremeda.com/fair-winds-and-following-seas-sucuri/" href="http://dremeda.com/fair-winds-and-following-seas-sucuri/">left the company</a> he helped found, he didn&#8217;t provide any hints as to where he was going.</p>
<p>Three months after leaving Sucuri, Armeda <a title="http://webdevstudios.com/2014/08/14/dre-armeda-joins-webdevstudios/" href="http://webdevstudios.com/2014/08/14/dre-armeda-joins-webdevstudios/">has been named</a> the Vice President of Operations for <a title="http://webdevstudios.com/" href="http://webdevstudios.com/">WebDevStudios</a>. Brad Williams, co-owner of WebDevStudios and Armeda were kind enough to answer a few questions I had regarding the hire.</p>
<h2>Interview With Dre Armeda and Brad Williams</h2>
<p><strong>What does the Vice President of Operations for WebDevStudios do?</strong></p>
<p><em>Brad Williams</em> &#8211; The Vice President of Operations is a new role at WDS and our first Executive position outside of the original Partners.  WDS has been growing quite a bit this year and we knew it was time to start expanding the leadership team. Dre brings a wealth of knowledge and a ton of experience to WDS, specifically around building a very successful distributed company.  Some of the primary responsibilities for Dre include business development, improving operational efficiency, marketing, and even sales.  Roles at WDS are always evolving, so I certainly expect Dre&#8217;s position to really evolve and be defined over the next few months.</p>
<p><strong>In some instances, businesses can ruin friendships. How did you two factor that into the equation before making the hire? Will the fact that you&#8217;re now co-workers have an effect on your personal relationship?</strong></p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/DreandBrad.png" rel="prettyphoto[28328]"><img class="size-full wp-image-28378" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/DreandBrad.png?resize=698%2C353" alt="Dre and Brad at WCSF 2013" /></a>Image Courtesy Of <a title="http://designsimply.com/2013/08/25/photos-from-wcsf-2013/mcm_8499/" href="http://designsimply.com/2013/08/25/photos-from-wcsf-2013/mcm_8499/">Designsimply.com</a>
<p><em>Brad Williams</em> &#8211; When we started discussing the possibility of Dre Armeda joining WDS, this was the first item we discussed. We knew from the start that we had to look at this from a business perspective and not because we are close friends. The last thing either of us would ever want would be to ruin the friendship that we have. Dre Armeda is a perfect fit for WDS, not only in the business sense, but also our company culture. We work hard, and play hard, and no one works and plays harder than Dre Armeda!</p>
<p><strong>Out of all the possible places to work in the WordPress ecosystem, why did you choose WebDevStudios?</strong></p>
<p><em>Dre Armeda</em> &#8211; There is certainly a long relationship there with the leadership, the company, and the team. Brad Williams and I of course are the co-hosts of <a title="http://dradcast.com/" href="http://dradcast.com/">DradCast</a> and have even presented on the topic of security together in years past at WordCamps. While part of Sucuri, we successfully worked with WebDevstudios in various capacities. The direction of the company, and the culture is very much inline with where I want to be, and where I want to go. Along with that connection, our long relationship, and the experience I can bring to the table, I think the decision was easy.</p>
<p><strong>Do you look at this as a long-term (2-3 year) position?</strong></p>
<p><em>Dre Armeda</em> &#8211; One of the key points we talked about as we started looking into the possibility of working together was exactly that. We were looking for a long term situation and we’re excited about what the future brings!</p>
<p><strong>What lessons or experiences did you learn with Sucuri that you&#8217;ll be able to apply to improve WebDevStudios?</strong></p>
<p><em>Dre Armeda</em> &#8211; The position will encompass a broad range of responsibilities and oversight ranging from organizational and business development, to talent development and strategy. I&#8217;ve had the great opportunity to work in these areas over the past five years as I helped build Sucuri into the successful organization it is today.</p>
<p>I am very passionate about better serving our audience by expanding global reach and I’m certainly excited about increasing overall organizational efficiency through resourcing, process improvement, and business development. I really enjoy helping implement strategies to scale organizations efficiently and ultimately the lessons I have learned from my experience at Sucuri definitely align with the forward vision at WebDevStudios!</p>
<h2>What Was Once A Joke Has Become A Reality</h2>
<p>Those who know Williams and Armeda have joked that the two would some day work together but it was always a joke. Now, it&#8217;s real and it will be interesting to see how it works out. Based on the interview, Armeda is committed to the company for the long-term, something that&#8217;s not <a title="http://wptavern.com/why-company-culture-is-so-important-for-remote-wordpress-developers" href="http://wptavern.com/why-company-culture-is-so-important-for-remote-wordpress-developers">easily accomplished</a> when hiring remote workers. Does this move surprise you or did you see the writing on the wall?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Aug 2014 14:59:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"Matt: You Won’t Believe Who Wrote This Product Checklist";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43998";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://ma.tt/2014/08/you-wont-believe-who-wrote-this-productchecklist/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1089:"<blockquote>
<ol>
<li>Understand what people need.</li>
<li>Address the whole experience, from start to finish.</li>
<li>Make it simple and intuitive.</li>
<li>Build the service using agile and iterative practices.</li>
<li>Structure budgets and contracts to support delivery.</li>
<li>Assign one leader and hold that person accountable.</li>
<li>Bring in experienced teams.</li>
<li>Choose a modern technology stack.</li>
<li>Deploy in a flexible hosting environment.</li>
<li>Automate testing and deployments.</li>
<li>Manage security and privacy through reusable processes.</li>
<li>Use data to drive decisions.</li>
<li>Default to open.</li>
</ol>
</blockquote>
<p>That sounds like a list anyone creating something online should follow. Would you guess <a href="http://playbook.cio.gov/">it&#8217;s actually from the US government Digital Services Playbook</a>? Great work by <a href="https://twitter.com/stevenvDC">Steven VanRoekel</a> and his team, which I had the pleasure of meeting last time I was in DC. <cite>Hat tip: <a href="http://dashes.com/anil/">Anil Dash</a>.</cite></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Aug 2014 14:10:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"WPTavern: The Simple Criteria That Determines Which Jetpack Modules Are Auto-Activated";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28360";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:216:"http://wptavern.com/the-simple-criteria-that-determines-which-jetpack-modules-are-auto-activated?utm_source=rss&utm_medium=rss&utm_campaign=the-simple-criteria-that-determines-which-jetpack-modules-are-auto-activated";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3233:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/AutoActivateModulesFeaturedImage.png" rel="prettyphoto[28360]"><img class="size-full wp-image-28362" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/AutoActivateModulesFeaturedImage.png?resize=640%2C210" alt="Auto Activate Jetpack Modules Featured Image" /></a>photo credit: <a href="https://www.flickr.com/photos/2create/2144345327/">2create</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a>
<p>Since the release of <a title="http://jetpack.me/" href="http://jetpack.me/">Jetpack</a> in 2011, there have been <a title="http://premium.wpmudev.org/blog/daily-tip-stop-jetpack-from-auto-activating-new-modules/" href="http://premium.wpmudev.org/blog/daily-tip-stop-jetpack-from-auto-activating-new-modules/">several</a> <a title="http://krogsgard.com/2012/jetpack/" href="http://krogsgard.com/2012/jetpack/">articles</a> highlighting the fact that it auto activates modules. George Stephanis, a member of the Jetpack development team, has <a title="http://wptavern.com/easier-way-to-enable-or-disable-jetpack-modules-with-rocketeer#comment-49494" href="http://wptavern.com/easier-way-to-enable-or-disable-jetpack-modules-with-rocketeer#comment-49494">consistently explained</a> that &#8220;Jetpack only auto-activates modules that provide enhancements without affecting the front-end layout of the site.&#8221;</p>
<p>Earlier today, Stephanis <a title="http://stephanis.info/2014/08/13/on-jetpack-and-auto-activating-modules/" href="http://stephanis.info/2014/08/13/on-jetpack-and-auto-activating-modules/">published a post on his blog</a> that goes into detail on how the decision is made to auto-activate a module.</p>
<blockquote><p>We’ve spoken to many, many users who find a default feature set convenient, and resent having to make a bunch of ‘decision points’ if they had to manually activate each and every module. Good software should run well <a href="http://wordpress.org/about/philosophy/#box">out of the box</a>. So we’ve set up the defaults as we have. Yes, <a href="http://wordpress.org/about/philosophy/#minority">some people disagree and are vocal about not wanting anything to auto-activate</a>. That’s okay. We try to <a href="http://wordpress.org/about/philosophy/#majority">design for the majority</a>, with the best user experience we can provide.</p></blockquote>
<p>I appreciate the fact that new modules <strong>will not</strong> auto-activate if they impact the front end of my site. In this instance, the decisions being made for me are a convenience, not a hassle. If you disagree with the decisions being made, there are <a title="http://jeremy.hu/customize-the-list-of-modules-available-in-jetpack/" href="http://jeremy.hu/customize-the-list-of-modules-available-in-jetpack/">several filters</a> you can use to customize the Jetpack experience, including one to deactivate all modules by default.</p>
<p><code>add_filter( \'jetpack_get_default_modules\', \'__return_empty_array\' );</code></p>
<p>I doubt his post will resonate with those who have a strong stance against auto-activating anything. As long as the development team stick to their current philosophy, I&#8217;m ok with it.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Aug 2014 01:10:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"WPTavern: Carl Hancock Shares Advice On Registering Trademarks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28347";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:168:"http://wptavern.com/carl-hancock-shares-advice-on-registering-trademarks?utm_source=rss&utm_medium=rss&utm_campaign=carl-hancock-shares-advice-on-registering-trademarks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1553:"<p>Chris Lema <a title="http://chrislema.com/trademarks-wordpress-carl-hancock/" href="http://chrislema.com/trademarks-wordpress-carl-hancock/">published an interview</a> with Carl Hancock of <a title="http://www.rocketgenius.com/" href="http://www.rocketgenius.com/">RocketGenius</a>, where he shares his thoughts on why trademarks are important and how they help protect a brand&#8217;s identity. While you can register trademarks yourself, Hancock suggests working with a lawyer who knows intellectual property law and does it for a living.</p>
<blockquote><p>It’s not simple and straightforward.You don’t pay $100 and instantly gain protection for your brand name around the world. It’s why I recommend not doing it yourself – work with a lawyer who knows intellectual property law and does this for a living.</p></blockquote>
<p>Earlier this year, I wrote about how the <a title="http://wptavern.com/the-gpl-license-doesnt-provide-the-freedom-to-infringe-registered-trademarks" href="http://wptavern.com/the-gpl-license-doesnt-provide-the-freedom-to-infringe-registered-trademarks">GPL doesn&#8217;t give people the right to infringe trademarks</a>. As the WordPress product market matures, I think we&#8217;ll see more businesses trademark their logo and product names, especially if more sites like <a title="https://gplclub.org/" href="https://gplclub.org/">GPL Club</a> are created. If you&#8217;ve gone through the process of registering or enforcing a trademark for your product or business, share your experience in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Aug 2014 01:00:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: WPCore App Adds Export Feature: Save Active Plugins to a Collection with 1-Click";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28318";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:222:"http://wptavern.com/wpcore-app-adds-export-feature-save-active-plugins-to-a-collection-with-1-click?utm_source=rss&utm_medium=rss&utm_campaign=wpcore-app-adds-export-feature-save-active-plugins-to-a-collection-with-1-click";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3043:"<p>We&#8217;ve been following the evolution of the <a href="https://wpcore.com/" target="_blank">WPCore plugin management app</a>, which recently added favoriting, update notifications, and the ability to add plugins that aren&#8217;t hosted on WordPress.org. Today, the app&#8217;s developer, Stuart Starr, announced what is perhaps the most convenient feature to date.</p>
<p>With <a href="http://wordpress.org/plugins/wpcore/" target="_blank">WPCore Plugin Manager</a> installed, users can now export all of their plugins with one click and save them to a new collection on WPcore.com. This is useful if you have a site that already has all the plugins you want to include in a specific collection.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/export.jpg" rel="prettyphoto[28318]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/export.jpg?resize=513%2C211" alt="export" class="aligncenter size-full wp-image-28336" /></a></p>
<p>Despite the fact that the plugin makes it convenient to install all your favorite plugins in one click, you may find that building collections requires quite a bit of work. The new export feature makes it possible to build a collection instantly, based on an existing site&#8217;s active plugins. Currently, it can only export active plugins hosted on WordPress.org, but Starr plans to expand the feature in the future.</p>
<h3>Clone WordPress Plugin Collections</h3>
<p>Another new feature that you&#8217;ll find on the app side of WPCore is the ability to clone other users&#8217; collections. Perhaps you want most of the plugins in one collection but want to add or remove a few selections. Click on the new clone button to copy the collection to your own account for editing.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/clone-collection.jpg" rel="prettyphoto[28318]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/clone-collection.jpg?resize=983%2C518" alt="clone-collection" class="aligncenter size-full wp-image-28345" /></a></p>
<p>Starr is continuing development on the app and plugin, inspired by positive feedback from users who are saving time with WPCore. &#8220;The feedback has been amazing. In terms of users we are getting new users daily,&#8221; he said. One satisfied fan dubbed WPCore the &#8220;<a href="https://twitter.com/kierstenbogush/status/498723752721391617" target="_blank">Pinterest for WordPress plugins</a>.&#8221;</p>
<p>September will bring a major update to the service. Starr wouldn&#8217;t comment on the specifics of features on the way but he did reveal that he is currently working on a referral system. <a href="http://wptavern.com/wpcore-plugin-manager-adds-update-notifications-plans-to-implement-pro-subscription" target="_blank">WPCore is moving to a paid subscription model</a> as of August 31st but users who sign up before that time will be grandfathered in as Pro members for life. New free signups will continue to have access to the basic features of the app.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Aug 2014 23:47:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WPTavern: New WordPress Plugin Spell Checks Post Titles Before Publishing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28230";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:190:"http://wptavern.com/new-wordpress-plugin-spell-checks-post-titles-before-publishing?utm_source=rss&utm_medium=rss&utm_campaign=new-wordpress-plugin-spell-checks-post-titles-before-publishing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1941:"<p>Have you ever published a post in WordPress only to realize the title has a misspelled word? Sure, a quick edit will do the trick but wouldn&#8217;t it be nice if the misspelling was caught before the post went live? WordPress doesn&#8217;t spell check post titles but you can change that with a new plugin called <a title="https://github.com/FlagshipWP/post-title-spell-check" href="https://github.com/FlagshipWP/post-title-spell-check">Post Title Spell Check,</a> developed by <a href="https://github.com/robneu">Robert Neu</a> and <a href="https://github.com/bradyvercher">Brady Vercher</a>.</p>
<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/TestingPostTitleSpellCheckerPlugin.png" rel="prettyphoto[28230]"><img class="size-full wp-image-28316" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/TestingPostTitleSpellCheckerPlugin.png?resize=538%2C297" alt="Post Title Spell Checking Plugin" /></a>Yep, It Works
<p>It&#8217;s a simple plugin that adds a small bit of code to the WordPress title input field. Activating the plugin allows all post types which support the default WordPress title input field to be spell checked by modern browsers. There are no settings to configure as it&#8217;s a set and forget type of plugin.</p>
<h2>How To Spell Check Post Titles Without Using A Plugin</h2>
<p>If Firefox is your browser of choice, I found a <a title="http://rhour.com/activate-spell-check-for-post-titles.html" href="http://rhour.com/activate-spell-check-for-post-titles.html">great guide on Rhour.com</a> that explains how to change a value in Firefox&#8217;s configuration file to spell check post titles. The downside to this technique is that it&#8217;s for Firefox only. The plugin on the other hand, enables post title spell checking across all modern browsers.</p>
<p>Is this something you&#8217;d like to see added to the core of WordPress or should it be left to web browsers to handle?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Aug 2014 21:48:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: WordPress Rainbow Hilite Plugin Adds Rainbow.js for Syntax Highlighting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28270";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:206:"http://wptavern.com/wordpress-rainbow-hilite-plugin-adds-rainbow-js-for-syntax-highlighting?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-rainbow-hilite-plugin-adds-rainbow-js-for-syntax-highlighting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4034:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/rainbow.jpg" rel="prettyphoto[28270]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/rainbow.jpg?resize=1024%2C514" alt="photo credit: Βethan - cc" class="size-full wp-image-28301" /></a>photo credit: <a href="https://www.flickr.com/photos/beth19/4912628387/">Βethan</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a>
<p>If you regularly blog code snippets, adding a syntax highlighter plugin can help make your code more readable and easier to copy. Many plugins use language-specific shortcodes to surround embedded code, but this generally requires you to remember the right way to form the shortcode. The new <a href="http://wordpress.org/plugins/wp-rainbow-hilite/" target="_blank">WordPress Rainbow Hilite</a> plugin uses a different method for embedding code in posts.</p>
<p>The plugin incorporates the lightweight <a href="http://craig.is/making/rainbows" target="_blank">Rainbow.js</a> syntax highlighting library into WordPress and is completely themable via CSS. Rainbow Hilite utilizes the visual editor to add language-specific styles to pre tags.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/rainbow-hilite-editor.png" rel="prettyphoto[28270]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/rainbow-hilite-editor.png?resize=653%2C526" alt="rainbow-hilite-editor" class="aligncenter size-full wp-image-28284" /></a></p>
<p>The plugin includes support for 18 commonly used languages, which can be enabled or disabled in the settings located in the Writing panel:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/rainbow-languages.jpg" rel="prettyphoto[28270]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/rainbow-languages.jpg?resize=977%2C310" alt="rainbow-languages" class="aligncenter size-full wp-image-28274" /></a></p>
<p>It also includes 19 preset visual themes to choose from for making your code beautiful. The settings panel allows you to toggle a sample code block in order to conveniently preview each theme without having to navigate to the frontend.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/toggle-code.gif" rel="prettyphoto[28270]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/toggle-code.gif?resize=850%2C504" alt="toggle-code" class="aligncenter size-full wp-image-28276" /></a></p>
<p>Below is an example of how code appears on the frontend using the plugin&#8217;s sample code. One handy thing Rainbow Hilite&#8217;s output is that the highlighted code can be copy-pasted directly out of the site. There&#8217;s no &#8220;view raw&#8221; button to clutter up the code snippet.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/rainbow-example.jpg" rel="prettyphoto[28270]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/rainbow-example.jpg?resize=652%2C568" alt="rainbow-example" class="aligncenter size-full wp-image-28275" /></a></p>
<p>Line numbers are optional and when active they are added using <a href="https://github.com/Sjeiti/rainbow.linenumbers" target="_blank">rainbow.linenumbers</a>. The plugin also includes some <a href="https://github.com/mcguffin/wp-rainbow-hilite#plugin-api" target="_blank">filters</a>, which allow users to load their own language modules and themes and plugins to hook in.</p>
<p>If you ever decide to stop using the plugin, pre tags aren&#8217;t as bad as orphaned shortcodes littered throughout your posts. In other words, using it doesn&#8217;t mean that you&#8217;re married to the plugin for life. If you&#8217;d like to suggest any changes, the development version of Rainbow Hilite is available on <a href="https://github.com/mcguffin/wp-rainbow-hilite" target="_blank">GitHub</a>. If you want to use the plugin on your site,  you can <a href="http://wordpress.org/plugins/wp-rainbow-hilite/" target="_blank">download</a> it from WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Aug 2014 20:03:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WordPress.tv: Dave Jensen: Metro UK’s Powerful Content Algorithm";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=37910";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://wordpress.tv/2014/08/13/dave-jensen-metro-uks-powerful-content-algorithm/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:671:"<div id="v-vhHvKooO-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/37910/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/37910/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=37910&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/13/dave-jensen-metro-uks-powerful-content-algorithm/"><img alt="Dave Jensen: Metro UK’s Powerful Content Algorithm" src="http://videos.videopress.com/vhHvKooO/video-4d74be6fad_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Aug 2014 19:00:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WordPress.tv: Kevin Newman: Harvard Business Review and WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=37727";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wordpress.tv/2014/08/13/kevin-newman-harvard-business-review-and-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:672:"<div id="v-AgRygS6W-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/37727/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/37727/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=37727&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/13/kevin-newman-harvard-business-review-and-wordpress/"><img alt="Kevin Newman: Harvard Business Review and WordPress" src="http://videos.videopress.com/AgRygS6W/video-6ccda50669_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Aug 2014 16:42:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:37:"Joseph: WordCamp Salt Lake City, 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"https://josephscott.org/?p=10802";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"https://josephscott.org/archives/2014/08/wordcamp-salt-lake-city-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1718:"<p><a href="http://2014.slc.wordcamp.org/"><img src="https://josephscott.org/wp-content/uploads/2014/08/wcslc-2014.png" alt="wcslc-2014" width="479" height="341" class="aligncenter size-full wp-image-10817" /></a></p>
<p><a href="http://2014.slc.wordcamp.org/">WordCamp SLC 2014</a> is coming up fast.  Just one month away: <strong>Saturday 13 September 2014</strong>.  This is one day that brings together the local WordPress community like no other.  We tend to get a wide range of people attending, from those just starting out, to designers, developers, consultants, and people who contribute to the core code of WordPress.</p>
<p>WordCamp SLC is a great opportunity to learn a few things from the presentations.  Even more important than that is the chance to get to know other WordPress users in the community.</p>
<p>One really important thing to note for 2014, the <a href="http://2014.slc.wordcamp.org/location/">location has changed</a>:</p>
<p></p>
<p>City And County Building<br />
451 Washington Square,<br />
Salt Lake City, Utah</p>
<p>The <a href="http://2014.slc.wordcamp.org/tickets/">registration this year is only $15</a>, which includes lunch.  The reduced price is to help offset the cost of parking in down town SLC.</p>
<p>If you are interested in speaking there is still time to <a href="http://2014.slc.wordcamp.org/speakers/speaker-application/">submit a presentation proposal</a>.</p>
<p>Go <a href="http://2014.slc.wordcamp.org/tickets/">register</a> today and be sure to say hi when I see you on September 13th.  Then go give a big thank you to <a href="https://twitter.com/MikeHansenMe">Mike Hansen</a>, he is organizing <a href="http://2014.slc.wordcamp.org/">WordCamp SLC 2014</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Aug 2014 15:49:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Joseph Scott";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Matt: Extrinsic Motivation Doesn’t Work";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43987";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ma.tt/2014/08/extrinsic-motivation-doesntwork/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:376:"<p>From <a href="http://seriouspony.com/">Kathy Sierra</a>, here&#8217;s &#8220;One of the longest deep studies on negative impact of external reinforcers (e.g. rewards) on long-term motivation&#8221;: <a href="http://www.pnas.org/content/111/30/10990.full">Multiple types of motives don&#8217;t multiply the motivation of West Point cadets</a>. Academic, but interesting.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Aug 2014 15:37:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:83:"WordPress.tv: Alex McClafferty: Building Your WordPress Business With Relationships";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=37320";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:100:"http://wordpress.tv/2014/08/13/alex-mcclafferty-building-your-wordpress-business-with-relationships/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:714:"<div id="v-l4ykY5Pm-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/37320/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/37320/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=37320&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/13/alex-mcclafferty-building-your-wordpress-business-with-relationships/"><img alt="Alex McClafferty: Building Your WordPress Business With Relationships" src="http://videos.videopress.com/l4ykY5Pm/video-43637e555e_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Aug 2014 15:30:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WordPress.tv: WordCamp Organizer’s Orientation AMA";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36456";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wordpress.tv/2014/08/13/wordcamp-organizers-orientation-ama/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:654:"<div id="v-Qnax801N-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36456/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36456/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36456&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/13/wordcamp-organizers-orientation-ama/"><img alt="WordCamp Organizer&#8217;s Orientation AMA" src="http://videos.videopress.com/Qnax801N/video-d5b8927979_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Aug 2014 15:26:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"WordPress.tv: Aaron Jorbin: The Users We Forget About";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36952";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wordpress.tv/2014/08/13/aaron-jorbin-the-users-we-forget-about/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:654:"<div id="v-3s5zGSB4-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36952/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36952/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36952&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/13/aaron-jorbin-the-users-we-forget-about/"><img alt="Aaron Jorbin: The Users We Forget About" src="http://videos.videopress.com/3s5zGSB4/video-1f14f13e89_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Aug 2014 15:15:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: Espied: A Free WordPress Portfolio Theme for Designers and Photographers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28131";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:206:"http://wptavern.com/espied-a-free-wordpress-portfolio-theme-for-designers-and-photographers?utm_source=rss&utm_medium=rss&utm_campaign=espied-a-free-wordpress-portfolio-theme-for-designers-and-photographers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3633:"<p>If you&#8217;re on the hunt for a new design to showcase your work, WordPress.com&#8217;s beautiful <a href="https://wordpress.com/themes/espied/" target="_blank">Espied</a> theme is now available for use on self-hosted sites. This striking minimalist portfolio theme was created with designers, photographers, and artists in mind.</p>
<p>Espied utilizes WordPress.com&#8217;s <a href="http://en.support.wordpress.com/portfolios/" target="_blank">portfolio</a> feature, which was recently <a href="http://wptavern.com/jetpack-rebrands-with-new-logo-adds-custom-post-types-in-3-1-release" target="_blank">added to Jetpack</a>. With this custom content type enabled, users can easily manage and showcase projects with the <code>[portfolio]</code> shortcode.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/espied.png" rel="prettyphoto[28131]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/espied.png?resize=880%2C660" alt="espied" class="aligncenter size-full wp-image-28133" /></a></p>
<p>Customization options for Espied include support for a 1600 × 320px header image, the ability to set the header text color, and a unique option for setting the thumbnail aspect ratio. Featured image ratio options include landscape (4:3), portrait (3:4), and square (1:1). This setting carries over to archive pages, the portfolio page template, and portfolio shortcodes.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/espied-archive-page.png" rel="prettyphoto[28131]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/espied-archive-page.png?resize=1025%2C780" alt="espied-archive-page" class="aligncenter size-full wp-image-28247" /></a></p>
<p>The theme includes a sidebar that slides out to display navigation and widgets. It is hidden until clicked in order to keep the focus on showcasing your work.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/sidebar.jpg" rel="prettyphoto[28131]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/sidebar.jpg?resize=660%2C336" alt="sidebar" class="aligncenter size-full wp-image-28250" /></a></p>
<p>Espied also features a beautiful way to display your social links via a custom menu. Add your social URLs as menu items and the theme will automatically display the right icon, if it&#8217;s available. It currently includes 22 different icons for various social profiles.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/social-links.jpg" rel="prettyphoto[28131]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/social-links.jpg?resize=660%2C305" alt="social-links" class="aligncenter size-full wp-image-28249" /></a></p>
<p>Espied showcases images at full width on larger displays so it&#8217;s important to use images that are at least 1272px. Although the theme does include beautiful, readable typography for blogging, the design is probably best-suited for sites that are primarily portfolios or other visual showcases. Check out a <a href="http://espieddemo.wordpress.com/" target="_blank">live demo</a> on WordPress.com to see the theme in action.</p>
<p>With the release of Espied, the folks at Automattic are approaching 50 free themes listed on WordPress.org. This portfolio theme is a home run and responds nicely to any screen size. If you want an easy way to showcase your work without having to configure a ton of options, Espied is an excellent choice. <a href="http://wordpress.org/themes/espied" target="_blank">Download</a> it from the WordPress.org or install it directly via your admin themes panel.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Aug 2014 04:42:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:101:"WPTavern: Theme Checklist Helps Prepare Developers To Submit A Theme To The WordPress Theme Directory";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28095";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:246:"http://wptavern.com/theme-checklist-helps-prepare-developers-to-submit-a-theme-to-the-wordpress-theme-directory?utm_source=rss&utm_medium=rss&utm_campaign=theme-checklist-helps-prepare-developers-to-submit-a-theme-to-the-wordpress-theme-directory";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4406:"<p><a title="http://wordpress.org/plugins/theme-checklist/" href="http://wordpress.org/plugins/theme-checklist/">Theme Checklist</a> is a new plugin by <a title="http://profiles.wordpress.org/gpriday/" href="http://profiles.wordpress.org/gpriday/">Greg Priday</a> of <a title="http://siteorigin.com/" href="http://siteorigin.com/">SiteOrigin</a>. The plugin provides a checklist of items to go through before submitting a theme to the WordPress theme directory. Once activated, you&#8217;ll find the checklist under <strong>Tools &gt; Theme Checklist.</strong> Theme developers check off each item that successfully passes a test. Themes need to pass all tests before they can be accepted into the <a title="http://wordpress.org/themes/" href="http://wordpress.org/themes/">WordPress theme directory</a>.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/ThemeChecklist.png" rel="prettyphoto[28095]"><img class="size-full wp-image-28195" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/ThemeChecklist.png?resize=790%2C461" alt="Check List Of Items To Go Through" /></a>Check List Of Items To Go Through
<p>If a test doesn&#8217;t pass, you can select the X and a small text area appears allowing you to write and save notes to that item. There are a total of 31 different tests ranging from Code Quality to Security. Each item has a link that takes users to a page on <a title="http://themechecklist.org/" href="http://themechecklist.org/">Themechecklist.org</a> with more information. Theme Checklist also contains the ability to import or export tests enabling users to collaborate on testing themes in different environments.</p>
<p>I used Theme Checklist to review the WP Tavern theme and it passed with flying colors.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/ThemeChecklistResults.png" rel="prettyphoto[28095]"><img class="size-full wp-image-28199" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/ThemeChecklistResults.png?resize=844%2C186" alt="Ravel Passes Tests With Flying Colors" /></a>WP Tavern Theme Passes With Flying Colors
<h2>Theme Checklist Is An Alternative Learning Experience</h2>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/ThemeCheckListFeaturedImage.png" rel="prettyphoto[28095]"><img class="size-full wp-image-28218" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/ThemeCheckListFeaturedImage.png?resize=638%2C298" alt="Theme Check List Featured Image" /></a>photo credit: <a href="https://www.flickr.com/photos/justin_case/6089119290/">Dr Case</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc/2.0/">cc</a>
<p>Although the plugin is not an exact match, Priday will do his best to keep the checklist in line with the official <a title="https://make.wordpress.org/docs/theme-developer-handbook/part-four-releasing-your-theme/theme-review-guidelines/" href="https://make.wordpress.org/docs/theme-developer-handbook/part-four-releasing-your-theme/theme-review-guidelines/">WordPress.org Theme Review Guidelines</a>.  &#8220;My goal is to make a kind of Dummies Guide to The Theme Review Guidelines&#8221; Priday said. &#8220;I’ve generally found that the theme review guidelines are really difficult for new theme developers to understand. I’ve tried to make something that makes all the requirements easier to understand.&#8221;</p>
<p>Theme Checklist is not meant to be a replacement for the <a title="https://wordpress.org/plugins/theme-check/" href="https://wordpress.org/plugins/theme-check/">Theme Check</a> plugin. Instead, it&#8217;s a collection of the most common snag points witnessed by Priday in the theme review queue. According to Priday, the queue has a five-week backlog. He hopes Theme Checklist helps decrease the queue and gets more theme developers to pass the initial review.</p>
<p>I understand why the theme review guidelines need to be thorough and specific. It&#8217;s the WordPress.org theme directory and they help create a consistent user experience. Plugins like Theme Checklist provide an alternative learning experience to accomplish the same goal. However, it has to remain on par with the official guidelines or else it could end up doing more harm than good.</p>
<p>Theme developers, is this a tool you see yourself using? What other tools do you use to increase the likelihood of passing a review on the first try?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Aug 2014 22:45:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:89:"WPTavern: Right Meow Plugin Puts The Super Troopers Cat Game Into Your WordPress Comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28201";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:222:"http://wptavern.com/right-meow-plugin-puts-the-super-troopers-cat-game-into-your-wordpress-comments?utm_source=rss&utm_medium=rss&utm_campaign=right-meow-plugin-puts-the-super-troopers-cat-game-into-your-wordpress-comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1976:"<p>Broken Lizard&#8217;s 2001 comedy &#8220;<a href="http://www.imdb.com/title/tt0247745/" target="_blank">Super Troopers</a>&#8221; introduced millions of viewers to the &#8220;cat game.&#8221; In the scene, a highway patrolman pulls Jim Gaffigan over and then tries to insert the word &#8220;meow&#8221; casually into the conversation as many times as possible. You remember that scene, right? If not, check it out here:</p>
<p><span class="embed-youtube"></span></p>
<h3>Am I Saying Meow?!</h3>
<p>Now, you can also have subliminal meow fun with <a href="http://wordpress.org/plugins/right-meow/" target="_blank">Right Meow</a>, a WordPress plugin that changes your comments section so that the word &#8220;now&#8221; automatically becomes &#8220;meow,&#8221; as shown below:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/meow.jpg" rel="prettyphoto[28201]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/meow.jpg?resize=766%2C461" alt="meow" class="aligncenter size-full wp-image-28205" /></a></p>
<p>The plugin was created by <a href="http://www.thomasleen.com/" target="_blank">Thomas Leen</a> and is his first submission on WordPress.org. It&#8217;s also available on <a href="https://github.com/tleen/wp-right-meow" target="_blank">GitHub</a>, should you want to suggest any changes. After testing it, I can confirm that it works as advertised to transform all instances of &#8220;now&#8221; to &#8220;meow&#8221; in the comments.</p>
<p>This may not be the most productive tool in the shed but it definitely adds a dash of frivolity and fun to your site by automatically trolling commenters with meows on your behalf. Please note that de-activating the plugin will return all your &#8220;meows&#8221; back to &#8220;nows.&#8221; If you want your comments to have a little more entertainment value, I recommend you <a href="http://wordpress.org/plugins/right-meow/" target="_blank">download</a> this plugin right meow.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Aug 2014 22:20:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"Alex King: The Race to the Bottom Benefits Platforms (not Developers)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=20713";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://alexking.org/blog/2014/08/12/race-to-bottom-platforms";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3773:"<p>There&#8217;s been a ton of recent conversation in the iOS world about the inability for most indie developers to create sustainable businesses through the iOS app store. In particular, these devs are talking about apps that require larger development efforts &#8211; they want to charge more than &#8220;impulse purchase&#8221; prices for these, and thus want trials, upgrade pricing, etc. to support that model. They want things to work they way they always have &#8211; I don&#8217;t blame them.</p>
<p>I think it&#8217;s worth considering who wins in this &#8220;race to the bottom&#8221;. In general, more stuff for free benefits consumers, which in turn benefits the platform.</p>
<p>&#8220;But wait!&#8221; the developers cry. &#8220;When the platform doesn&#8217;t support building more sophisticated apps, the consumers ultimately lose!&#8221; I know this argument, I&#8217;ve made it myself regarding the WordPress ecosystem. I was wrong.</p>
<p>Consumers have been well trained that they can expect incredible value for free. Sure, they may trade off their privacy and be subjected to ads, but they aren&#8217;t asked to fork over their cash directly.</p>
<p>VC-backed companies often contribute to the problem as well. As they clamor for users to their platforms, they give everything away &#8211; it&#8217;s so easy to flip the switch in the future and start the money pouring in. Or if that doesn&#8217;t work, they fold up shop and call it a day. Oops!</p>
<p>More complex apps <em>will get made</em>. They just won&#8217;t be built using the model that indie developers are used to.</p>
<p>There will be apps supported by alternative revenue streams. Some might have ads or sponsorships, some might mine and sell the data they produce, some (like Evernote and Dropbox) will be a gateway to a commercial service. People will figure out ways to get money out of a large enough user base, and apps will get built.</p>
<p>I&#8217;ve seen this happen in the WordPress ecosystem already. It&#8217;s a different beast because it&#8217;s an Open Source community, but it&#8217;s still an interesting parallel.</p>
<p>Basically this happened:</p>
<ol>
<li>A bunch of folks built stuff and released it all for free to a small community, largely consisting of fellow developers and tinkerers</li>
<li>A whole bunch more folks started using the platform and the community grew &#8211; it wasn&#8217;t just developers anymore, it was end users with expectations of support, etc.</li>
<li>Devs wanted to start monetizing the products they were providing</li>
<li>The platform didn&#8217;t provide the tools to make money in the way that the devs wanted -instead it invested in tools to promote free products</li>
<li>Eventually a variety of patterns arose to monetize both commercial and &#8220;free&#8221; products (subscription clubs with access to a bunch of different plugins/themes, free products with commercial add-ons, sponsorships and ads, products that were created to support hosting services, etc.)</li>
</ol>
<p>It&#8217;s not the  <img src="http://alexking.org/wp-content/themes/alexking.org-v3/smilies/ak_scare1.gif" alt=":scare:" class="wp-smiley" />  pure  <img src="http://alexking.org/wp-content/themes/alexking.org-v3/smilies/ak_scare2.gif" alt=":/scare:" class="wp-smiley" />  and direct approach of charging directly for the software, but it&#8217;s still developers writing code and making money.</p>
<p>The same thing is happening for iOS. There is money to be made. The platform and consumers are winning.</p>
<p>&#8220;Adapt or die&#8221; is our mantra for those business who are threatened by technology. We have little sympathy for newspapers, the music industry, etc. Perhaps it&#8217;s time to include software companies in that list.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Aug 2014 21:53:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:110:"WPTavern: Sprout Apps to Launch a Suite of WordPress-Powered Apps Targeted at Freelancers and Small Businesses";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:264:"http://wptavern.com/sprout-apps-to-launch-a-suite-of-wordpress-powered-apps-targeted-at-freelancers-and-small-businesses?utm_source=rss&utm_medium=rss&utm_campaign=sprout-apps-to-launch-a-suite-of-wordpress-powered-apps-targeted-at-freelancers-and-small-businesses";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6601:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/sprout-apps.png" rel="prettyphoto[28141]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/sprout-apps.png?resize=1025%2C464" alt="sprout-apps" class="aligncenter size-full wp-image-28152" /></a></p>
<p><a href="https://sproutapps.co/" target="_blank">Sprout Apps</a> will soon be launching a suite of business apps targeted at WordPress freelancers and small businesses. WordPress developer <a href="http://dancameron.org/" target="_blank">Daniel Cameron</a> is behind the project, which is centered around creating plugins that help business owners work more efficiently with WordPress. Sprout Apps aims to bring tasks like invoicing, estimates, and client tracking into the admin.</p>
<p>Cameron is the creator of <a href="http://smartecart.com/" target="_blank">Smart eCart</a>, a popular solution for daily deals, crowdfunding and social commerce. For five years he has supported and maintained the plugin, which was originally created for a client project. With the desire to venture out and create something new, Cameron has soft-launched Sprout Apps, starting with <a href="https://sproutapps.co/sprout-invoices/" target="_blank">Sprout Invoices</a>, now available for purchase.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/sprout-apps-invoices.png" rel="prettyphoto[28141]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/sprout-apps-invoices.png?resize=500%2C387" alt="sprout-apps-invoices" class="aligncenter size-large wp-image-28154" /></a></p>
<p>Sprout Invoicing is an idea that Cameron had cooked up year ago but was hesitant about, due to the fact that other plugin developers had explored it without much success.</p>
<p>&#8220;I went back to my original idea that I had years ago, which was a new invoicing app that solved all the problems I’ve had with Freshbooks and Harvest,&#8221; he said. &#8220;I knew there were already plugins out there which made me reluctant to pursue it further, regardless if their approach was wrong in my opinion.&#8221;</p>
<h3>Sprout Invoicing Aims to Help Streamline and Brand All Client Communications</h3>
<p>In order to sell his product, Cameron will have to convince business owners of the value in using a WordPress-powered invoicing system instead of the many standalone services. He&#8217;s counting on customers&#8217; desire to <a href="https://sproutapps.co/news/what-sprout-invoices-solves-for-freelancers-and-wordpress-sites/" target="_blank">streamline all aspects of their businesses</a>.</p>
<p>&#8220;Those other standalone services are silo’d, expensive, limiting and offer limited customization for brand integrity,&#8221; Cameron contends. &#8220;I want to streamline the estimate and invoicing process. Integrating it within the site that already has the estimate request (contact form) helps tremendously.&#8221;</p>
<p>In addition to fully automating estimating and invoicing, the app is designed to help business owners overcome the branding limitations of popular invoicing services, which generally only let you upload a logo to a subdomain. The freedom to fully brand all client communications is a big win for small businesses.</p>
<p>&#8220;Sprout Invoice notification emails are sent from your server and your from address,&#8221; Cameron said. &#8220;No more http://yoursite.harvestbooks.com with a &#8216;Powered by A Service I Pay For&#8217;.&#8221;</p>
<p>The invoicing app is built with business owner&#8217;s needs in mind. It&#8217;s packed full of dashboards and charts, summaries, and dynamic reporting that can be easily sorted and filtered in the WordPress admin.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/sprout-invoicing-charts.gif" rel="prettyphoto[28141]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/sprout-invoicing-charts.gif?resize=606%2C342" alt="sprout-invoicing-charts" class="aligncenter size-full wp-image-28159" /></a></p>
<p>Under the hood, Sprout Invoices is a WordPress plugin that uses custom post types, post meta and taxonomies for its data structure. &#8220;There are no additional tables created. The entire code base adheres to WordPress coding practices,&#8221; Cameron told the Tavern. &#8220;There&#8217;s hundreds of hooks and filters in SI, I want the entire app to be customizable and I anticipate it’s users to want more control than traditional WP users.&#8221;</p>
<p>The apps he <a href="https://sproutapps.co/coming-soon/" target="_blank">plans to build</a> are actually WordPress plugins, though he felt that apps was a more applicable term. &#8220;I didn’t want to go with &#8216;Sprout plugins,&#8217; for example, because I do have ideas that aren&#8217;t plugins and I didn&#8217;t want to box myself in,&#8221; he said. &#8220;I also think &#8216;Apps&#8217; is a better term for these larger premium plugins since they offer more than a traditional plugin that might filter post content.&#8221;</p>
<p>Sprout&#8217;s next app will be a CRM, followed by a team-based app. Cameron is also considering a PM app and a time tracker, depending on how sales go with the invoicing app. <a href="https://sproutapps.co/sprout-invoices/purchase/" target="_blank">Pricing</a> for Sprouts Invoicing is similar to that of popular invoicing services, with both monthly and yearly subscription rates at $5 and $9 respectively. Subscribers will receive updates, support and <a href="https://sproutapps.co/marketplace/" target="_blank">add-on</a> discounts. Cameron also plans to launch a free version of the invoicing app later this year.</p>
<p>Sprout Apps is built on the bold premise that your WordPress site can be more than just the marketing face of your business. It can also power the daily tasks of estimating work, billing clients, and charting progress. Cameron is aiming to provide all the business essentials with the added benefit of brand independence, a streamlined workflow, and total control. He&#8217;s got a big vision to create a superior suite of apps that will support the many freelancers and small businesses that make up a large segment of the WordPress ecosystem.</p>
<p><a href="https://sproutapps.co/" target="_blank">Sprout Apps</a> is currently in pre-launch mode and will officially launch at <a href="http://2014.la.wordcamp.org/" target="_blank">WordCamp LA</a> in early September. A <a href="https://sproutapps.co/demos/" target="_blank">live demo</a> of the app is available to preview and pre-launch subscribers will receive a discount at purchase.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Aug 2014 20:54:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"WPTavern: WP Site Care Acquires Audit WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28140";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:124:"http://wptavern.com/wp-site-care-acquires-audit-wp?utm_source=rss&utm_medium=rss&utm_campaign=wp-site-care-acquires-audit-wp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1996:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/MergeFeaturedImage.png" rel="prettyphoto[28140]"><img class="size-full wp-image-28143" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/MergeFeaturedImage.png?resize=678%2C252" alt="Merge Featured Image" /></a>photo credit: <a href="https://www.flickr.com/photos/rutlo/3743291132/">rutlo</a> &#8211; <a href="http://creativecommons.org/licenses/by/2.0/">cc</a>
<p><a title="http://auditwp.com/" href="http://auditwp.com/">Audit WP</a> has been acquired by <a title="http://www.wpsitecare.com" href="http://www.wpsitecare.com">WP Site Care</a>. According to <a title="http://www.wpsitecare.com/rob-neu-auditwp-join-wp-site-care/" href="http://www.wpsitecare.com/rob-neu-auditwp-join-wp-site-care/">the announcement</a>, Audit WP will operate under WP Site Care while continuing to offer specialized SEO services. Rob Neu, who owned and operated Audit WP, will become WP Site Care&#8217;s Director of Digital Strategy.</p>
<blockquote><p>Rob will oversee product development as well as making sure that our brand, services, and content align with our ultimate goal of providing top-tier WordPress support, and making WordPress an asset for our clients and people who are new to the platform.</p></blockquote>
<p>Neu hints that new SEO training packages are being worked on and a new plugin is being developed that will make it easier for WP Site Care customers to receive support from the WordPress dashboard.</p>
<p>Neu cites his passion for wanting to help businesses and individuals as one of the primary reasons for merging with WP Site Care. &#8220;At my core, the thing I like the most about everything that I do is that I’m able help people,&#8221; Neu said. &#8220;I want to help people improve their businesses, make more money, and be more successful.&#8221;</p>
<p>By joining WP Site Care, a business dedicated to helping people solve WordPress problems, he&#8217;s in a great position to do just that.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Aug 2014 18:26:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Matt: The Great Filter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43964";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:36:"http://ma.tt/2014/08/thegreatfilter/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:423:"<p><span class="embed-youtube"></span></p>
<p>This is about the Great Filter. (No, not <a href="http://akismet.com/">Akismet</a>.) It&#8217;s <a href="http://www.overcomingbias.com/2014/07/adam-ford-i-on-great-filter.html">Adam Ford and Robert Hanson</a> on existential risks to humanity, a continuation of the Fermi Paradox discussion I <a href="http://ma.tt/2014/07/the-fermi-paradox/">posted about the other day</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Aug 2014 16:39:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"Post Status: Audit WP to become part of WP Site Care with acquihire of Rob Neu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=7078";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:108:"http://www.poststat.us/wp-site-care-rob-neu/?utm_source=rss&utm_medium=rss&utm_campaign=wp-site-care-rob-neu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3669:"<p><img class="aligncenter size-large wp-image-7081" src="http://www.poststat.us/wp-content/uploads/2014/08/wp-site-care-752x341.jpg" alt="wp-site-care" width="627" height="284" /></p>
<p>Audit WP had a short, but interesting life span. Started by <a href="https://twitter.com/rob_neu">Rob Neu</a> and <a href="http://jacobking.com">Jacob King</a>, the site launched in February, and <a href="http://www.wpsitecare.com/rob-neu-auditwp-join-wp-site-care/">today it&#8217;s been acquired by WP Site Care</a>.</p>
<p>They made an early splash after their launch when Jacob <a href="http://auditwp.com/wp-engine-seo-failboat/">wrote a provocative post</a> about WP Engine&#8217;s SEO policies. Aside from that, they set out to productize technical SEO and general website strategy.</p>
<p>Their product was fairly successful, but they learned a valuable lesson; they were limiting their consulting opportunities for larger contracts by productizing &#8212; and therefore bracketing themselves at a relatively low price &#8212; their entry level services. That said, the product was quite good, and will now be part of WP Site Care&#8217;s offering in the form of a la carte SEO consulting, reports, and tools.</p>
<p>I had a call with Rob and Jacob a couple of months ago to demo their product, and because I needed real help from them. I&#8217;d been getting clobbered by Google, and they helped me identify some of the reasons why and set about a plan to fix it. I&#8217;m still working on it, and was very pleased with what they offered.</p>
<p><img class="aligncenter size-large wp-image-7079" src="http://www.poststat.us/wp-content/uploads/2014/08/audit-wp-overview-752x488.jpg" alt="audit-wp-overview" width="627" height="406" /></p>
<p>This and other tools were quite nice, and the value I got from a short call and report were pretty enormous. I think this will be a compelling product for WP Site Care&#8217;s services, and it will fit in well with their other offerings.</p>
<p>If you know Rob Neu and WP Site Care&#8217;s owner, Ryan Sullivan, then you already know they are friends. Rob joining WP Site Care doesn&#8217;t come as a shock, and seems to make sense all around. The two are already working on a separate side project together, called <a href="http://flagshipwp.com/">Flagship</a>, a theme company. Additionally, WP Site Care was a sponsor and often attendee on WP Bacon, Rob&#8217;s old podcast that also unfortunately bit the dust.</p>
<p>Rob and Ryan&#8217;s partnership for Flagship will remain separate, and Rob will be the Director of Digital Strategy for WP Site Care, now a team of five full time employees. Rob is a technical guy, and in addition to running strategy and marketing for WP Site Care, he&#8217;ll be working on refining some of their product offerings as well.</p>
<h3>What is WP Site Care anyway?</h3>
<p>I talked about WP Site Care and other <a title="The rise of WordPress maintenance services" href="http://www.poststat.us/rise-wordpress-maintenance-services/">WordPress maintenance services</a> earlier this year. Essentially it&#8217;s a combination of monthly maintenance and support, and a la carte services. It&#8217;s been a wildly successful and growing niche in the WordPress market, and there seem to be new companies popping up every day.</p>
<p>While I don&#8217;t know the degree of professionalism and expertise all of them have, I know that at least a few are very good at what they do. <a href="http://www.wpsitecare.com">WP Site Care</a> adding Rob and the variety of tools he brings to the table is a smart move for them to help set themselves apart in what is quickly becoming a crowded market.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Aug 2014 15:59:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WordPress.tv: Andrew Nacin: Keynote WordCamp Seattle 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=37318";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.tv/2014/08/12/andrew-nacin-keynote-wordcamp-seattle-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:634:"<div id="v-zRdcUwIL-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/37318/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/37318/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=37318&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/12/andrew-nacin-keynote-wordcamp-seattle-2014/"><img alt="Andrew Nacin: Keynote" src="http://videos.videopress.com/zRdcUwIL/video-29a2a6e399_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Aug 2014 15:40:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordPress.tv: WordCamp.org Site Tools Orientation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36428";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wordpress.tv/2014/08/12/wordcamp-org-site-tools-orientation/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:647:"<div id="v-GHzuucx2-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36428/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36428/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36428&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/12/wordcamp-org-site-tools-orientation/"><img alt="WordCamp.org Site Tools Orientation" src="http://videos.videopress.com/GHzuucx2/video-072a616795_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Aug 2014 15:20:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WordPress.tv: Fish Bowl Interactive Group Discussion";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=37400";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wordpress.tv/2014/08/12/fish-bowl-interactive-group-discussion/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:653:"<div id="v-eYcA9xgt-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/37400/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/37400/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=37400&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/12/fish-bowl-interactive-group-discussion/"><img alt="Fish Bowl Interactive Group Discussion" src="http://videos.videopress.com/eYcA9xgt/video-8612b0f944_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Aug 2014 15:15:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WPTavern: Add Reddit Style Commenting to WordPress With the Comment Popularity Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28045";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:214:"http://wptavern.com/add-reddit-style-commenting-to-wordpress-with-the-comment-popularity-plugin?utm_source=rss&utm_medium=rss&utm_campaign=add-reddit-style-commenting-to-wordpress-with-the-comment-popularity-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5010:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/comments.png" rel="prettyphoto[28045]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/comments.png?resize=984%2C455" alt="comments" class="aligncenter size-full wp-image-28128" /></a></p>
<p>Comments are an important aspect of your content and can serve as a vehicle for building community. WordPress site admins put in a hefty amount of work moderating comments and combating spam, just to <a href="http://wptavern.com/why-comments-still-matter" target="_blank">keep the conversation going</a> with comments open. With all that work invested, admins are looking for new ways to make comment interaction more valuable to those who are participating.</p>
<p>WordPress.com recently<a href="http://en.blog.wordpress.com/2014/08/07/introducing-comment-likes/" target="_blank"> added comment likes</a> to the delight of its users. Self-hosted WordPress site admins are hopeful that comment likes will find their way into Jetpack as well. If you&#8217;re interested in doing something more with comments, there are many plugins that help to promote interaction on your site.</p>
<p><a href="http://wordpress.org/plugins/comment-popularity/" target="_blank">Comment Popularity</a> is a new one that caught my eye. The plugin, created by <a href="https://twitter.com/paul_wp" target="_blank">Paul de Wouters</a> and his colleagues at <a href="http://hmn.md/" target="_blank">Human Made</a>, adds Reddit style commenting to WordPress. Registered site members can vote comments up or down to increase or decrease comment visibility.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/comment-popularity.jpg" rel="prettyphoto[28045]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/comment-popularity.jpg?resize=785%2C613" alt="comment-popularity" class="aligncenter size-full wp-image-28093" /></a></p>
<p>When the plugin is active, comments are sorted by weight (number of votes) in a descending order. Site members receive karma each time one of their comments is upvoted. Administrators have the option to attribute more weight to &#8220;expert&#8221; commenters by adding an expert label and additional points on user profiles.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/user-profile-comment-popularity-settings.jpg" rel="prettyphoto[28045]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/user-profile-comment-popularity-settings.jpg?resize=503%2C234" alt="user-profile-comment-popularity-settings" class="aligncenter size-full wp-image-28102" /></a></p>
<p>There&#8217;s also an option in the discussion panel for setting a default expert karma.</p>
<p>De Wouters and the folks at Human Made plan to support and maintain the plugin via the forums on WordPress.org. It was originally created for their client, CFO Publishing, who will be listed as a contributor on the next release.</p>
<p><strong>&#8220;I have a few ideas for integration with other plugins such as Stream, and our SaaS product WP Remote,&#8221;</strong> de Wouters said. I asked if he plans to add a UI for showing users their aggregate upvotes/ranks, and he confirmed that this is a possibility. &#8220;We&#8217;re already storing users voting activity, so it makes sense to offer an admin view for it,&#8221; he said. &#8220;Maybe a dashboard widget. Also, this is the kind of data we&#8217;d send to WP Remote or Stream.&#8221;</p>
<p>The plugin is currently restricted to registered users, as it doesn&#8217;t make much sense to leave it open for anonymous users to vote. &#8220;I do however plan to develop a drop in class that will allow users to authenticate themselves via social networks, which will reduce friction and still provide a way to identify a user with relative reliabilty,&#8221; de Wouters commented regarding future development plans. Although he wants to keep it simple and focused on one particular functionality, he is open to suggestions and contributions via the plugin&#8217;s <a href="https://github.com/humanmade/comment-popularity" target="_blank">GitHub repository</a>.</p>
<p>Comment Popularity gives registered users a way to weigh in on discussions without having to comment. Consequently, there is a greater incentive for readers to register for your site. It gives everyone a chance to influence the conversation. As users attribute value to comments they like, the best comments will float to the top. This saves readers from having to scroll through all the mediocre comments in order to find the highest quality responses.</p>
<p>If you&#8217;re looking for a new way to encourage interaction in your comments, the Comment Popularity plugin is simple and intuitive to use. It should work automatically with most standard comment forms. <a href="http://wordpress.org/plugins/comment-popularity/" target="_blank">Download</a> the plugin for free from WordPress.org and watch the GitHub repository for updates in development.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Aug 2014 00:14:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: Interview With Siobhan McKeown On The Future Of The WordPress Codex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28089";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:198:"http://wptavern.com/interview-with-siobhan-mckeown-on-the-future-of-the-wordpress-codex?utm_source=rss&utm_medium=rss&utm_campaign=interview-with-siobhan-mckeown-on-the-future-of-the-wordpress-codex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6798:"<p>If you use WordPress, chances are that you&#8217;ve run into the <a title="http://codex.wordpress.org/" href="http://codex.wordpress.org/">WordPress Codex</a>. The Codex is a community maintained collection of documentation, hooks, filters, best practices, and other information related to WordPress. With various <a title="http://make.wordpress.org/docs/handbook/projects/handbooks/" href="http://make.wordpress.org/docs/handbook/projects/handbooks/">handbook projects</a> underway, I&#8217;ve been wondering what the future of the Codex is. To find out, I got in touch with <a title="http://siobhanmckeown.com/" href="http://siobhanmckeown.com/">Siobhan McKeown</a>, who is a member of the <a title="http://make.wordpress.org/docs/" href="http://make.wordpress.org/docs/">documentation team</a>.</p>
<h2>Interview With Siobhan McKeown</h2>
<p><strong>Is the <a title="http://make.wordpress.org/docs/2013/06/19/docs-sprint-results-and-roadmap/" href="http://make.wordpress.org/docs/2013/06/19/docs-sprint-results-and-roadmap/">roadmap outlined here</a> still accurate and is it being followed? Is it still on time?</strong></p>
<p>The roadmap is still fairly accurate but it’s not on time. The number of contributors to docs is quite small and we’ve faced challenges around getting development work done and finding people to write. That said, the people who are involved are very dedicated and we’re slowly chipping away at things. We have made big strides forward, particularly in the area of inline docs (thanks <a title="http://profiles.wordpress.org/drewapicture" href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a> and <a title="https://profiles.wordpress.org/kpdesign" href="https://profiles.wordpress.org/kpdesign">Kim Parsell</a>) and in building <a title="https://developer.wordpress.org/reference/" href="https://developer.wordpress.org/reference/">developer.wordpress.org</a>.</p>
<p><strong>Ultimately, is the future of the Codex for it to disappear in favor of all the other documentation resources outlined in the roadmap?</strong></p>
<p>I would like for that to happen, but the decision doesn’t ultimately lie with me and it’s a discussion that we’ll have to return to once new documentation is in place.</p>
<p>Many free software projects in the early stages of their life use a wiki for their documentation. Over time, this can become out-of-date and inaccurate. As a project grows, it often out-grows a wiki, requiring more targeted documentation for both users and developers. <a href="https://support.mozilla.org/en-US/products/firefox">Firefox</a> and <a href="http://guides.rubyonrails.org/getting_started.html">Ruby on Rails</a> are good examples of FOSS projects that provide the types of targeted documentation that WordPress should be providing. I would hope that we can eventually get there ourselves, and keep the Codex as a historical archive.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/MozillaFireFoxTargetedSupport.png" rel="prettyphoto[28089]"><img class="size-full wp-image-28100" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/MozillaFireFoxTargetedSupport.png?resize=966%2C690" alt="Mozilla FireFox Targeted Documentation" /></a>Mozilla FireFox Targeted Documentation
<p><strong>Is it a waste of effort and energy for folks to continue to edit and update the Codex?</strong></p>
<p>No. For two reasons: First of all, while all of the docs work is going on, we need to ensure that the Codex stays up-to-date and accurate. It remains WordPress’ primary source of documentation and will be for some time, so contributions are still valuable there. When a new version of WordPress is released, the docs team usually does a sprint to get the Codex up-to-date.</p>
<p>Secondly, the main problem with the Codex is its navigation and structure. There’s a lot of good content in there mixed with a lot of out-of-date content. As we create new resources, we look at the content in the Codex and migrate good-quality content. If you fix a page in the Codex, then it’s likely that will end up somewhere in a new documentation resource.</p>
<p><strong>How can folks get involved with helping the roadmap move along?</strong></p>
<p>We particularly need help in two areas:</p>
<ol>
<li>Someone to help with ongoing development of <a title="http://wptavern.com/help-contribute-to-the-official-wordpress-developer-resource-by-testing-code-references" href="http://wptavern.com/help-contribute-to-the-official-wordpress-developer-resource-by-testing-code-references">WP-Parser</a> (the parser used to generate the Code Reference). A lot of things are on hold until we get someone helping there.</li>
<li>Writing the <a title="https://make.wordpress.org/docs/theme-developer-handbook/" href="https://make.wordpress.org/docs/theme-developer-handbook/">theme</a> and <a title="https://make.wordpress.org/docs/plugin-developer-handbook/" href="https://make.wordpress.org/docs/plugin-developer-handbook/">plugin developer</a> handbooks. These have been around for a long time and we really want to get them finished off so that we can move on to focusing on user support.</li>
</ol>
<h2>To Some, Google Is The WordPress Codex</h2>
<p>It may be the largest collection of WordPress documentation but I bet it doesn&#8217;t compare to the amount of WordPress content published on sites across the web. The paradox of publishing content on the Codex for the benefit of everyone versus a personal site for the benefit of a small audience has existed since it was created.</p>
<p>I think it would be awesome if content from sites like <a title="http://justintadlock.com/" href="http://justintadlock.com/">Justin Tadlock</a> found a home on the Codex but perhaps we don&#8217;t need one at all. Maybe all we need is Google. When I asked the Tavern&#8217;s Twitter followers what <a title="http://wptavern.com/7-aspects-of-wordpress-i-take-for-granted" href="http://wptavern.com/7-aspects-of-wordpress-i-take-for-granted">aspect of WordPress do they take for granted</a>, Jared Novack submitted the following answer:</p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/wptavern">@wptavern</a> You can type anything into google followed by "WordPress" and someone has already asked (and answered) it</p>
<p>&mdash; Jared Novack (@jaredNova) <a href="https://twitter.com/jaredNova/statuses/494322903739936768">July 30, 2014</a></p></blockquote>
<p></p>
<p>If the Codex ever goes offline, it will be a sad day. However, if it&#8217;s replaced with easy to navigate, skill level targeted documentation, with a solid code reference, I think a lot of users and developers will be happy with its replacement. Has the Codex saved your bacon once or twice? Let us know in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Aug 2014 22:20:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WPTavern: WPWeekly Episode 157 – Jeffro Tells His Story";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=28075&preview_id=28075";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:150:"http://wptavern.com/wpweekly-episode-157-jeffro-tells-his-story?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-157-jeffro-tells-his-story";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2274:"<p>The past 156 episodes of WordPress Weekly are filled with stories of people who are doing exciting things with WordPress. For this episode, I decided to try something a little different. I handed the show over to <a href="http://marcuscouch.com/" title="http://marcuscouch.com/">Marcus Couch</a>, who interviewed me. In the show, I describe how I became interested in computers and the events that lead me to where I am today. It&#8217;s a lengthy episode but one I hope you enjoy.</p>
<p>A reminder that beginning this week, WordPress Weekly will be recorded live on <strong>Wednesdays at 9:30 PM Eastern</strong>. The change better accommodates my schedule and the new day and time is also more compatible with guests.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/wordpress-3-9-2-fixes-security-vulnerabilities-users-strongly-encouraged-to-update" title="http://wptavern.com/wordpress-3-9-2-fixes-security-vulnerabilities-users-strongly-encouraged-to-update">WordPress 3.9.2 Fixes Security Vulnerabilities, Users Strongly Encouraged To Update</a><br />
<a href="http://wptavern.com/crowd-favorite-announces-chris-lema-as-new-cto" title="http://wptavern.com/crowd-favorite-announces-chris-lema-as-new-cto">Crowd Favorite Announces Chris Lema As New CTO</a><br />
<a href="http://wptavern.com/how-to-change-jetpack-accounts-without-losing-your-stats-or-subscribers" title="http://wptavern.com/how-to-change-jetpack-accounts-without-losing-your-stats-or-subscribers">How to Change Jetpack Accounts Without Losing Your Stats or Subscribers</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, August 13th 3 P.M. Eastern &#8211; Special Guest, Pippin Williamson</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #157:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Aug 2014 20:05:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: Underscores WordPress Starter Theme Adds Support for Sass";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=28061";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:178:"http://wptavern.com/underscores-wordpress-starter-theme-adds-support-for-sass?utm_source=rss&utm_medium=rss&utm_campaign=underscores-wordpress-starter-theme-adds-support-for-sass";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3186:"<p><a href="http://underscores.me/" target="_blank">Underscores</a> community project contributors <a href="http://themeshaper.com/2014/08/11/sass-comes-to-_s/" target="_blank">announced</a> today that the theme now includes support for <a href="http://sass-lang.com/" target="_blank">Sass</a>. The popular WordPress starter theme is an open source project maintained by Automattic, and many of its users requested Sass support, according to contributor Tammie Lister. &#8220;The community firstly asked for Sass. As Sass is in core, this makes sense. It was already part of most themers&#8217; workflow.&#8221;</p>
<p>If you visit <a href="http://underscores.me/" target="_blank">Underscores.me</a> and click on &#8220;Advanced Options&#8221;, you&#8217;ll now find that you can check a box to add Sass support:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/add-sass.jpg" rel="prettyphoto[28061]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/08/add-sass.jpg?resize=968%2C355" alt="add-sass" class="aligncenter size-full wp-image-28068" /></a></p>
<p>Lister emphasized in the announcement that support for Sass is included in a way that gives developers the freedom to use it as they please:</p>
<blockquote><p>Not everyone compiles or uses Sass the same, so _s shouldn&#8217;t force anyone to follow one path or another. In this sense, the Sass provided takes a pure approach, not requiring Compass or any other scripts.</p></blockquote>
<p>Sass support came about from a combination of numerous pull requests and forks of the project on GitHub. However, the project&#8217;s contributors do not wish to limit everyone to Sass and are open to other CSS preprocessors. <strong>&#8220;I&#8217;d still love to see a fork of Less for _s. We&#8217;re keen it opens up the way to other preprocessors,&#8221;</strong> Lister told the Tavern regarding the Sass support announced today.</p>
<p>Earlier this year, <a href="http://wptavern.com/wordpress-com-formally-opens-its-marketplace-to-theme-developers" target="_blank">WordPress.com formally opened up its marketplace to theme developers</a>. Theme submission <a href="http://developer.wordpress.com/themes/" target="_blank">guidelines</a> are fairly strict and developers are encouraged to use the _s theme for a head start. While many theme authors appreciate the ability to save time with mixins and variables, using a preprocessor is not required for submitting to WordPress.com.</p>
<p>Every WordPress themer has a unique workflow that may or may not involve a preprocessor, and the Underscores project contributors plan to respect that. <strong>&#8220;_s doesn&#8217;t tell you how to do things, it gives you a start. Anything we add to it should also do that,&#8221;</strong> Lister said.</p>
<p>The addition of Sass support marks another turning point for the project, as Lister notes that the <a href="https://github.com/Automattic/_s" target="_blank">GitHub repository</a> will now be used solely for development. If you want to use Underscores in a project, the team encourages you to download it directly from <a href="http://underscores.me/" target="_blank">Underscores.me</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Aug 2014 19:00:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"Post Status: Week in review: theme shops, hub and spoke, you can’t afford me, and much more";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"http://www.poststat.us/?p=7070";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:168:"http://www.poststat.us/week-review-theme-shops-hub-spoke-cant-afford-much/?utm_source=rss&utm_medium=rss&utm_campaign=week-review-theme-shops-hub-spoke-cant-afford-much";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:10330:"<p><img class="aligncenter size-large wp-image-6769" src="http://www.poststat.us/wp-content/uploads/2014/06/week-in-review1-752x300.jpg" alt="week-in-review" width="627" height="250" /></p>
<p>Welcome to the seventh “<a href="http://www.poststat.us/category/week-in-review/">Week in Review</a>” on Post Status, where I hope to offer up some of the things you may have missed in the last week or so. A whole bunch of good stuff to read from the last week, so let&#8217;s get to it:</p>
<h3>Theme shops sorted by their Alexa rank</h3>
<p>Devin Price has updated his <a href="http://wptheming.com/2014/08/theme-shop-directory-2014/">list of WordPress theme shops</a>, sorted by Alexa rank, for 2014. This is a really interesting list that&#8217;s sure to enlighten you to some theme shops that you&#8217;ve never heard of. I&#8217;ve referenced the 2013 version many times in the past. I&#8217;m glad Devin put time into doing this again.</p>
<p>Alexa isn&#8217;t a perfect way to rank theme shops, obviously, but it does offer good insight to see what average Joes unfamiliar with the WordPress theme landscape probably stumble upon as they search for WordPress themes. As Devin notes, the order of the top shops haven&#8217;t changed a whole lot in the past year, though pretty much all have gained ground, and WPMU Dev jumped all the way to number 1 from number 6.</p>
<h3>Hub and spoke versus distributed teams</h3>
<p>Jeff Chandler blogged about <a href="http://wptavern.com/how-crowd-favorite-utilizes-multiple-offices-and-a-distributed-work-force">Crowd Favorite&#8217;s <del>hub and spoke office</del> (<em>edit</em>: it&#8217;s actually a constellation model; no &#8220;hub&#8221;) model</a> (a central office + many smaller offices). Jake Goldman responded with his <a href="http://jakegoldman.me/2014/08/hub-and-spoke-vs-distributed/">case for a fully distributed team</a> (10up&#8217;s model). Both offer quality insight into how some of the larger WordPress consultancies operate.</p>
<h3>You can&#8217;t afford the plugin you want</h3>
<p>Chris Lema has written <a href="http://chrislema.com/cant-afford-wordpress-plugin-want/">an excellent post about custom plugin development</a>, and why you just can&#8217;t get the exact thing you want off the shelf (unless you get real lucky).</p>
<blockquote><p>That plugin that does everything you ever wanted? It doesn’t exist. And if it did, if someone built it, it would cost you thousands and thousands of dollars.</p>
<p>Because what you often describe isn’t a plugin. It’s a system.</p>
<p>And since you don’t want to connect several focused plugins, that each do the one thing they were made to do, you won’t really find the perfect plugin sitting there waiting for you.</p></blockquote>
<h3>SSL all the things</h3>
<p><span id="more-7070"></span></p>
<p><a href="http://searchengineland.com/google-starts-giving-ranking-boost-secure-httpsssl-sites-199446">Google spoke from on high</a>, declaring SSL to be a portion of their ranking algorithm. The SEOs and the SSL sellers rejoiced. Tim Nash has a nice<a href="https://timnash.co.uk/guessing-ssl-questions/"> primer on the nerdy details of SSL</a>. Joost de Valk also has some <a href="https://yoast.com/move-website-https-ssl/">practical tips for switching over to SSL</a>. And Zack Tollman has a great performance post over at The Theme Foundry <a href="https://thethemefoundry.com/blog/why-we-dont-use-a-cdn-spdy-ssl/">about SPDY and SSL</a>.</p>
<p>Now, all that said, seriously don&#8217;t freak out about SSL. It is great, that&#8217;s true, but just because Google says it&#8217;s part of their algorithm doesn&#8217;t mean you have to have it no matter what. Still though, having SSL enabled is probably a good thing for most sites, if you can afford it. Just be smart about it, and not purely reactionary to Google&#8217;s whims.</p>
<h3>Some hosts start to support Clef, the password-less login app</h3>
<p>SiteGround and three other hosts announced <a href="http://blog.getclef.com/protecting-users-default/">default support for Clef last week</a>. New installs on those platforms will enable the password-less login app. Clef works as a form of two-factor authentication, since you have to have your phone on you and scan the login screen to access the site.</p>
<p>It&#8217;s obviously past time to rely purely on passwords, so it&#8217;s good to see folks supporting Clef and other two-factor methods out of the box.</p>
<h3>WordPress-based portfolio templates, with Semplice</h3>
<p><a href="http://semplicelabs.com/">Semplice</a> is a WordPress portfolio template product, that&#8217;s still in development, but it&#8217;s definitely outside of the normal WordPress themes you see. I got in touch with the folks behind Semplice and they expect to have something ready in a few weeks for beta testing. It seems you can already buy it though, so I don&#8217;t know what that&#8217;s about. Either way, this may be a product to keep an eye on.</p>
<h3>The WordPress security &#8220;delimma&#8221;</h3>
<p>Tony Perez, CEO of Sucuri, write about <a href="http://tonyonsecurity.com/2014/08/09/the-dilemma-that-is-wordpress-security/">what he considers to be a delimma with WordPress security</a>. I don&#8217;t personally agree with some of Tony&#8217;s conclusions here, but they are worth reading, as your mileage may vary. He takes some folks&#8217; words to task (including my own), but I think in the end there is a more a difference in opinion on how to delivery the security message versus actual differences in implementing security measures.</p>
<p>I believe the Drupal vs WordPress method for highlighting last week&#8217;s security release was a reflection of how WordPress and Drupal communicate in general; WordPress said it as if speaking to regular site owners and Drupal spoke to developers. To me, making WordPress accessible to regular people is paramount &#8212; related to security issues or not.</p>
<p>I have a lot more I can say about this, but I have no desire to get in a pointless battle when I think we mostly agree on the goal, just not the message. But I do have one more note. Tony finishes his post with this:</p>
<blockquote><p>You can’t own 22% of the market and not expect issues. Is it best to fight it and blindly convince yourself that they don’t exist, or is it better to embrace it?</p></blockquote>
<p>I take exception to this. I don&#8217;t know anyone in a significant position within the WordPress project that takes such a &#8220;blind&#8221; stance. You can&#8217;t say WordPress core developers don&#8217;t take security seriously, because they absolutely do.</p>
<h3>Stellar and international payments</h3>
<p><a href="https://www.stellar.org/blog/introducing-stellar/">Stellar</a> is a &#8220;a decentralized protocol for sending and receiving money in any pair of currencies&#8221; with some big backers, like Stripe. Brent and Kirby, at Prospress, nerded out over Stellar when it launched, and then wrote up a <a href="http://prospress.com/will-stellar-finally-fix-international-payments/">great post about what this could mean for big savings in international eCommerce</a>.</p>
<h3>Tablesaw: responsive tables, by Filament Group</h3>
<p>Responsive tables are a pain. The Filament Group really attacked them with <a href="http://filamentgroup.com/lab/tablesaw.html">Tablesaw</a>. This is a really nice solution that you may consider for implementation with certain types of themes and websites.</p>
<h3>Comment likes on WordPress.com</h3>
<p><a href="http://en.blog.wordpress.com/2014/08/07/introducing-comment-likes/">WordPress.com has introduced comment likes</a>. This could be great for some sites with heavy amounts of comments, especially if they add some sorting options to bring good comments to the top. It might be a while before this one hits Jetpack though; apparently there are some technical challenges there.</p>
<h3>Get news of new WordPress.com themes</h3>
<p>Also in WordPress.com land, it turns out they aren&#8217;t really blogging about every theme release any more. So Luke McDonald put together a Twitter account to help keep you informed.</p>
<blockquote class="twitter-tweet" width="550"><p><a href="http://t.co/unxO0Vbjaz">http://t.co/unxO0Vbjaz</a> no longer promotes or announces Premium theme releases, so I spent some time to do this: <a href="https://t.co/Cenf4RW0Ed">https://t.co/Cenf4RW0Ed</a></p>
<p>&mdash; Luke McDonald (@thelukemcdonald) <a href="https://twitter.com/thelukemcdonald/statuses/497817557529665536">August 8, 2014</a></p></blockquote>
<p></p>
<h3>Why attend WordPress conferences (and updates on some of them)</h3>
<p>Andy Leverenz puts some good reasons together on the Elegant Themes blog about <a href="http://www.elegantthemes.com/blog/tips-tricks/wordpress-conferences-are-on-the-rise-why-you-should-attend">why you should attend WordPress conferences</a>, and he highlights some of those coming up.</p>
<p>Speaking of, if you want to go to PressNomics (the attendee list is awesome so far), <a href="http://pressnomics.com/2014/08/players-came-far-wide-attendees/">you better act soon</a>; that conference could sell out really soon.</p>
<p>The <a href="http://2014.sf.wordcamp.org/2014/08/04/say-hello-to-the-first-group-of-wordcamp-san-francisco-speakers/">first</a> and <a href="http://2014.sf.wordcamp.org/2014/08/07/our-second-group-of-wordcamp-san-francisco-speakers/">second</a> batches of WordCamp San Francisco speakers have been announced.</p>
<p><a href="http://2014.europe.wordcamp.org/">WordCamp Europe&#8217;s</a> speaker list is also dripping out, and it&#8217;s pretty amazing; that&#8217;s going to be an incredible event in Sofia.</p>
<p>Finally, if you&#8217;re in the south, WordCamp Birmingham (my local camp &#8212; #WPYall!) is this Saturday. It&#8217;s going to be a great time, and I hope I get to meet some of you there. You can still register, <a href="http://2014.birmingham.wordcamp.org/">so do that and come learn with us</a>.</p>
<hr />
<p>Have a great week, y&#8217;all. Make some news, and I&#8217;ll write it. Be on the lookout too, I&#8217;ve got my own news to share in the next month or so. Which means it&#8217;s probably a good time to subscribe to my <a title="Newsletter" href="http://www.poststat.us/newsletter/">newsletter</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Aug 2014 17:22:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WordPress.tv: Kailey Lampert: Hidden Treasures of WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=37206";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://wordpress.tv/2014/08/11/kailey-lampert-hidden-treasures-of-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:666:"<div id="v-rF09mHB3-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/37206/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/37206/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=37206&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/11/kailey-lampert-hidden-treasures-of-wordpress/"><img alt="Kailey Lampert: Hidden Treasures of WordPress" src="http://videos.videopress.com/rF09mHB3/video-92a0f142f5_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Aug 2014 15:24:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WordPress.tv: WordCamp Organizers’ Orientation Hangout Mar 19, 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=36465";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://wordpress.tv/2014/08/11/wordcamp-organizers-orientation-hangout-mar-19-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:687:"<div id="v-RWT5wtrZ-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/36465/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/36465/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=36465&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/11/wordcamp-organizers-orientation-hangout-mar-19-2014/"><img alt="WordCamp Organizers&#8217; Orientation Hangout Mar 19, 2014" src="http://videos.videopress.com/RWT5wtrZ/video-f088d9ed3d_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Aug 2014 15:17:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WordPress.tv: Peter Baran: Optimalizácia WordPress pre rýchlosť";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=37425";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wordpress.tv/2014/08/11/peter-baran-optimalizacia-wordpress-pre-rychlost-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:673:"<div id="v-zO6njcbX-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/37425/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/37425/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=wordpress.tv&blog=5089392&post=37425&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/08/11/peter-baran-optimalizacia-wordpress-pre-rychlost-2/"><img alt="Peter Baran: Optimalizácia WordPress pre rýchlosť" src="http://videos.videopress.com/zO6njcbX/video-97d1c51b93_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Aug 2014 15:14:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 16 Aug 2014 12:14:33 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"162845";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Sat, 16 Aug 2014 12:00:14 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 249";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911080210";}', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (267, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1408234473', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (268, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1408191273', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (269, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1408234473', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (270, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 16 Aug 2014 11:49:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"MailPoet Newsletters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wysija-newsletters/#post-32629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Dec 2011 17:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32629@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Send newsletters, post notifications or autoresponders from WordPress easily, and beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"MailPoet Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 10 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WP Super Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/wp-super-cache/#post-2572";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Nov 2007 11:40:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2572@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:73:"A very fast caching engine for WordPress that produces static html files.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Donncha O Caoimh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"21738@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"The easiest, most effective way to secure WordPress in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Fast Secure Contact Form";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/si-contact-form/#post-12636";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Aug 2009 01:20:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"12636@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"An easy and powerful form builder that lets your visitors send you email. Blocks all automated spammers. No templates to mess with.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Mike Challis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"5468@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Create a slick mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 16 Aug 2014 12:14:33 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Sat, 16 Aug 2014 12:24:26 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Sat, 16 Aug 2014 11:49:26 +0000";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20130911080210";}', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (271, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1408234473', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (272, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1408191273', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (273, '_transient_timeout_plugin_slugs', '1408277719', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (274, '_transient_plugin_slugs', 'a:7:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:19:"akismet/akismet.php";i:2;s:35:"backupwordpress/backupwordpress.php";i:3;s:37:"custom-content-type-manager/index.php";i:4;s:35:"event-organiser/event-organiser.php";i:5;s:9:"hello.php";i:6;s:55:"super-simple-contact-form/super-simple-contact-form.php";}', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (275, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1408234473', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (276, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2014/08/wordpress-4-0-beta-4/\'>WordPress 4.0 Beta 4</a> <span class="rss-date">August 15, 2014</span><div class="rssSummary">The fourth and likely final beta for WordPress 4.0 is now available. We’ve made more than 250 changes in the past month, including: Further improvements to the editor scrolling experience, especially when it comes to the second column of boxes. Better handling of small screens in the media library modals. A separate bulk selection mode […]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/time-to-move-on-from-the-is-wordpress-a-cms-debate?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=time-to-move-on-from-the-is-wordpress-a-cms-debate\' title=\'photo credit: Cesar Maia – cc In the realm of WordPress, there is a particular debate that has been going on for years on whether WordPress is a CMS or not. CMSCritic has a great article by Kaya Ismail, that explains why WordPress is a CMS (Whether You Like it or Not). It’s one of the most refreshing perspectives I’ve read on the subject. The definition of a\'>WPTavern: Time To Move On From The “Is WordPress A CMS” Debate</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/under-the-hood-of-semplice-a-new-portfolio-system-based-on-wordpress?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=under-the-hood-of-semplice-a-new-portfolio-system-based-on-wordpress\' title=\'Semplice has soft-launched its new WordPress-powered portfolio system. The commercial project popped up on our radar after debuting its extraordinary implementation of the WordPress content editor. Founded by German designers Michael Schmidt and Tobias van Schneider, Semplice is breaking onto the scene with high impact designs and its own radically simplifie\'>WPTavern: Under the Hood of Semplice: A New Portfolio System Based on WordPress</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/a-survival-guide-to-wordcamps-for-first-time-attendees?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=a-survival-guide-to-wordcamps-for-first-time-attendees\' title=\'photo credit: Steve Rhodes – cc WordCamps are excellent opportunities to learn WordPress and have of face-to-face interaction with a lot of different people. They can also be exhausting and possibly stressful for first timers. Carrie Dils has an awesome WordCamp Survival Guide filled with tips and information on how to get the most out of these events. Tip n\'>WPTavern: A Survival Guide To WordCamps For First Time Attendees</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'http://wordpress.org/plugins/better-wp-security/\' class=\'dashboard-news-plugin-link\'>iThemes Security (formerly Better WP Security)</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=better-wp-security&amp;_wpnonce=cf82427c4e&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'iThemes Security (formerly Better WP Security)\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (277, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1408202080', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (278, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"4587";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2848";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2785";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"2284";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2189";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1792";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1587";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1563";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1529";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1519";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1448";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1411";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1350";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1209";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1153";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1121";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:4:"1044";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:4:"1001";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"995";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"823";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"811";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"798";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"793";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"789";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"730";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"693";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"691";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"661";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"638";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"618";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"609";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"607";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"601";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"593";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"587";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"546";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"544";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"543";}s:5:"share";a:3:{s:4:"name";s:5:"Share";s:4:"slug";s:5:"share";s:5:"count";s:3:"536";}s:8:"security";a:3:{s:4:"name";s:8:"security";s:4:"slug";s:8:"security";s:5:"count";s:3:"534";}}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (279, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1408191318;s:7:"checked";a:7:{s:30:"advanced-custom-fields/acf.php";s:5:"4.3.8";s:19:"akismet/akismet.php";s:5:"3.0.1";s:35:"backupwordpress/backupwordpress.php";s:5:"2.6.2";s:37:"custom-content-type-manager/index.php";s:8:"0.9.7.13";s:35:"event-organiser/event-organiser.php";s:5:"2.8.3";s:9:"hello.php";s:3:"1.6";s:55:"super-simple-contact-form/super-simple-contact-form.php";s:5:"1.5.4";}s:8:"response";a:1:{s:35:"event-organiser/event-organiser.php";O:8:"stdClass":6:{s:2:"id";s:5:"27828";s:4:"slug";s:15:"event-organiser";s:6:"plugin";s:35:"event-organiser/event-organiser.php";s:11:"new_version";s:5:"2.8.4";s:3:"url";s:46:"https://wordpress.org/plugins/event-organiser/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/event-organiser.2.8.4.zip";}}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (280, 'hmbkp_default_path', '/Applications/MAMP/htdocs/muthetaatlarge.org/wp-content/backupwordpress-b5275fa4d6-backups', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (281, 'hmbkp_path', '/Applications/MAMP/htdocs/muthetaatlarge.org/wp-content/backupwordpress-b5275fa4d6-backups', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (282, 'hmbkp_schedule_default-1', 'a:4:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:19:"schedule_start_time";i:1408230000;s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (283, 'hmbkp_schedule_default-2', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1408244400;s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (284, 'hmbkp_plugin_version', '2.6.2', 'yes') ; 
INSERT INTO `wpMTAL_options` VALUES (285, '_transient_timeout_hmbkp_plugin_data', '1408277764', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (286, '_transient_hmbkp_plugin_data', 'O:8:"stdClass":20:{s:4:"name";s:15:"BackUpWordPress";s:4:"slug";s:15:"backupwordpress";s:7:"version";s:5:"2.6.2";s:6:"author";s:47:"<a href="http://hmn.md/">Human Made Limited</a>";s:14:"author_profile";s:32:"//profiles.wordpress.org/willmot";s:12:"contributors";a:7:{s:9:"humanmade";s:34:"//profiles.wordpress.org/humanmade";s:7:"willmot";s:32:"//profiles.wordpress.org/willmot";s:13:"pauldewouters";s:38:"//profiles.wordpress.org/pauldewouters";s:8:"joehoyle";s:33:"//profiles.wordpress.org/joehoyle";s:7:"mattheu";s:32:"//profiles.wordpress.org/mattheu";s:9:"tcrsavage";s:34:"//profiles.wordpress.org/tcrsavage";s:8:"cuvelier";s:0:"";}s:8:"requires";s:5:"3.7.3";s:6:"tested";s:5:"3.9.2";s:13:"compatibility";a:1:{s:5:"3.9.2";a:1:{s:5:"2.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}}s:6:"rating";d:91.7999999999999971578290569595992565155029296875;s:11:"num_ratings";i:723;s:7:"ratings";a:5:{i:5;i:590;i:4;i:66;i:3;i:13;i:2;i:8;i:1;i:46;}s:10:"downloaded";i:1121432;s:12:"last_updated";s:10:"2014-05-06";s:5:"added";s:10:"2007-09-02";s:8:"homepage";s:18:"http://bwp.hmn.md/";s:8:"sections";a:5:{s:11:"description";s:1433:"<p><a href="https://bwp.hmn.md/?utm_source=wordpress-org&#38;utm_medium=plugin-page&#38;utm_campaign=freeplugin">BackUpWordPress</a> will back up your entire site including your database and all your files on a schedule that suits you. Try it now to see how easy it is!</p>

<h4>Features</h4>

<ul>
<li>Super simple to use, no setup required.</li>
<li>Works in low memory, "shared host" environments.</li>
<li>Manage multiple schedules.</li>
<li>Option to have each backup file emailed to you.</li>
<li>Uses <code>zip</code> and <code>mysqldump</code> for faster backups if they are available.</li>
<li>Works on Linux &#38; Windows Server.</li>
<li>Exclude files and folders from your backups.</li>
<li>Good support should you need help.</li>
<li>Translations for Spanish, German, Chinese, Romanian, Russian, Serbian, Lithuanian, Italian, Czech, Dutch, French, Basque.</li>
</ul>

<h4>Help develop this plugin</h4>

<p>The BackUpWordPress plugin is hosted on GitHub, if you want to help out with development or testing then head over to <a href="https://github.com/humanmade/backupwordpress/" rel="nofollow">https://github.com/humanmade/backupwordpress/</a>.</p>

<h4>Translations</h4>

<p>We\'d also love help translating the plugin into more languages, if you can help then please contact <a href="mailto:support@hmn.md">support@hmn.md</a> or visit <a href="http://translate.hmn.md/" rel="nofollow">http://translate.hmn.md/</a>.</p>";s:12:"installation";s:460:"<ol>
<li>Install BackUpWordPress either via the WordPress.org plugin directory, or by uploading the files to your server.</li>
<li>Activate the plugin.</li>
<li>Sit back and relax safe in the knowledge that your whole site will be backed up every day.</li>
</ol>

<p>The plugin will try to use the <code>mysqldump</code> and <code>zip</code> commands via shell if they are available, using these will greatly improve the time it takes to back up your site.</p>";s:11:"screenshots";s:1083:"<ol>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=904756\' title=\'Click to view full-size screenshot 1\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-1.png?rev=904756\' alt=\'backupwordpress screenshot 1\' />
		</a>		<p>Manage multiple schedules.</p>
	</li>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=904756\' title=\'Click to view full-size screenshot 2\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-2.png?rev=904756\' alt=\'backupwordpress screenshot 2\' />
		</a>		<p>Choose your schedule, backup type, number of backups to keep and whether to recieve a notification email.</p>
	</li>
	<li>
		<a href=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=904756\' title=\'Click to view full-size screenshot 3\'>			<img class=\'screenshot\' src=\'//ps.w.org/backupwordpress/assets/screenshot-3.png?rev=904756\' alt=\'backupwordpress screenshot 3\' />
		</a>		<p>Easily manage exclude rules and see exactly which files are included and excluded from your backup.</p>
	</li>
</ol>";s:9:"changelog";s:32377:"<h4>2.6.2</h4>

<ul>
<li>Reverts a change to how the home path is calculated as it caused issues on installs where wp-config.php was stored outside of web root. Props to @mikelittle for the bug report.</li>
</ul>

<h4>2.6.1</h4>

<ul>
<li>Bump minimum WP requirement to 3.7.3, the latest security release on the 3.7 branch.</li>
<li>Fix an issues that could cause schedule times to fail to account for timezone differences.</li>
<li>Add a nonce check to the schedule settings.</li>
<li>Fix a possible JS warning when removing an exclude rule.</li>
<li>Our unit tests now run in PHP 5.2 again.</li>
</ul>

<h4>2.6</h4>

<ul>
<li>It\'s now possible to choose the time and day that your schedule will run on.</li>
<li>Introduces several new unit tests around schedule timings.</li>
<li>Fixes a bug that could cause the hourly schedule to run constantly.</li>
<li>Improved the layout of the Constants help panel.</li>
<li>If the backup root directory is unreadable then the plugin will no longer function.</li>
<li>Update the backups table match the standard WordPress table styles.</li>
<li>Improved styling for the settings dialogue.</li>
<li>Improved styling for the Server Info help tab.</li>
<li>/s/back ups/backups.</li>
<li>Remove Deprecated call to <code>screen_icon</code>.</li>
<li>Updated French translation.</li>
<li>Update the <code>WP CLI</code> command to use the new method for registering command.</li>
<li>Reload the schedules when re-setting up the default schedules so they show up straight away.</li>
<li>s/dpesnt\'t/doesn\'t.</li>
<li>Only show the estimated total schedule size when editing an existing schedule.</li>
<li>Stop stripping 0 from the minutes on hourly backups so that backups at 10 (&#38; 20, etc.) past the hour correctly show.</li>
<li>Disable buttons whilst ajax requests are running.</li>
<li>Move spinners outside the buttons as they didn\'t look very good inside.</li>
<li>Improve the detection of the home path on multisite installs which have WordPress in a subdirectory.</li>
<li>Track the time that the running backup is started and display how long a backup has been running for.</li>
<li>Fix an issue that meant it wasn\'t possible to run multiple manual backups at the same time.</li>
<li>Many other minor improvements.</li>
</ul>

<h4>2.5</h4>

<ul>
<li>BackUpWordPress now requires WordPress 3.7.1 as a minimum.</li>
<li>Remove some old back-compat code that was required because we supported older WP versions.</li>
<li>It\'s now possible to change the email address that notification emails are sent from using the <code>hmbkp_from_email</code> filter.</li>
<li>The spinner is now retina!</li>
<li>Close the PHP Session before starting the backup process to work around the 1 request per session issue. Backup status will now work on sites which happen to call <code>session_start</code>.</li>
<li>Pass <code>max_execution_time</code> and the BackUpWordPress Plugin version back to support. * Include the users real name in support requests</li>
<li>Stop passing <code>$_SERVER</code> with support requests as it can contain things like <code>.htaccess</code> passwords on some server configurations.</li>
<li>Improve the display of the server info in the enable support popup.</li>
<li>New screenshots</li>
<li>Use <code>wp_safe_redirect</code> for internal redirects.</li>
<li>Use <code>wp_is_writable</code> instead of <code>is_writable</code>.</li>
</ul>

<h4>2.4.2</h4>

<ul>
<li>In WordPress Multisite the backups admin page is now located in Network admin instead of the wp-admin of the main site.</li>
<li>Fixed an issue with the new intercom support integration that could cause loading the backups page to timeout</li>
<li>Fixed 3 stray PHP warnings.</li>
<li>BackUpWordPress will now always be loaded before any BackUpWordPress Extensions.</li>
<li>Fixed an issue that could cause a long modal (excludes) to show underneath the WP admin bar.</li>
</ul>

<h4>2.4.1</h4>

<ul>
<li>Add missing colorbox images</li>
</ul>

<h4>2.4</h4>

<ul>
<li>Support for new premium extensions for storing backups in a variety of online services.</li>
<li>Exclude the WP DB Manager backups and WP Super Cache cache directories by default.</li>
<li>We now use Intercom to offer support directly from within the plugin, opt-in of course.</li>
<li>More i18n fixes / improvements.</li>
<li>We no longer show download links if your backups directory isn\'t web accessible.</li>
<li>Fix a bug that caused the plugin activation and deactivation hooks from firing.</li>
<li>Correctly handle <code>MYSQL TIMESTAMP</code> columns in database dumps.</li>
<li><code>mysqldump</code> and <code>zip</code> are now correctly recognised on SmartOS.</li>
<li>Schedule names are now translatable.</li>
<li>Avoid having to re-calculate the filesize when a schedules type is set.</li>
<li>Compatibility with WordPress 3.8</li>
</ul>

<h4>2.3.2</h4>

<ul>
<li>Correct version number.</li>
</ul>

<h4>2.3.1</h4>

<ul>
<li>Fix a PHP strict error.</li>
<li>Save and close as separate buttons.</li>
<li>Fix bug that caused multiple notification emails.</li>
<li>Fixes typo in database option name.</li>
<li>Updated translations.</li>
<li>Improve PHP docblocks.</li>
<li>Make schedules class a singleton.</li>
<li>Exclude popular backup plugin folders by default.</li>
<li>Exclude version control folders by default.</li>
<li>Fix broken localisation.</li>
<li>Use <code>wp_safe_redirect</code> instead of <code>wp_redirect</code> for internal form submissions</li>
<li></li>
</ul>

<h4>2.3</h4>

<ul>
<li>Replace Fancybox with Colorbox as Fancybox 2 isn\'t GPL compatible.</li>
<li>Use the correct <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant consistently in the help section.</li>
<li>Correct filename for some mis-named translation files.</li>
<li>Show the total estimated disk space a schedule could take up (max backups * estimated site size).</li>
<li>Fix a typo (your -&#62; you\'re).</li>
<li>Use the new time Constants and define backwords compatible ones for &#62; than 3.5.</li>
<li>Play nice with custom cron intervals.</li>
<li>Main plugin file is now <code>backupwordpress.php</code> for consistency.</li>
<li>Add Paul De Wouters (<code>pauldewouters</code>) as a contributor, welcome Paul!</li>
<li>Don\'t remove non-backup files from custom backup paths.</li>
<li>Fix a regression where setting a custom path which didn\'t exist could cause you to lose existing backups.</li>
<li>When moving paths only move backup files.</li>
<li>Make some untranslatable strings translatable.</li>
<li>Don\'t allow a single schedule to run in multiple threads at once, should finally fix edge case issues where some load balancer / proxies were causing multiple backups per run.</li>
<li>Only highlight the <code>HMBKP_SCHEDULE_TIME</code> constant in help if it\'s not the default value.</li>
<li>Remove help text for deprecated <code>HMBKP_EMAIL</code>.</li>
<li>Default to allways specificing <code>--single-transaction</code> when using <code>mysqldump</code> to backup the database, can be disabled by setting the <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code> to <code>false</code>.</li>
<li>Silence a <code>PHP Warning</code> if <code>mysql_pconnect</code> has been disabled.</li>
<li>Ensure dot directories <code>.</code> &#38; <code>..</code> are always skipped when looping the filesystem.</li>
<li>Work around a warning in the latest version of MySQL when using the <code>-p</code> flag with <code>mysqldunmp</code>.</li>
<li>Fix issues on IIS that could cause the root directory to be incorrectly calculated.</li>
<li>Fix an issue on IIS that could cause the download backup url to be incorrect.</li>
<li>Fix an issue on IIS that could mean your existing backups are lost when moving backup directory.</li>
<li>Avoid a <code>PHP FATAL ERROR</code> if the <code>mysql_set_charset</code> doesn\'t exist.</li>
<li>All unit tests now pass under IIS on Windows.</li>
<li>Prefix the backup directory with <code>backupwordpress-</code> so that it\'s easier to identify.</li>
<li>Re-calculate the backup directory name on plugin update and move backups.</li>
<li>Fix some issues with how <code>HMBKP_SECURE_KEY</code> was generated.</li>
</ul>

<h4>2.2.4</h4>

<ul>
<li>Fix a fatal error on PHP 5.2, sorry! (again.)</li>
</ul>

<h4>2.2.3</h4>

<ul>
<li>Fix a parse error, sorry!</li>
</ul>

<h4>2.2.2</h4>

<ul>
<li>Fix a fatal error when uninstalling.</li>
<li>Updated translations for Brazilian, French, Danish, Spanish, Czech, Slovakian, Polish, Italian, German, Latvian, Hebrew, Chinese &#38; Dutch.</li>
<li>Fix a possible notice when using the plugin on a server without internet access.</li>
<li>Don\'t show the wp-cron error message when <code>WP_USE_ALTERNATE_CRON</code> is defined as true.</li>
<li>Ability to override the max attachment size for email notifications using the new <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant.</li>
<li>Nonce some ajax request.</li>
<li>Silence warnings created if <code>is_executable</code>, <code>escapeshellcmd</code> or <code>escapeshellarg</code> are disabled.</li>
<li>Handle situations where the mysql port is set to something wierd.</li>
<li>Fallback to <code>mysql_connect</code> on system that disable <code>mysql_pconnect</code>.</li>
<li>You can now force the <code>--single-transaction</code> param when using <code>mysqldump</code> by defining <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code>.</li>
<li>Unit tests for <code>HM_Backup::is_safe_mode_available()</code>.</li>
<li>Silence possible PHP Warnings when unlinking files.</li>
</ul>

<h4>2.2.1</h4>

<ul>
<li>Stop storing a list of unreadable files in the backup warnings as it\'s too memory intensive.</li>
<li>Revert the custom <code>RecursiveDirectoryIterator</code> as it caused an infinite loop on some servers.</li>
<li>Show all errors and warnings in the popup shown when a manual backup completes.</li>
<li>Write the .backup_error and .backup_warning files everytime an error or warning happens instead of waiting until the end of the backups process.</li>
<li>Fix a couple of <code>PHP E_STRICT</code> notices.</li>
<li>Catch more errors during the manual backup process and expose them to the user.</li>
</ul>

<h4>2.2</h4>

<ul>
<li>Don\'t repeatedly try to create the backups directory in the <code>uploads</code> if <code>uploads</code> isn\'t writable.</li>
<li>Show the correct path in the warning message when the backups path can\'t be created.</li>
<li>Include any user defined auth keys and salts when generating the HMBKP_SECURE_KEY.</li>
<li>Stop relying on the built in WordPress schedules as other plugins can mess with them.</li>
<li>Delete old backups everytime the backups page is viewed in an attempt to ensure old backups are always cleaned up.</li>
<li>Improve modals on small screens and mobile devices.</li>
<li>Use the retina spinner on retina screens.</li>
<li>Update buttons to the new 3.5 style.</li>
<li>Fix a possible fatal error caused when a symlink points to a location that is outside an <code>open_basedir</code> restriction.</li>
<li>Fix an issue that could cause backups using PclZip with a custom backups path to fail.</li>
<li>Security hardening by improving escaping, sanitizitation and validation.</li>
<li>Increase the timeout on the ajax cron check, should fix issues with cron errors showing on slow sites.</li>
<li>Only clear the cached backup filesize if the backup type changes.</li>
<li>Add unit tests for all the schedule recurrences.</li>
<li>Fix an issue which could cause weekly and monthly schedules to fail.</li>
<li>Add an <code>uninstall.php</code> file which removes all BackUpWordPress data and options.</li>
<li>Catch a possible fatal error in <code>RecursiveDirectoryIterator::hasChildren</code>.</li>
<li>Fix an issue that could cause mysqldump errors to be ignored thus causing the backup process to use an incomplete mysqldump file.</li>
</ul>

<h4>2.1.3</h4>

<ul>
<li>Fix a regression in <code>2.1.2</code> that broke previewing and adding new exclude rules.</li>
</ul>

<h4>2.1.2</h4>

<ul>
<li>Fix an issue that could stop the settings panel from closing on save on servers which return <code>\'0\'</code> for ajax requests.</li>
<li>Fix an issue that could cause the backup root to be set to <code>/</code> on sites with <code>site_url</code> and <code>home</code> set to different domains.</li>
<li>The mysqldump fallback function will now be used if <code>mysqldump</code> produces an empty file.</li>
<li>Fix a possible PHP <code>NOTICE</code> on Apache servers.</li>
</ul>

<h4>2.1.1</h4>

<ul>
<li>Fix a possible fatal error when a backup schedule is instantiated outside of wp-admin.</li>
<li>Don\'t use functions from misc.php as loading it too early can cause fatal errors.</li>
<li>Don\'t hardcode an English string in the JS, use the translated string instead.</li>
<li>Properly skip dot files, should fix fatal errors on systems with <code>open_basedir</code> restrictions.</li>
<li>Don\'t call <code>apache_mod_loaded</code> as it caused wierd DNS issue on some sites, use <code>global $is_apache</code> instead.</li>
<li>Fix a possible double full stop at the end of the schedule sentence.</li>
<li>Minor code cleanup.</li>
</ul>

<h4>2.1</h4>

<ul>
<li>Stop blocking people with <code>safe_mode = On</code> from using the plugin, instead just show a warning.</li>
<li>Fix possible fatal error when setting schedule to monthly.</li>
<li>Fix issues with download backup not working on some shared hosts.</li>
<li>Fix issuses with download backup not working on sites with strange characters in the site name.</li>
<li>Fix a bug could cause the update actions to fire on initial activation.</li>
<li>Improved reliability when changing backup paths, now with Unit Tests.</li>
<li>Generate the lists of excluded, included and unreadable files in a more memory efficient way, no more fatal errors on sites with lots of files.</li>
<li>Bring back .htaccess protection of the backups directory on <code>Apache</code> servers with <code>mod_rewrite</code> enabled.</li>
<li>Prepend a random string to the backups directory to make it harder to brute force guess.</li>
<li>Fall back to storing the backups directoy in <code>uploads</code> if <code>WP_CONTENT_DIR</code> isn\'t writable.</li>
<li>Attempt to catch <code>E_ERROR</code> level errors (Fatal errors) that happen during the backup process and offer to email them to support.</li>
<li>Provide more granular status messages during the backup process.</li>
<li>Show a spinner next to the schedule link when a backup is running on a schedule which you are not currently viewing.</li>
<li>Improve the feedback when removing an exclude rule.</li>
<li>Fix an issue that could cause an exclude rule to be marked as default when it in-fact isn\'t, thus not letting it be deleted.</li>
<li>Add a line encouraging people to rate the plugin if they like it.</li>
<li>Change the support line to point to the FAQ before recommending they contact support.</li>
<li>Fix the link to the "How to Restore" post in the FAQ.</li>
<li>Some string changes for translators, 18 changed strings.</li>
</ul>

<h4>2.0.6</h4>

<ul>
<li>Fix possible warning on plugin activation if the sites cron option is empty.</li>
<li>Don\'t show the version warning in the help for Constants as that comes from the current version.</li>
</ul>

<h4>2.0.5</h4>

<ul>
<li>Re-setup the cron schedules if they get deleted somehow.</li>
<li>Delete all BackUpWordPress cron entries when the plugin is deactivated.</li>
<li>Introduce the <code>HMBKP_SCHEDULE_TIME</code> constant to allow control over the time schedules run.</li>
<li>Make sure the schedule times and times of previous backups are shown in local time.</li>
<li>Fix a bug that could cause the legacy backup schedule to be created on every update, not just when going from 1.x to 2.x.</li>
<li>Improve the usefulness of the <code>wp-cron.php</code> response code check.</li>
<li>Use the built in <code>site_format</code> function for human readable filesizes instead of defining our own function.</li>
</ul>

<h4>2.0.4</h4>

<ul>
<li>Revert the change to the way the plugin url and path were calculated as it caused regressions on some systems.</li>
</ul>

<h4>2.0.3</h4>

<ul>
<li>Fix issues with scheduled backups not firing in some cases.</li>
<li>Better compatibility when the WP Remote plugin is active alongside BackUpWordPress.</li>
<li>Catch and display more WP Cron errors.</li>
<li>BackUpWordPress now fails to activate on WordPress 3.3.2 and below.</li>
<li>Other minor fixes and improvements.</li>
</ul>

<h4>2.0.2</h4>

<ul>
<li>Only send backup failed emails if the backup actually failed.</li>
<li>Turn off the generic "memory limit probably hit" message as it was showing for too many people.</li>
<li>Fix a possible notice when the backup running filename is blank.</li>
<li>Include the <code>wp_error</code> response in the cron check.</li>
</ul>

<h4>2.0.1</h4>

<ul>
<li>Fix fatal error on PHP 5.2.</li>
</ul>

<h4>2.0</h4>

<ul>
<li>Ability to have multiple schedules with separate settings &#38; excludes per schedule.</li>
<li>Ability to manage exclude rules and see exactly which files are included and excluded.</li>
<li>Fix an issue with sites with an <code>open_basedir</code> restriction.</li>
<li>Backups should now be much more reliable in low memory environments.</li>
<li>Lots of other minor improvements and bug fixes.</li>
</ul>

<h4>1.6.9</h4>

<ul>
<li>Updated and improved translations across the board - props @elektronikLexikon.</li>
<li>German translation - props @elektronikLexikon.</li>
<li>New Basque translation - props Unai ZC.</li>
<li>New Dutch translation - Anno De Vries.</li>
<li>New Italian translation.</li>
<li>Better support for when WordPress is installed in a sub directory - props @mattheu</li>
</ul>

<h4>1.6.8</h4>

<ul>
<li>French translation props Christophe - <a href="http://catarina.fr" rel="nofollow">http://catarina.fr</a>.</li>
<li>Updated Spanish Translation props DD666 - <a href="https://github.com/radinamatic" rel="nofollow">https://github.com/radinamatic</a>.</li>
<li>Serbian translation props StefanRistic - <a href="https://github.com/StefanRistic" rel="nofollow">https://github.com/StefanRistic</a>.</li>
<li>Lithuanian translation props Vincent G - <a href="http://www.Host1Free.com" rel="nofollow">http://www.Host1Free.com</a>.</li>
<li>Romanian translation.</li>
<li>Fix conflict with WP Remote.</li>
<li>Fix a minor issue where invalid email address\'s were still stored.</li>
<li>The root path that is backed up can now be controlled by defining <code>HMBKP_ROOT</code>.</li>
</ul>

<h4>1.6.7</h4>

<ul>
<li>Fix issue with backups being listed in reverse chronological order.</li>
<li>Fix issue with newest backup being deleted when you hit your max backups limit.</li>
<li>It\'s now possible to have backups sent to multiple email address\'s by entering them as a comma separated list.</li>
<li>Fix a bug which broke the ability to override the <code>mysqldump</code> path with <code>HMBKP_MYSQLDUMP_PATH</code>.</li>
<li>Use <code>echo</code> rather than <code>pwd</code> when testing <code>shell_exec</code> as it\'s supported cross platform.</li>
<li>Updated Spanish translation.</li>
<li>Fix a minor spelling mistake.</li>
<li>Speed up the manage backups page by caching the FAQ data for 24 hours.</li>
</ul>

<h4>1.6.6</h4>

<ul>
<li>Fix backup path issue with case sensitive filesystems.</li>
</ul>

<h4>1.6.5</h4>

<ul>
<li>Fix an issue with emailing backups that could cause the backup file to not be attached.</li>
<li>Fix an issue that could cause the backup to be marked as running for ever if emailing the backup <code>FATAL</code> error\'d.</li>
<li>Never show the running backup in the list of backups.</li>
<li>Show an error backup email failed to send.</li>
<li>Fix possible notice when deleting a backup file which doesn\'t exist.</li>
<li>Fix possible notice on older versions of <code>PHP</code> which don\'t define <code>E_DEPRECATED</code>.</li>
<li>Make <code>HMBKP_SECURE_KEY</code> override-able.</li>
<li>BackUpWordPress should now work when <code>ABSPATH</code> is <code>/</code>.</li>
</ul>

<h4>1.6.4</h4>

<ul>
<li>Don\'t show warning message as they cause to much panic.</li>
<li>Move previous methods errors to warnings in fallback methods.</li>
<li>Wrap <code>.htaccess</code> rewrite rules in if <code>mod_rewrite</code> check.</li>
<li>Add link to new restore help article to FAQ.</li>
<li>Fix issue that could cause "not using latest stable version" message to show when you were in-fact using the latest version.</li>
<li>Bug fix in <code>zip command</code> check that could cause an incorrect <code>zip</code> path to be used.</li>
<li>Detect and pass <code>MySQL</code> port to <code>mysqldump</code>.</li>
</ul>

<h4>1.6.3</h4>

<ul>
<li>Don\'t fail archive verification for errors in previous archive methods.</li>
<li>Improved detection of the <code>zip</code> and <code>mysqldump</code> commands.</li>
<li>Fix issues when <code>ABSPATH</code> is <code>/</code>.</li>
<li>Remove reliance on <code>SECURE_AUTH_KEY</code> as it\'s often not defined.</li>
<li>Use <code>warning()</code> not <code>error()</code> for issues reported by <code>zip</code>, <code>ZipArchive</code> &#38; <code>PclZip</code>.</li>
<li>Fix download zip on Windows when <code>ABSPATH</code> contains a trailing forward slash.</li>
<li>Send backup email after backup completes so that fatal errors in email code don\'t stop the backup from completing.</li>
<li>Add missing / to <code>PCLZIP_TEMPORARY_DIR</code> define.</li>
<li>Catch and display errors during <code>mysqldump</code>.</li>
</ul>

<h4>1.6.2</h4>

<ul>
<li>Track <code>PHP</code> errors as backup warnings not errors.</li>
<li>Only show warning message for <code>PHP</code> errors in BackUpWordPress files.</li>
<li>Ability to dismiss the error / warning messages.</li>
<li>Disable use of <code>PclZip</code> for full archive checking for now as it causes memory issues on some large sites.</li>
<li>Don\'t delete "number of backups" setting on update.</li>
<li>Better handling of multibyte characters in archive and database dump filenames.</li>
<li>Mark backup as running and increase callback timeout to <code>500</code> when firing backup via ajax.</li>
<li>Don\'t send backup email if backup failed.</li>
<li>Filter out duplicate exclude rules.</li>
</ul>

<h4>1.6.1</h4>

<ul>
<li>Fix fatal error on PHP =&#60; 5.3</li>
</ul>

<h4>1.6</h4>

<ul>
<li>Fixes issue with backups dir being included in backups on some Windows Servers.</li>
<li>Consistent handling of symlinks across all archive methods (they are followed).</li>
<li>Use .htaccess rewrite cond authentication to allow for secure http downloads of backup files.</li>
<li>Track errors and warnings that happen during backup and expose them through admin.</li>
<li>Fire manual backups using ajax instead of wp-cron, <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> is no longer needed and has been removed.</li>
<li>Ability to cancel a running backup.</li>
<li>Zip files are now integrity checked after every backup.</li>
<li>More robust handling of failed / corrupt zips, backup process now fallsback through the various zip methods until one works.</li>
<li>Use <code>mysql_query</code> instead of the depreciated <code>mysql_list_tables</code>.</li>
</ul>

<h4>1.5.2</h4>

<ul>
<li>Better handling of unreadable files in ZipArchive and the backup size calculation.</li>
<li>Support for wp-cli, usage: <code>wp backup [--files_only] [--database_only] [--path&#60;dir&#62;] [--root&#60;dir&#62;] [--zip_command_path=&#60;path&#62;] [--mysqldump_command_path=&#60;path&#62;]</code></li>
</ul>

<h4>1.5.1</h4>

<ul>
<li>Better detection of <code>zip</code> command.</li>
<li>Don\'t delete user settings on update / deactivate.</li>
<li>Use <code>ZipArchive</code> if <code>zip</code> is not available, still falls back to <code>PclZip</code> if neither <code>zip</code> nor <code>ZipArchive</code> are installed.</li>
<li>Better exclude rule parsing, fixes lots of edge cases, excludes now pass all 52 unit tests.</li>
<li>Improved the speed of the backup size calculation.</li>
</ul>

<h4>1.5</h4>

<ul>
<li>Re-written core backup engine should be more robust especially in edge case scenarios.</li>
<li>48 unit tests for the core backup engine, yay for unit tests.</li>
<li>Remove some extraneous status information from the admin interface.</li>
<li>Rename Advanced Options to Settings</li>
<li>New <code>Constant</code> <code>HMBKP_CAPABILITY</code> to allow the default <code>add_menu_page</code> capability to be changed.</li>
<li>Suppress possible filemtime warnings in some edge cases.</li>
<li>3.3 compatability.</li>
<li>Set proper charset of MySQL backup, props valericus.</li>
<li>Fix some inconsistencies between the estimated backup size and actual backup size when excluding files.</li>
</ul>

<h4>1.4.1</h4>

<ul>
<li>1.4 was incorrectly marked as beta.</li>
</ul>

<h4>1.4</h4>

<ul>
<li>Most options can now be set on the backups page, all options can still be set by defining them as <code>Constants</code>.</li>
<li>Russian translation, props valericus.</li>
<li>All dates are now translatable.</li>
<li>Fixed some strings which weren\'t translatable.</li>
<li>New Constant <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> which enable you to disable the use of <code>wp_cron</code> for manual backups.</li>
<li>Manual backups now work if <code>DISABLE_WP_CRON</code> is defined as <code>true</code>.</li>
</ul>

<h4>1.3.2</h4>

<ul>
<li>Spanish translation</li>
<li>Bump PHP version check to 5.2.4</li>
<li>Fallback to PHP mysqldump if shell_exec fails for any reason.</li>
<li>Silently ignore unreadable files / folders</li>
<li>Make sure binary data is properly exported when doing a mysqldump</li>
<li>Use 303 instead of 302 when redirecting in the admin.</li>
<li>Don\'t <code>set_time_limit</code> inside a loop</li>
<li>Use WordPress 3.2 style buttons</li>
<li>Don\'t pass an empty password to mysqldump</li>
</ul>

<h4>1.3.1</h4>

<ul>
<li>Check for PHP version. Deactivate plugin if running on PHP version 4.</li>
</ul>

<h4>1.3</h4>

<ul>
<li>Re-written back up engine, no longer copies everything to a tmp folder before zipping which should improve speed and reliability.</li>
<li>Support for excluding files and folders, define <code>HMBKP_EXCLUDE</code> with a comma separated list of files and folders to exclude, supports wildcards <code>*</code>, path fragments and absolute paths.</li>
<li>Full support for moving the backups directory, if you define a new backups directory then your existing backups will be moved to it.</li>
<li>Work around issues caused by low MySQL <code>wait_timeout</code> setting.</li>
<li>Add FAQ to readme.txt.</li>
<li>Pull FAQ into the contextual help tab on the backups page.</li>
<li>Block activation on old versions of WordPress.</li>
<li>Stop guessing compressed backup file size, instead just show size of site uncompressed.</li>
<li>Fix bug in <code>safe_mode</code> detection which could cause <code>Off</code> to act like <code>On</code>.</li>
<li>Better name for the database dump file.</li>
<li>Better name for the backup files.</li>
<li>Improve styling for advanced options.</li>
<li>Show examples for all advanced options.</li>
<li>Language improvements.</li>
<li>Layout tweaks.</li>
</ul>

<h4>1.2</h4>

<ul>
<li>Show live backup status in the back up now button when a back up is running.</li>
<li>Show free disk space after total used by backups.</li>
<li>Several langauge changes.</li>
<li>Work around the 1 cron every 60 seconds limit.</li>
<li>Store backup status in a 2 hour transient as a last ditch attempt to work around the "stuck on backup running" issue.</li>
<li>Show a warning and disable backups when PHP is in Safe Mode, may try to work round issues and re-enable in the future.</li>
<li>Highlight defined <code>Constants</code>.</li>
<li>Show defaults for all <code>Constants</code>.</li>
<li>Show a warning if both <code>HMBKP_FILES_ONLY</code> and <code>HMBKP_DATABASE_ONLY</code> are defined at the same time.</li>
<li>Make sure options added in 1.1.4 are cleared on de-activate.</li>
<li>Support <code>mysqldump on</code> Windows if it\'s available.</li>
<li>New option to have each backup emailed to you on completion. Props @matheu for the contribution.</li>
<li>Improved windows server support.</li>
</ul>

<h4>1.1.4</h4>

<ul>
<li>Fix a rare issue where database backups could fail when using the mysqldump PHP fallback if <code>mysql.max_links</code> is set to 2 or less.</li>
<li>Don\'t suppress <code>mysql_connect</code> errors in the mysqldump PHP fallback.</li>
<li>One time highlight of the most recent completed backup when viewing the manage backups page after a successful backup.</li>
<li>Fix a spelling error in the <code>shell_exec</code> disabled message.</li>
<li>Store the BackUpWordPress version as a <code>Constant</code> rather than a <code>Variable</code>.</li>
<li>Don\'t <code>(float)</code> the BackUpWordPress version number, fixes issues with minor versions numbers being truncated.</li>
<li>Minor PHPDoc improvements.</li>
</ul>

<h4>1.1.3</h4>

<ul>
<li>Attempt to re-connect if database connection hits a timeout while a backup is running, should fix issues with the "Back Up Now" button continuing to spin even though the backup is completed.</li>
<li>When using <code>PCLZIP</code> as the zip fallback don\'t store the files with absolute paths. Should fix issues unzipping the file archives using "Compressed (zipped) Folders" on Windows XP.</li>
</ul>

<h4>1.1.2</h4>

<ul>
<li>Fix a bug that stopped <code>HMBKP_DISABLE_AUTOMATIC_BACKUP</code> from working.</li>
</ul>

<h4>1.1.1</h4>

<ul>
<li>Fix a possible <code>max_execution_timeout</code> fatal error when attempting to calculate the path to <code>mysqldump</code>.</li>
<li>Clear the running backup status and reset the calculated filesize on update.</li>
<li>Show a link to the manage backups page in the plugin description.</li>
<li>Other general fixes.</li>
</ul>

<h4>1.1</h4>

<ul>
<li>Remove the logging facility as it provided little benefit and complicated the code, your existing logs will be deleted on update.</li>
<li>Expose the various <code>Constants</code> that can be defined to change advanced settings.</li>
<li>Added the ability to disable the automatic backups completely <code>define( \'HMBKP_DISABLE_AUTOMATIC_BACKUP\', true );</code>.</li>
<li>Added the ability to switch to file only or database only backups <code>define( \'HMBKP_FILES_ONLY\', true );</code> Or <code>define( \'HMBKP_DATABASE_ONLY\', true );</code>.</li>
<li>Added the ability to define how many old backups should be kept <code>define( \'HMBKP_MAX_BACKUPS\', 20 );</code></li>
<li>Added the ability to define the time that the daily backup should run <code>define( \'HMBKP_DAILY_SCHEDULE_TIME\', \'16:30\' );</code></li>
<li>Tweaks to the backups page layout.</li>
<li>General bug fixes and improvements.</li>
</ul>

<h4>1.0.5</h4>

<ul>
<li>Don\'t ajax load estimated backup size if it\'s already been calculated.</li>
<li>Fix time in backup complete log message.</li>
<li>Don\'t mark backup as running until cron has been called, will fix issues with backup showing as running even if cron never fired.</li>
<li>Show number of backups saved message.</li>
<li>Add a link to the backups page to the plugin action links.</li>
</ul>

<h4>1.0.4</h4>

<p>Don\'t throw PHP Warnings when <code>shell_exec</code> is disabled</p>

<h4>1.0.3</h4>

<p>Minor bug fix release.</p>

<ul>
<li>Suppress <code>filesize()</code> warnings when calculating backup size.</li>
<li>Plugin should now work when symlinked.</li>
<li>Remove all options on deactivate, you should now be able to deactivate then activate to fix issues with settings etc. becoming corrupt.</li>
<li>Call setup_defaults for users who update from backupwordpress 0.4.5 so they get new settings.</li>
<li>Don\'t ajax ping running backup status quite so often.</li>
</ul>

<h4>1.0.1 &#38; 1.0.2</h4>

<p>Fix some silly 1.0 bugs</p>

<h4>1.0</h4>

<p>1.0 represents a total rewrite &#38; rethink of the BackUpWordPress plugin with a focus on making it "Just Work". The management and development of the plugin has been taken over by <a href="http://hmn.md">Human Made Limited</a> the chaps behind <a href="https://wpremote.com">WP Remote</a></p>

<h4>Previous</h4>

<p>Version 0.4.5 and previous were developed by <a href="http://profiles.wordpress.org/users/wpdprx/">wpdprx</a></p>";s:3:"faq";s:4410:"<p><strong>Where does BackUpWordPress store the backup files?</strong></p>

<p>Backups are stored on your server in <code>/wp-content/backups</code>, you can change the directory.</p>

<p><strong>Important:</strong> By default BackUpWordPress backs up everything in your site root as well as your database, this includes any non WordPress folders that happen to be in your site root. This does means that your backup directory can get quite large.</p>

<p><strong>What if I want I want to back up my site to another destination?</strong></p>

<p>BackUpWordPress Pro supports Dropbox, Google Drive, Amazon S3, Rackspace, Azure, DreamObjects and FTP/SFTP. Check it out here: <a href="http://bwp.hmn.md/?utm_source=wordpress-org&#38;utm_medium=plugin-page&#38;utm_campaign=freeplugin">https://bwp.hmn.md</a></p>

<p><strong>How do I restore my site from a backup?</strong></p>

<p>You need to download the latest backup file either by clicking download on the backups page or via <code>FTP</code>. <code>Unzip</code> the files and upload all the files to your server overwriting your site. You can then import the database using your hosts database management tool (likely <code>phpMyAdmin</code>).</p>

<p>See this post for more details <a href="http://hmn.md/backupwordpress-how-to-restore-from-backup-files/" rel="nofollow">http://hmn.md/backupwordpress-how-to-restore-from-backup-files/</a>.</p>

<p><strong>Does BackUpWordPress back up the backups directory?</strong></p>

<p>No.</p>

<p><strong>I\'m not receiving my backups by email</strong></p>

<p>Most servers have a filesize limit on email attachments, it\'s generally about 10mb. If your backup file is over that limit it won\'t be sent attached to the email, instead you should receive an email with a link to download the backup, if you aren\'t even receiving that then you likely have a mail issue on your server that you\'ll need to contact your host about.</p>

<p><strong>How many backups are stored by default?</strong></p>

<p>BackUpWordPress stores the last 10 backups by default.</p>

<p><strong>How long should a backup take?</strong></p>

<p>Unless your site is very large (many gigabytes) it should only take a few minutes to perform a back up, if your back up has been running for longer than an hour it\'s safe to assume that something has gone wrong, try de-activating and re-activating the plugin, if it keeps happening, contact support.</p>

<p><strong>What do I do if I get the wp-cron error message</strong></p>

<p>The issue is that your <code>wp-cron.php</code> is not returning a <code>200</code> response when hit with a http request originating from your own server, it could be several things, most of the time it\'s an issue with the server / site and not with BackUpWordPress.</p>

<p>Some things you can test are.</p>

<ul>
<li>Are scheduled posts working? (They use wp-cron too).</li>
<li>Are you hosted on Heart Internet? (wp-cron is known not to work with them).</li>
<li>If you click manual backup does it work?</li>
<li>Try adding <code>define( \'ALTERNATE_WP_CRON\', true ); to your</code>wp-config.php`, do automatic backups work?</li>
<li>Is your site private (I.E. is it behind some kind of authentication, maintenance plugin, .htaccess) if so wp-cron won\'t work until you remove it, if you are and you temporarily remove the authentication, do backups start working?</li>
</ul>

<p>If you have tried all these then feel free to contact support.</p>

<p><strong>How to get BackUpWordPress working in Heart Internet</strong></p>

<p>The script to be entered into the Heart Internet cPanel is: <code>/usr/bin/php5 /home/sites/yourdomain.com/public_html/wp-cron.php</code> (note the space between php5 and the location of the file). The file <code>wp-cron.php</code> <code>chmod</code> must be set to <code>711</code>.</p>

<p><strong>Further Support &#38; Feedback</strong></p>

<p>General support questions should be posted in the <a href="http://wordpress.org/tags/backupwordpress?forum_id=10">WordPress support forums, tagged with backupwordpress.</a></p>

<p>For development issues, feature requests or anybody wishing to help out with development checkout <a href="https://github.com/humanmade/backupwordpress/">BackUpWordPress on GitHub.</a></p>

<p>You can also tweet <a href="http://twitter.com/humanmadeltd">@humanmadeltd</a> or email <a href="mailto:support@hmn.md">support@hmn.md</a> for further help/support.</p>";}s:13:"download_link";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.2.6.2.zip";s:4:"tags";a:10:{s:7:"archive";s:7:"archive";s:7:"back-up";s:7:"back up";s:6:"backup";s:6:"backup";s:7:"backups";s:7:"backups";s:8:"database";s:8:"database";s:2:"db";s:2:"db";s:5:"files";s:5:"files";s:9:"humanmade";s:9:"humanmade";s:6:"wp-cli";s:6:"wp-cli";s:3:"zip";s:3:"zip";}s:11:"donate_link";N;}', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (287, '_transient_timeout_hmbkp_schedule_default-1_database_filesize', '2816469128', 'no') ; 
INSERT INTO `wpMTAL_options` VALUES (288, '_transient_hmbkp_schedule_default-1_database_filesize', '1409024', 'no') ;
#
# End of data contents of table wpMTAL_options
# --------------------------------------------------------

# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_events`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_venuemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_postmeta`
#

DROP TABLE IF EXISTS `wpMTAL_postmeta`;


#
# Table structure of table `wpMTAL_postmeta`
#

CREATE TABLE `wpMTAL_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_postmeta (168 records)
#
 
INSERT INTO `wpMTAL_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (2, 4, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (3, 4, '_edit_lock', '1407720549:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (4, 4, '_wp_page_template', 'page-home.php') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (5, 6, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (6, 6, '_edit_lock', '1407808568:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (7, 6, '_wp_page_template', 'default') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (8, 10, '_wp_attached_file', '2014/08/hson.jpg') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (9, 10, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:109;s:6:"height";i:110;s:4:"file";s:16:"2014/08/hson.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (10, 10, '_edit_lock', '1407713038:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (11, 11, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (12, 11, 'field_53e8003b4a3b8', 'a:13:{s:3:"key";s:19:"field_53e8003b4a3b8";s:5:"label";s:12:"Page Summary";s:4:"name";s:12:"page_summary";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:10:"formatting";s:2:"br";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (13, 11, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"page";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (14, 11, 'position', 'normal') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (15, 11, 'layout', 'no_box') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (16, 11, 'hide_on_screen', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (17, 11, '_edit_lock', '1407713257:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (18, 12, 'page_summary', 'Apply now and learn about membership criteria, special member initiatives and how you can stay connected through this community of nurses who have dedicated a lifetime of being a member in the honor society of nursing. For membership information, please follow the links to Sigma Theta Tau International.') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (19, 12, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (20, 6, 'page_summary', 'Apply now and learn about membership criteria, special member initiatives and how you can stay connected through this community of nurses who have dedicated a lifetime of being a member in the honor society of nursing. For membership information, please follow the links to Sigma Theta Tau International.') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (21, 6, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (22, 14, 'page_summary', 'Apply now and learn about membership criteria, special member initiatives and how you can stay connected through this community of nurses who have dedicated a lifetime of being a member in the honor society of nursing. For membership information, please follow the links to Sigma Theta Tau International.') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (23, 14, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (24, 15, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (25, 15, '_edit_lock', '1407722393:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (26, 15, '_wp_page_template', 'default') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (27, 16, 'page_summary', 'Yes, I would like to help nurses reach their goals in education and research!') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (28, 16, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (29, 15, 'page_summary', 'Yes, I would like to help nurses reach their goals in education and research!') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (30, 15, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (31, 17, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (32, 17, '_edit_lock', '1407806474:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (33, 17, '_wp_page_template', 'default') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (34, 18, 'page_summary', 'Mu Theta Thanks all those who donated to its Friends of Mu Theta-At-Large Patron Program that was debuted in 2011. This program will fund Scholarships and research grants for our members Leaflets are available at this event if you would like to make a donation') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (35, 18, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (36, 17, 'page_summary', 'Mu Theta Thanks all those who donated to its Friends of Mu Theta-At-Large Patron Program that was debuted in 2011. This program will fund Scholarships and research grants for our members Leaflets are available at this event if you would like to make a donation') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (37, 17, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (38, 19, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (39, 19, '_edit_lock', '1407716984:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (40, 20, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (41, 20, '_edit_lock', '1407720626:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (42, 21, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (43, 21, '_edit_lock', '1407717040:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (44, 22, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (45, 22, '_edit_lock', '1407717822:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (46, 23, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (47, 23, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (48, 4, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (49, 4, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (50, 24, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (51, 24, '_wp_page_template', 'page-calendar.php') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (52, 25, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (53, 25, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (54, 24, 'page_summary', 'Calendar of Events 2014 - 2015
College of Saint Elizabeth') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (55, 24, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (56, 24, '_edit_lock', '1407804143:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (57, 26, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (58, 26, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (59, 27, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (60, 27, '_edit_lock', '1407721368:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (61, 27, '_eventorganiser_event_schedule', 'a:8:{s:7:"all_day";i:0;s:8:"schedule";s:4:"once";s:13:"schedule_meta";s:0:"";s:9:"frequency";i:1;s:7:"exclude";a:0:{}s:7:"include";a:0:{}s:12:"duration_str";s:19:"+0days 7200 seconds";s:12:"_occurrences";a:1:{i:1;s:19:"2014-09-13 10:00:00";}}') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (62, 27, '_eventorganiser_schedule_start_start', '2014-09-13 10:00:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (63, 27, '_eventorganiser_schedule_start_finish', '2014-09-13 12:00:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (64, 27, '_eventorganiser_schedule_last_start', '2014-09-13 10:00:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (65, 27, '_eventorganiser_schedule_last_finish', '2014-09-13 12:00:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (66, 28, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (67, 28, '_edit_lock', '1407721571:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (68, 28, '_eventorganiser_event_schedule', 'a:8:{s:7:"all_day";i:0;s:8:"schedule";s:4:"once";s:13:"schedule_meta";s:0:"";s:9:"frequency";i:1;s:7:"exclude";a:0:{}s:7:"include";a:0:{}s:12:"duration_str";s:16:"+0days 0 seconds";s:12:"_occurrences";a:1:{i:2;s:19:"2014-10-01 00:00:00";}}') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (69, 28, '_eventorganiser_schedule_start_start', '2014-10-01 00:00:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (70, 28, '_eventorganiser_schedule_start_finish', '2014-10-01 00:00:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (71, 28, '_eventorganiser_schedule_last_start', '2014-10-01 00:00:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (72, 28, '_eventorganiser_schedule_last_finish', '2014-10-01 00:00:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (73, 29, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (74, 29, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (75, 31, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (76, 31, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (77, 32, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (78, 32, '_edit_lock', '1407721842:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (79, 32, '_eventorganiser_event_schedule', 'a:8:{s:7:"all_day";i:0;s:8:"schedule";s:4:"once";s:13:"schedule_meta";s:0:"";s:9:"frequency";i:1;s:7:"exclude";a:0:{}s:7:"include";a:0:{}s:12:"duration_str";s:20:"+0days 10800 seconds";s:12:"_occurrences";a:1:{i:3;s:19:"2014-10-05 10:30:00";}}') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (80, 32, '_eventorganiser_schedule_start_start', '2014-10-05 10:30:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (81, 32, '_eventorganiser_schedule_start_finish', '2014-10-05 13:30:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (82, 32, '_eventorganiser_schedule_last_start', '2014-10-05 10:30:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (83, 32, '_eventorganiser_schedule_last_finish', '2014-10-05 13:30:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (84, 33, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (85, 33, '_edit_lock', '1407721973:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (86, 33, '_eventorganiser_event_schedule', 'a:8:{s:7:"all_day";i:0;s:8:"schedule";s:4:"once";s:13:"schedule_meta";s:0:"";s:9:"frequency";i:1;s:7:"exclude";a:0:{}s:7:"include";a:0:{}s:12:"duration_str";s:16:"+0days 0 seconds";s:12:"_occurrences";a:1:{i:4;s:19:"2014-11-15 00:00:00";}}') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (87, 33, '_eventorganiser_schedule_start_start', '2014-11-15 00:00:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (88, 33, '_eventorganiser_schedule_start_finish', '2014-11-15 00:00:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (89, 33, '_eventorganiser_schedule_last_start', '2014-11-15 00:00:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (90, 33, '_eventorganiser_schedule_last_finish', '2014-11-15 00:00:00') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (91, 34, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (92, 34, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (93, 35, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (94, 35, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (95, 36, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (96, 36, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (97, 37, 'page_summary', 'Calendar of Events 2014-2015<br /> 
College of Saint Elizabeth') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (98, 37, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (99, 38, 'page_summary', 'Calendar of Events 2014 - 2015
College of Saint Elizabeth') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (100, 38, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (101, 39, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (102, 39, '_edit_lock', '1407889258:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (103, 39, '_wp_page_template', 'default') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (104, 40, 'page_summary', 'Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (105, 40, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (106, 39, 'page_summary', 'Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (107, 39, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (108, 42, 'page_summary', 'Mu Theta Thanks all those who donated to its Friends of Mu Theta-At-Large Patron Program that was debuted in 2011. This program will fund Scholarships and research grants for our members Leaflets are available at this event if you would like to make a donation') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (109, 42, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (110, 43, 'page_summary', 'Mu Theta Thanks all those who donated to its Friends of Mu Theta-At-Large Patron Program that was debuted in 2011. This program will fund Scholarships and research grants for our members Leaflets are available at this event if you would like to make a donation') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (111, 43, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (112, 45, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (113, 45, '_edit_lock', '1407807917:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (114, 45, '_wp_page_template', 'default') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (115, 46, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (116, 46, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (117, 45, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (118, 45, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (119, 47, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (120, 47, '_edit_lock', '1407808025:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (121, 47, '_wp_page_template', 'default') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (122, 48, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (123, 48, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (124, 47, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (125, 47, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (126, 49, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (127, 49, '_edit_lock', '1407889356:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (128, 49, '_wp_page_template', 'default') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (129, 50, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (130, 50, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (131, 49, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (132, 49, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (133, 51, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (134, 51, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (135, 52, 'page_summary', 'Apply now and learn about membership criteria, special member initiatives and how you can stay connected through this community of nurses who have dedicated a lifetime of being a member in the honor society of nursing. For membership information, please follow the links to Sigma Theta Tau International.') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (136, 52, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (141, 53, 'page_summary', 'Apply now and learn about membership criteria, special member initiatives and how you can stay connected through this community of nurses who have dedicated a lifetime of being a member in the honor society of nursing. For membership information, please follow the links to Sigma Theta Tau International.') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (142, 53, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (143, 6, '_oembed_00a5eaaac04d67e26e5fecc97042b927', '{{unknown}}') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (144, 6, '_oembed_1ba099903cd011ea92fabc2c8ad95202', '{{unknown}}') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (145, 6, '_oembed_1fde33727aedc755b5ace84b622efd8b', '{{unknown}}') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (146, 6, '_oembed_1bd4f505dfe6c0acb6daa17a47c2b3b2', '{{unknown}}') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (147, 54, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (148, 54, '_edit_lock', '1407888302:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (149, 54, '_wp_page_template', 'default') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (150, 55, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (151, 55, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (152, 54, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (153, 54, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (154, 56, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (155, 56, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (156, 57, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (157, 57, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (158, 59, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (159, 59, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (160, 61, 'page_summary', 'Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (161, 61, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (162, 62, 'page_summary', 'Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (163, 62, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (164, 63, '_edit_last', '1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (165, 63, '_wp_page_template', 'default') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (166, 64, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (167, 64, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (168, 63, 'page_summary', '') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (169, 63, '_page_summary', 'field_53e8003b4a3b8') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (170, 63, '_edit_lock', '1407889316:1') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (171, 63, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wpMTAL_postmeta` VALUES (172, 63, '_wp_trash_meta_time', '1407889470') ;
#
# End of data contents of table wpMTAL_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_events`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_venuemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_posts`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_posts`
#

DROP TABLE IF EXISTS `wpMTAL_posts`;


#
# Table structure of table `wpMTAL_posts`
#

CREATE TABLE `wpMTAL_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_posts (64 records)
#
 
INSERT INTO `wpMTAL_posts` VALUES (1, 1, '2014-08-10 15:17:52', '2014-08-10 15:17:52', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-08-10 15:17:52', '2014-08-10 15:17:52', '', 0, 'http://localhost:8888/muthetaatlarge.org/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wpMTAL_posts` VALUES (2, 1, '2014-08-10 15:17:52', '2014-08-10 15:17:52', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://localhost:8888/muthetaatlarge.org/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-08-10 15:17:52', '2014-08-10 15:17:52', '', 0, 'http://localhost:8888/muthetaatlarge.org/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (3, 1, '2014-08-10 15:18:04', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-08-10 15:18:04', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/muthetaatlarge.org/?p=3', 0, 'post', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (4, 1, '2014-08-10 15:50:03', '2014-08-10 15:50:03', '<div class="sixteen columns" style="margin: 30px 0;">
			<h2 style="text-align:center; margin-bottom: 20px;">Who We Are</h2>
			<div class="sixteen clearfix">
				<div class="eight columns alpha" >
				
					<div class="circular-wwr"></div>
				
				</div>
				
				<div class="eight columns omega">
				<h4>Mu Theta At Large</h4>
					<p>Mu Theta is a dynamic chapter with many accomplishments to its credit. Our board has developed a 5-year strategic plan. Our goals include increasing membership involvement, supporting research activities, encouraging leadership development and fund-raising to promote scholarship. In addition, we are working to increase our chapter\'s visibility. If any of these areas are of interest to you and you can share your time and talent with us, please contact me.</p>

				</div>
			</div>

		</div>
		
		<div class="sixteen columns" style="margin: 30px 0;">
			<h2 style="text-align:center; margin-bottom: 20px;">President\'s Message</h2>
			<div class="sixteen clearfix">
				<div class="eight columns alpha" >
				<h4>Sara Thompson, DNP, RN, APN-C</h4>
					<p>I am honored and humbled to serve the next two years as your president. The Mission and Vision of Sigma Theta Tau International are carried out in chapters like Mu Theta at Large. Read the Mission and Vision. </p>
					<p>Organizational Mission
The mission of the Honor Society of Nursing, Sigma Theta Tau International is to support the learning, knowledge and professional development of nurses committed to making a difference in health worldwide.</p>
				</div>
				
				<div class="eight columns omega">
				
					<div class="circular-pm"></div>
				</div>
			</div>

		</div>', 'Homepage', '', 'publish', 'open', 'open', '', 'homepage', '', '', '2014-08-11 01:31:31', '2014-08-11 01:31:31', '', 0, 'http://localhost:8888/muthetaatlarge.org/?page_id=4', 0, 'page', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (5, 1, '2014-08-10 15:50:03', '2014-08-10 15:50:03', '', 'Homepage', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-08-10 15:50:03', '2014-08-10 15:50:03', '', 4, 'http://localhost:8888/muthetaatlarge.org/?p=5', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (6, 1, '2014-08-10 16:08:10', '2014-08-10 16:08:10', '<h3>Membership criteria</h3>
http://www.nursingsociety.org/membership/applyNow/Pages/mem_criteria.aspx                       

<h3>New Leader Membership criteria: </h3>     
http://www.nursingsociety.org/Membership/ApplyNow/Pages/nl_memcriteria.aspx

<h3>Member Benefits:</h3>
http://www.nursingsociety.org/Membership/Benefits/Pages/benefits.aspx

<h3>Member Get a Member Campaign:</h3>
http://www.nursingsociety.org/Membership/Campaigns/Pages/Member2Member.aspx

<p>Newest members to Sigma Theta Tau International, Honor Society of Nurses, Mu Theta at Large Chapter Inducted April 27th, 2013.</p>

New Members List 2013
New Members List Archives

New Members List 2011
Photos of Mu Theta at Large Chapter’s Events', 'Membership', '', 'publish', 'open', 'open', '', 'membership', '', '', '2014-08-12 01:58:31', '2014-08-12 01:58:31', '', 0, 'http://localhost:8888/muthetaatlarge.org/?page_id=6', 0, 'page', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (7, 1, '2014-08-10 16:08:10', '2014-08-10 16:08:10', '<h3 style="margin:20px 60px;">Apply now and learn about membership criteria, special member initiatives and how you can stay connected through this community of nurses who have dedicated a lifetime of being a member in the honor society of nursing. For membership information, please follow the links to Sigma Theta Tau International.</h3>
					</div>
				</div>
		
	<div class="container">
		<div class="sixteen columns" style="margin: 0;">
			
			<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">History</h2>
				<div class="eight columns alpha">
				<p>In 1922, six students from the Indiana University Training School for Nurses in Indianapolis, Indiana founded the honor society of nursing. Read about the lives of these students and their faculty advisor, who recognized the value of scholarship and excellence in nursing practice. (more)</p>
				<p>
					Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.  In its pursuit of promoting nursing excellence, it helps prepare nurses to excel and function globally in all facets of nursing education, leadership, research, and scholarship.
				</p>
				</div>
				<div class="eight columns omega">
				<p>

					To that end, the Board of Directors, Committees, and Chapter members convene at alternating sites and rotate between the campuses of the schools that comprise its membership namely-St. Peter’s College (Englewood Cliffs), Felician College (Lodi), and College of St. Elizabeth (Morristown). General business meetings held regularly throughout the year provide opportunities to discuss, plan, and implement strategies for chapter-based programs or co-sponsored educational initiatives.  In order to meet the involving needs of our members as well as enhance the growth of the chapter, we encourage your active participation, and invite you to join us!
				</p>
				</div>
			</div>		
			
		</div>
		', 'Membership', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-08-10 16:08:10', '2014-08-10 16:08:10', '', 6, 'http://localhost:8888/muthetaatlarge.org/?p=7', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (8, 1, '2014-08-10 16:09:27', '2014-08-10 16:09:27', '<div class="banner-holder" style="background-color:#fff;">
<h3 style="margin:20px 60px;">Apply now and learn about membership criteria, special member initiatives and how you can stay connected through this community of nurses who have dedicated a lifetime of being a member in the honor society of nursing. For membership information, please follow the links to Sigma Theta Tau International.</h3>
					</div>
				</div>
          </div>
		
	<div class="container">
		<div class="sixteen columns" style="margin: 0;">
			
			<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">History</h2>
				<div class="eight columns alpha">
				<p>In 1922, six students from the Indiana University Training School for Nurses in Indianapolis, Indiana founded the honor society of nursing. Read about the lives of these students and their faculty advisor, who recognized the value of scholarship and excellence in nursing practice. (more)</p>
				<p>
					Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.  In its pursuit of promoting nursing excellence, it helps prepare nurses to excel and function globally in all facets of nursing education, leadership, research, and scholarship.
				</p>
				</div>
				<div class="eight columns omega">
				<p>

					To that end, the Board of Directors, Committees, and Chapter members convene at alternating sites and rotate between the campuses of the schools that comprise its membership namely-St. Peter’s College (Englewood Cliffs), Felician College (Lodi), and College of St. Elizabeth (Morristown). General business meetings held regularly throughout the year provide opportunities to discuss, plan, and implement strategies for chapter-based programs or co-sponsored educational initiatives.  In order to meet the involving needs of our members as well as enhance the growth of the chapter, we encourage your active participation, and invite you to join us!
				</p>
				</div>
			</div>		
			
		</div>
		', 'Membership', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-08-10 16:09:27', '2014-08-10 16:09:27', '', 6, 'http://localhost:8888/muthetaatlarge.org/?p=8', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (9, 1, '2014-08-10 16:10:06', '2014-08-10 16:10:06', '<h3 style="margin:20px 60px;">Apply now and learn about membership criteria, special member initiatives and how you can stay connected through this community of nurses who have dedicated a lifetime of being a member in the honor society of nursing. For membership information, please follow the links to Sigma Theta Tau International.</h3>
					</div>
				</div>
         </div> 
		
	<div class="container">
		<div class="sixteen columns" style="margin: 0;">
			
			<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">History</h2>
				<div class="eight columns alpha">
				<p>In 1922, six students from the Indiana University Training School for Nurses in Indianapolis, Indiana founded the honor society of nursing. Read about the lives of these students and their faculty advisor, who recognized the value of scholarship and excellence in nursing practice. (more)</p>
				<p>
					Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.  In its pursuit of promoting nursing excellence, it helps prepare nurses to excel and function globally in all facets of nursing education, leadership, research, and scholarship.
				</p>
				</div>
				<div class="eight columns omega">
				<p>

					To that end, the Board of Directors, Committees, and Chapter members convene at alternating sites and rotate between the campuses of the schools that comprise its membership namely-St. Peter’s College (Englewood Cliffs), Felician College (Lodi), and College of St. Elizabeth (Morristown). General business meetings held regularly throughout the year provide opportunities to discuss, plan, and implement strategies for chapter-based programs or co-sponsored educational initiatives.  In order to meet the involving needs of our members as well as enhance the growth of the chapter, we encourage your active participation, and invite you to join us!
				</p>
				</div>
			</div>		
			
		</div>
		', 'Membership', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-08-10 16:10:06', '2014-08-10 16:10:06', '', 6, 'http://localhost:8888/muthetaatlarge.org/?p=9', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (10, 1, '2014-08-10 16:12:41', '2014-08-10 16:12:41', '', 'hson', '', 'inherit', 'open', 'open', '', 'hson', '', '', '2014-08-10 16:12:41', '2014-08-10 16:12:41', '', 0, 'http://localhost:8888/muthetaatlarge.org/wp-content/uploads/2014/08/hson.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (11, 1, '2014-08-10 23:29:33', '2014-08-10 23:29:33', '', 'Page Summary', '', 'publish', 'closed', 'closed', '', 'acf_page-summary', '', '', '2014-08-10 23:29:33', '2014-08-10 23:29:33', '', 0, 'http://localhost:8888/muthetaatlarge.org/?post_type=acf&#038;p=11', 0, 'acf', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (12, 1, '2014-08-10 23:30:33', '2014-08-10 23:30:33', '
		
	<div class="container">
		<div class="sixteen columns" style="margin: 0;">
			
			<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">History</h2>
				<div class="eight columns alpha">
				<p>In 1922, six students from the Indiana University Training School for Nurses in Indianapolis, Indiana founded the honor society of nursing. Read about the lives of these students and their faculty advisor, who recognized the value of scholarship and excellence in nursing practice. (more)</p>
				<p>
					Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.  In its pursuit of promoting nursing excellence, it helps prepare nurses to excel and function globally in all facets of nursing education, leadership, research, and scholarship.
				</p>
				</div>
				<div class="eight columns omega">
				<p>

					To that end, the Board of Directors, Committees, and Chapter members convene at alternating sites and rotate between the campuses of the schools that comprise its membership namely-St. Peter’s College (Englewood Cliffs), Felician College (Lodi), and College of St. Elizabeth (Morristown). General business meetings held regularly throughout the year provide opportunities to discuss, plan, and implement strategies for chapter-based programs or co-sponsored educational initiatives.  In order to meet the involving needs of our members as well as enhance the growth of the chapter, we encourage your active participation, and invite you to join us!
				</p>
				</div>
			</div>		
			
		</div>
		', 'Membership', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-08-10 23:30:33', '2014-08-10 23:30:33', '', 6, 'http://localhost:8888/muthetaatlarge.org/?p=12', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (13, 1, '2014-08-10 23:37:27', '2014-08-10 23:37:27', '<h3 style="margin:20px 60px;">Apply now and learn about membership criteria, special member initiatives and how you can stay connected through this community of nurses who have dedicated a lifetime of being a member in the honor society of nursing. For membership information, please follow the links to Sigma Theta Tau International.</h3>
					</div>
				</div>
         </div> 
		
	<div class="container">
		<div class="sixteen columns" style="margin: 0;">
			
			<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">History</h2>
				<div class="eight columns alpha">
				<p>In 1922, six students from the Indiana University Training School for Nurses in Indianapolis, Indiana founded the honor society of nursing. Read about the lives of these students and their faculty advisor, who recognized the value of scholarship and excellence in nursing practice. (more)</p>
				<p>
					Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.  In its pursuit of promoting nursing excellence, it helps prepare nurses to excel and function globally in all facets of nursing education, leadership, research, and scholarship.
				</p>
				</div>
				<div class="eight columns omega">
				<p>

					To that end, the Board of Directors, Committees, and Chapter members convene at alternating sites and rotate between the campuses of the schools that comprise its membership namely-St. Peter’s College (Englewood Cliffs), Felician College (Lodi), and College of St. Elizabeth (Morristown). General business meetings held regularly throughout the year provide opportunities to discuss, plan, and implement strategies for chapter-based programs or co-sponsored educational initiatives.  In order to meet the involving needs of our members as well as enhance the growth of the chapter, we encourage your active participation, and invite you to join us!
				</p>
				</div>
			</div>		
			
		</div>
		', 'Membership', '', 'inherit', 'open', 'open', '', '6-autosave-v1', '', '', '2014-08-10 23:37:27', '2014-08-10 23:37:27', '', 6, 'http://localhost:8888/muthetaatlarge.org/?p=13', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (14, 1, '2014-08-10 23:40:09', '2014-08-10 23:40:09', '
				
				<h2 style="text-align:left; margin-bottom: 20px; ">History</h2>
				<div class="eight columns alpha">
				<p>In 1922, six students from the Indiana University Training School for Nurses in Indianapolis, Indiana founded the honor society of nursing. Read about the lives of these students and their faculty advisor, who recognized the value of scholarship and excellence in nursing practice. (more)</p>
				<p>
					Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.  In its pursuit of promoting nursing excellence, it helps prepare nurses to excel and function globally in all facets of nursing education, leadership, research, and scholarship.
				</p>
				</div>
				<div class="eight columns omega">
				<p>

					To that end, the Board of Directors, Committees, and Chapter members convene at alternating sites and rotate between the campuses of the schools that comprise its membership namely-St. Peter’s College (Englewood Cliffs), Felician College (Lodi), and College of St. Elizabeth (Morristown). General business meetings held regularly throughout the year provide opportunities to discuss, plan, and implement strategies for chapter-based programs or co-sponsored educational initiatives.  In order to meet the involving needs of our members as well as enhance the growth of the chapter, we encourage your active participation, and invite you to join us!
				</p>
				</div>

		', 'Membership', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-08-10 23:40:09', '2014-08-10 23:40:09', '', 6, 'http://localhost:8888/muthetaatlarge.org/?p=14', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (15, 1, '2014-08-10 23:43:53', '2014-08-10 23:43:53', 'Donation can be made to Mu Theta at Large Chapter’s scholarship and research fund by sending your check to Teru Coleman, Treasurer.  Make the check out to Mu Theta at Large Chapter and mail it to Teru Coleman, 553 East Blancke Street 1st floor, Linden New Jersey 07036. If you have any question in reference to this fund, please e-mail Teru Coleman at nursetc@aol.com.
', 'Donations', '', 'publish', 'open', 'open', '', 'donations', '', '', '2014-08-10 23:43:53', '2014-08-10 23:43:53', '', 0, 'http://localhost:8888/muthetaatlarge.org/?page_id=15', 0, 'page', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (16, 1, '2014-08-10 23:43:53', '2014-08-10 23:43:53', 'Donation can be made to Mu Theta at Large Chapter’s scholarship and research fund by sending your check to Teru Coleman, Treasurer.  Make the check out to Mu Theta at Large Chapter and mail it to Teru Coleman, 553 East Blancke Street 1st floor, Linden New Jersey 07036. If you have any question in reference to this fund, please e-mail Teru Coleman at nursetc@aol.com.
', 'Donations', '', 'inherit', 'open', 'open', '', '15-revision-v1', '', '', '2014-08-10 23:43:53', '2014-08-10 23:43:53', '', 15, 'http://localhost:8888/muthetaatlarge.org/?p=16', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (17, 1, '2014-08-10 23:48:46', '2014-08-10 23:48:46', '<div class="sixteen clearfix">
<div class="eight columns alpha">
<h4>DONORS 2013:<h4> 
Gold 
Elaine M. Kopp 
Paula Lefever 
Silver 
Timothy Clyne 
Bronze 
Edlyn I. Arthur 
Naney Hie 
Barbara Weith Isenberg
</div>
<div class="eight columns omega">
<h4>Patron Project - Cover</h4>

<h4>Patron Project - Introduction</h4>

<h4>Patron Project - Levels of Patronage</h4>

<h4>Patron Project - Payment Procedure</h4>

<h4>Patron Project - Contact Information</h4>

</div>
</div>', 'Patron Project', '', 'publish', 'open', 'open', '', 'patron-project', '', '', '2014-08-12 01:23:37', '2014-08-12 01:23:37', '', 0, 'http://localhost:8888/muthetaatlarge.org/?page_id=17', 0, 'page', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (18, 1, '2014-08-10 23:48:46', '2014-08-10 23:48:46', '<h3>DONORS 2013:<h3> 
Gold 
Elaine M. Kopp 
Paula Lefever 
Silver 
Timothy Clyne 
Bronze 
Edlyn I. Arthur 
Naney Hie 
Barbara Weith Isenberg

<h3>Patron Project - Cover</h3>

<h3>Patron Project - Introduction</h3>

<h3>Patron Project - Levels of Patronage</h3>

<h3>Patron Project - Payment Procedure</h3>

<h3>Patron Project - Contact Information</h3>', 'Patron Project', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-08-10 23:48:46', '2014-08-10 23:48:46', '', 17, 'http://localhost:8888/muthetaatlarge.org/?p=18', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (19, 1, '2014-08-11 00:32:04', '2014-08-11 00:32:04', '<p>Please join us for a Lunch and Learn Education offering - The ABCs of Peer Review Publishing for Nurses on Saturday May 10th, 11:00 am - 2:00 pm Annunciation Center, College of Saint Elizabeth, 2 convent Station, Morris Town, NJ, 07960.</p>

<p>Presenter: Kathleen Motacki, Clinical Associate Professor, St Peter\'s University Nurses $20.00 and students $10.00</p>', 'Saturday May 10th, 11:00 am - 2:00 pm', '', 'publish', 'closed', 'closed', '', 'saturday-may-10th-1100-am-200-pm', '', '', '2014-08-11 00:32:04', '2014-08-11 00:32:04', '', 0, 'http://localhost:8888/muthetaatlarge.org/?post_type=news&#038;p=19', 0, 'news', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (20, 1, '2014-08-11 00:32:37', '2014-08-11 00:32:37', 'Chapter members, please take a moment to review results of 2014 Chapter elections.', '2014 Chapter elections', '', 'publish', 'closed', 'closed', '', '2014-chapter-elections', '', '', '2014-08-11 00:32:37', '2014-08-11 00:32:37', '', 0, 'http://localhost:8888/muthetaatlarge.org/?post_type=events&#038;p=20', 0, 'events', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (21, 1, '2014-08-11 00:33:03', '2014-08-11 00:33:03', 'Check out your 2013 induction Photos on facebook - search Mu theta-at-Large Chapter.', '2013 induction Photos on facebook', '', 'publish', 'closed', 'closed', '', '2013-induction-photos-on-facebook', '', '', '2014-08-11 00:33:03', '2014-08-11 00:33:03', '', 0, 'http://localhost:8888/muthetaatlarge.org/?post_type=events&#038;p=21', 0, 'events', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (22, 1, '2014-08-11 00:33:24', '2014-08-11 00:33:24', 'Time and Venue - TBA', 'Board and Committee Members Meeting', '', 'publish', 'closed', 'closed', '', 'board-and-committee-members-meeting', '', '', '2014-08-11 00:33:24', '2014-08-11 00:33:24', '', 0, 'http://localhost:8888/muthetaatlarge.org/?post_type=events&#038;p=22', 0, 'events', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (23, 1, '2014-08-11 01:29:28', '2014-08-11 01:29:28', '<div class="sixteen columns" style="margin: 30px 0;">
			<h2 style="text-align:center; margin-bottom: 20px;">Who We Are</h2>
			<div class="sixteen clearfix">
				<div class="eight columns alpha" >
				
					<div class="circular-wwr"></div>
				
				</div>
				
				<div class="eight columns omega">
				<h4>Mu Theta At Large</h4>
					<p>Mu Theta is a dynamic chapter with many accomplishments to its credit. Our board has developed a 5-year strategic plan. Our goals include increasing membership involvement, supporting research activities, encouraging leadership development and fund-raising to promote scholarship. In addition, we are working to increase our chapter\'s visibility. If any of these areas are of interest to you and you can share your time and talent with us, please contact me.</p>

				</div>
			</div>

		</div>
		
		<div class="sixteen columns" style="margin: 30px 0;">
			<h2 style="text-align:center; margin-bottom: 20px;">President\'s Message</h2>
			<div class="sixteen clearfix">
				<div class="eight columns alpha" >
				<h4>Sara Thompson, DNP, RN, APN-C</h4>
					<p>I am honored and humbled to serve the next two years as your president. The Mission and Vision of Sigma Theta Tau International are carried out in chapters like Mu Theta at Large. Read the Mission and Vision. </p>
					<p>Organizational Mission
The mission of the Honor Society of Nursing, Sigma Theta Tau International is to support the learning, knowledge and professional development of nurses committed to making a difference in health worldwide.</p>
				</div>
				
				<div class="eight columns omega">
				
					<div class="circular-pm"></div>
				</div>
			</div>

		</div>', 'Homepage', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-08-11 01:29:28', '2014-08-11 01:29:28', '', 4, 'http://localhost:8888/muthetaatlarge.org/?p=23', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (24, 1, '2014-08-11 01:38:23', '2014-08-11 01:38:23', '', 'Calendar', '', 'publish', 'open', 'open', '', 'calendar', '', '', '2014-08-12 00:04:25', '2014-08-12 00:04:25', '', 0, 'http://localhost:8888/muthetaatlarge.org/?page_id=24', 0, 'page', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (25, 1, '2014-08-11 01:38:23', '2014-08-11 01:38:23', '', 'Calendar', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-08-11 01:38:23', '2014-08-11 01:38:23', '', 24, 'http://localhost:8888/muthetaatlarge.org/?p=25', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (26, 1, '2014-08-11 01:42:09', '2014-08-11 01:42:09', '<span style="color: #444444;">[eo_events]</span>', 'Calendar', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-08-11 01:42:09', '2014-08-11 01:42:09', '', 24, 'http://localhost:8888/muthetaatlarge.org/?p=26', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (27, 1, '2014-08-11 01:44:23', '2014-08-11 01:44:23', 'Planning Agenda, Business Agenda', 'Board of Directors and Committee Members', 'Planning Agenda, Business Agenda', 'publish', 'closed', 'closed', '', 'board-of-directors-and-committee-members', '', '', '2014-08-11 01:44:23', '2014-08-11 01:44:23', '', 0, 'http://localhost:8888/muthetaatlarge.org/?post_type=event&#038;p=27', 0, 'event', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (28, 1, '2014-08-11 01:47:53', '2014-08-11 01:47:53', 'Program: Research Day at College of Saint Elizabeth', 'Research Day', 'Program: Research Day at College of Saint Elizabeth', 'publish', 'open', 'open', '', 'research-day', '', '', '2014-08-11 01:47:53', '2014-08-11 01:47:53', '', 0, 'http://localhost:8888/muthetaatlarge.org/?post_type=event&#038;p=28', 0, 'event', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (29, 1, '2014-08-11 01:48:48', '2014-08-11 01:48:48', '[eo_events] <a href="%event_url%">%event_title%</a> on %start{jS M Y}{ g:i:a}%, at %event_venue% [/eo_events]
', 'Calendar', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-08-11 01:48:48', '2014-08-11 01:48:48', '', 24, 'http://localhost:8888/muthetaatlarge.org/?p=29', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (30, 1, '2014-08-11 01:49:48', '2014-08-11 01:49:48', '[eo_events] <h><a href="%event_url%">%event_title%</a> on %start{jS M Y}{ g:i:a}%, at %event_venue% [/eo_events]
', 'Calendar', '', 'inherit', 'open', 'open', '', '24-autosave-v1', '', '', '2014-08-11 01:49:48', '2014-08-11 01:49:48', '', 24, 'http://localhost:8888/muthetaatlarge.org/?p=30', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (31, 1, '2014-08-11 01:49:57', '2014-08-11 01:49:57', '[eo_events] <h4><a href="%event_url%">%event_title%</a></h4> on %start{jS M Y}{ g:i:a}%, at %event_venue% [/eo_events]
', 'Calendar', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-08-11 01:49:57', '2014-08-11 01:49:57', '', 24, 'http://localhost:8888/muthetaatlarge.org/?p=31', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (32, 1, '2014-08-11 01:52:39', '2014-08-11 01:52:39', 'Program: Keynote speaker - Hester Klopper', 'Annual Founders Day', 'Program: Keynote speaker - Hester Klopper', 'publish', 'open', 'open', '', 'annual-founders-day', '', '', '2014-08-11 01:52:39', '2014-08-11 01:52:39', '', 0, 'http://localhost:8888/muthetaatlarge.org/?post_type=event&#038;p=32', 0, 'event', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (33, 1, '2014-08-11 01:54:01', '2014-08-11 01:54:01', 'Business Agenda', 'Board of Directors and Committee Members', 'Business Agenda', 'publish', 'open', 'open', '', 'board-of-directors-and-committee-members-2', '', '', '2014-08-11 01:54:01', '2014-08-11 01:54:01', '', 0, 'http://localhost:8888/muthetaatlarge.org/?post_type=event&#038;p=33', 0, 'event', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (34, 1, '2014-08-11 21:52:38', '2014-08-11 21:52:38', '[eo_events] <h4><a href="%event_url%">%event_title%</a></h4> on %start{jS M Y}{ g:i:a}%, at %event_venue% [/eo_events]

    <?php if( dynamic_sidebar( \'home_upcoming_events\' )): ?>

    <?php else: ?>
      <h3>Upcoming Events</h3>
      <p>Install Event Organizer Plugin.</p>
    <?php endif; ?>', 'Calendar', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-08-11 21:52:38', '2014-08-11 21:52:38', '', 24, 'http://localhost:8888/muthetaatlarge.org/?p=34', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (35, 1, '2014-08-11 21:55:29', '2014-08-11 21:55:29', '
    <?php if( dynamic_sidebar( \'home_upcoming_events\' )): ?>

    <?php else: ?>
      <h3>Upcoming Events</h3>
      <p>Install Event Organizer Plugin.</p>
    <?php endif; ?>', 'Calendar', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-08-11 21:55:29', '2014-08-11 21:55:29', '', 24, 'http://localhost:8888/muthetaatlarge.org/?p=35', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (36, 1, '2014-08-11 22:01:44', '2014-08-11 22:01:44', '', 'Calendar', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-08-11 22:01:44', '2014-08-11 22:01:44', '', 24, 'http://localhost:8888/muthetaatlarge.org/?p=36', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (37, 1, '2014-08-12 00:04:08', '2014-08-12 00:04:08', '', 'Calendar', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-08-12 00:04:08', '2014-08-12 00:04:08', '', 24, 'http://localhost:8888/muthetaatlarge.org/?p=37', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (38, 1, '2014-08-12 00:04:25', '2014-08-12 00:04:25', '', 'Calendar', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-08-12 00:04:25', '2014-08-12 00:04:25', '', 24, 'http://localhost:8888/muthetaatlarge.org/?p=38', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (39, 1, '2014-08-12 00:46:34', '2014-08-12 00:46:34', '<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">History</h2>
				<div class="eight columns alpha">
				<p>In 1922, six students from the Indiana University Training School for Nurses in Indianapolis, Indiana founded the honor society of nursing. Read about the lives of these students and their faculty advisor, who recognized the value of scholarship and excellence in nursing practice. (more)</p>
				<p>
					Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.  In its pursuit of promoting nursing excellence, it helps prepare nurses to excel and function globally in all facets of nursing education, leadership, research, and scholarship.
				</p>
				</div>
				<div class="eight columns omega">
				<p>

					To that end, the Board of Directors, Committees, and Chapter members convene at alternating sites and rotate between the campuses of the schools that comprise its membership namely-St. Peter’s College (Englewood Cliffs), Felician College (Lodi), and College of St. Elizabeth (Morristown). General business meetings held regularly throughout the year provide opportunities to discuss, plan, and implement strategies for chapter-based programs or co-sponsored educational initiatives.  In order to meet the involving needs of our members as well as enhance the growth of the chapter, we encourage your active participation, and invite you to join us!
				</p>
				</div>
			</div>

<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">Chapter Mission Statement</h2>
				<div class="eight columns alpha">
				<p>Mu Theta Chapter at Large embraces the wider aims of Sigma Theta Tau International.  In doing so, the Chapter provides direction, fellowship, and financial support for nurses who seek community engagement, educational assistance, or intra-professional mentoring and who wish to acquire leadership skills for role expansion, peer recognition or career fulfillment.</p>
				</div>
				<div class="eight columns omega">
<h4>Chapter Objectives</h4>
				<p><ol><li>Promote high professional standards</li>
<li>Provide scholarships for members/nursing students</li>
<li>Develop strategies for member retention</li>
<li>Develop community outreach programs</li>
<li>Promote and develop educational and research programs</li>
<li>Establish collaborative and mutually beneficial alliances</li>
				</p>
				</div>
			</div>', 'About Us', '', 'publish', 'open', 'open', '', 'about-us', '', '', '2014-08-13 00:23:20', '2014-08-13 00:23:20', '', 0, 'http://localhost:8888/muthetaatlarge.org/?page_id=39', 0, 'page', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (40, 1, '2014-08-12 00:46:34', '2014-08-12 00:46:34', '<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">History</h2>
				<div class="eight columns alpha">
				<p>In 1922, six students from the Indiana University Training School for Nurses in Indianapolis, Indiana founded the honor society of nursing. Read about the lives of these students and their faculty advisor, who recognized the value of scholarship and excellence in nursing practice. (more)</p>
				<p>
					Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.  In its pursuit of promoting nursing excellence, it helps prepare nurses to excel and function globally in all facets of nursing education, leadership, research, and scholarship.
				</p>
				</div>
				<div class="eight columns omega">
				<p>

					To that end, the Board of Directors, Committees, and Chapter members convene at alternating sites and rotate between the campuses of the schools that comprise its membership namely-St. Peter’s College (Englewood Cliffs), Felician College (Lodi), and College of St. Elizabeth (Morristown). General business meetings held regularly throughout the year provide opportunities to discuss, plan, and implement strategies for chapter-based programs or co-sponsored educational initiatives.  In order to meet the involving needs of our members as well as enhance the growth of the chapter, we encourage your active participation, and invite you to join us!
				</p>
				</div>
			</div>', 'About Us', '', 'inherit', 'open', 'open', '', '39-revision-v1', '', '', '2014-08-12 00:46:34', '2014-08-12 00:46:34', '', 39, 'http://localhost:8888/muthetaatlarge.org/?p=40', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (41, 1, '2014-08-12 01:22:34', '2014-08-12 01:22:34', '<div class="sixteen clearfix">
<div class="eight columns alpha">
<h3>DONORS 2013:<h3> 
Gold 
Elaine M. Kopp 
Paula Lefever 
Silver 
Timothy Clyne 
Bronze 
Edlyn I. Arthur 
Naney Hie 
Barbara Weith Isenberg
</div>
<div class="eight colum">
<h3>Patron Project - Cover</h3>

<h3>Patron Project - Introduction</h3>

<h3>Patron Project - Levels of Patronage</h3>

<h3>Patron Project - Payment Procedure</h3>

<h3>Patron Project - Contact Information</h3>', 'Patron Project', '', 'inherit', 'open', 'open', '', '17-autosave-v1', '', '', '2014-08-12 01:22:34', '2014-08-12 01:22:34', '', 17, 'http://localhost:8888/muthetaatlarge.org/?p=41', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (42, 1, '2014-08-12 01:22:48', '2014-08-12 01:22:48', '<div class="sixteen clearfix">
<div class="eight columns alpha">
<h3>DONORS 2013:<h3> 
Gold 
Elaine M. Kopp 
Paula Lefever 
Silver 
Timothy Clyne 
Bronze 
Edlyn I. Arthur 
Naney Hie 
Barbara Weith Isenberg
</div>
<div class="eight columns omega">
<h3>Patron Project - Cover</h3>

<h3>Patron Project - Introduction</h3>

<h3>Patron Project - Levels of Patronage</h3>

<h3>Patron Project - Payment Procedure</h3>

<h3>Patron Project - Contact Information</h3>

</div>
</div>', 'Patron Project', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-08-12 01:22:48', '2014-08-12 01:22:48', '', 17, 'http://localhost:8888/muthetaatlarge.org/?p=42', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (43, 1, '2014-08-12 01:23:37', '2014-08-12 01:23:37', '<div class="sixteen clearfix">
<div class="eight columns alpha">
<h4>DONORS 2013:<h4> 
Gold 
Elaine M. Kopp 
Paula Lefever 
Silver 
Timothy Clyne 
Bronze 
Edlyn I. Arthur 
Naney Hie 
Barbara Weith Isenberg
</div>
<div class="eight columns omega">
<h4>Patron Project - Cover</h4>

<h4>Patron Project - Introduction</h4>

<h4>Patron Project - Levels of Patronage</h4>

<h4>Patron Project - Payment Procedure</h4>

<h4>Patron Project - Contact Information</h4>

</div>
</div>', 'Patron Project', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2014-08-12 01:23:37', '2014-08-12 01:23:37', '', 17, 'http://localhost:8888/muthetaatlarge.org/?p=43', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (44, 1, '2014-08-12 01:46:49', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-08-12 01:46:49', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/muthetaatlarge.org/?p=44', 0, 'post', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (45, 1, '2014-08-12 01:47:08', '2014-08-12 01:47:08', '<h3 style="text-align:center;">Sigma Theta Tau International</h3>

<h3 style="text-align:center;">Sigma Theta Tau International – Education Information</h3>

<h3 style="text-align:center;">Sigma Theta Tau- Volunteer Information</h3>

<h3 style="text-align:center;">The New Jersey Board of Nursing</h3>

<h3 style="text-align:center;">The New Jersey State Nurses Association</h3>

<h3 style="text-align:center;">NSNA Forum of Nurses in Advanced Practice</h3>

<h3 style="text-align:center;">The American Academy of Nurse Practitioners</h3>
<h3 style="text-align:center;">The American College of Nurse Practitioners</h3>

<h3 style="text-align:center;">The American Nurses Association</h3>

<h3 style="text-align:center;">The New Jersey Collaborating Center of Nursing</h3>

<h3 style="text-align:center;">Association of American College and Universities</h3>

<h3 style="text-align:center;">Sigma Theta Tau International - Bylaws</h3>', 'Links', '', 'publish', 'open', 'open', '', 'links', '', '', '2014-08-12 01:47:08', '2014-08-12 01:47:08', '', 0, 'http://localhost:8888/muthetaatlarge.org/?page_id=45', 0, 'page', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (46, 1, '2014-08-12 01:47:08', '2014-08-12 01:47:08', '<h3 style="text-align:center;">Sigma Theta Tau International</h3>

<h3 style="text-align:center;">Sigma Theta Tau International – Education Information</h3>

<h3 style="text-align:center;">Sigma Theta Tau- Volunteer Information</h3>

<h3 style="text-align:center;">The New Jersey Board of Nursing</h3>

<h3 style="text-align:center;">The New Jersey State Nurses Association</h3>

<h3 style="text-align:center;">NSNA Forum of Nurses in Advanced Practice</h3>

<h3 style="text-align:center;">The American Academy of Nurse Practitioners</h3>
<h3 style="text-align:center;">The American College of Nurse Practitioners</h3>

<h3 style="text-align:center;">The American Nurses Association</h3>

<h3 style="text-align:center;">The New Jersey Collaborating Center of Nursing</h3>

<h3 style="text-align:center;">Association of American College and Universities</h3>

<h3 style="text-align:center;">Sigma Theta Tau International - Bylaws</h3>', 'Links', '', 'inherit', 'open', 'open', '', '45-revision-v1', '', '', '2014-08-12 01:47:08', '2014-08-12 01:47:08', '', 45, 'http://localhost:8888/muthetaatlarge.org/?p=46', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (47, 1, '2014-08-12 01:49:27', '2014-08-12 01:49:27', '<h3>2013 Scholarship recipients:</h3>

<h4>Desna Allen - Felician College</h4>
<h4>Jennifer Aquilar - Saint peter\'s University</h4>
<h4>Arlinda Cosaj - Saint Peter\'s University</h4>', 'Award', '', 'publish', 'open', 'open', '', 'award', '', '', '2014-08-12 01:49:27', '2014-08-12 01:49:27', '', 0, 'http://localhost:8888/muthetaatlarge.org/?page_id=47', 0, 'page', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (48, 1, '2014-08-12 01:49:27', '2014-08-12 01:49:27', '<h3>2013 Scholarship recipients:</h3>

<h4>Desna Allen - Felician College</h4>
<h4>Jennifer Aquilar - Saint peter\'s University</h4>
<h4>Arlinda Cosaj - Saint Peter\'s University</h4>', 'Award', '', 'inherit', 'open', 'open', '', '47-revision-v1', '', '', '2014-08-12 01:49:27', '2014-08-12 01:49:27', '', 47, 'http://localhost:8888/muthetaatlarge.org/?p=48', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (49, 1, '2014-08-12 01:55:22', '2014-08-12 01:55:22', '<div class="sixteen clearfix">

<div class="eight columns alpha">
<h3>Officers</h3>
<ul class="square">
	<li>President</li>

	<li>President-Elect</li>
 
	<li>Vice President (SPC) </li>

	<li>Vice President (CSE)</li>
 
	<li>Vice President (FC)</li>
 
	<li>Recording Secretary</li>
 
	<li>Corresponding Secretary </li>

	<li>Treasurer </li>
	<li>Faculty Counselor (SPC)</li>
 
	<li>Faculty Counselor (CSE)</li>
 
	<li>Faculty Counselor (FC)</li>

	<li>Governance (chair)</li>

</ul>


</div>
<div class="eight columns omega">
<h3>Committees</h3>
<ul class="square">
	<li>Leadership Succession (SPC) </li>

	<li>Leadership Succession (CSE)</li>
 
	<li>Leadership Succession (FC)</li>
 
	<li>Fundraising Chair</li>
 
	<li>Scholarship/Research Chair</li>
 
	<li>Website Coordinator </li>

	<li>Newsletter Editor</li>
</ul>


</div>
</div>', 'Officers', '', 'publish', 'open', 'open', '', 'officers', '', '', '2014-08-12 01:56:07', '2014-08-12 01:56:07', '', 0, 'http://localhost:8888/muthetaatlarge.org/?page_id=49', 0, 'page', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (50, 1, '2014-08-12 01:55:22', '2014-08-12 01:55:22', '<div class="sixteen clearfix">

<div class="eight columns alpha">
<h3>Officers</h3>
<ul>
	<li>President</li>

	<li>President-Elect</li>
 
	<li>Vice President (SPC) </li>

	<li>Vice President (CSE)</li>
 
	<li>Vice President (FC)</li>
 
	<li>Recording Secretary</li>
 
	<li>Corresponding Secretary </li>

	<li>Treasurer </li>
	<li>Faculty Counselor (SPC)</li>
 
	<li>Faculty Counselor (CSE)</li>
 
	<li>Faculty Counselor (FC)</li>

	<li>Governance (chair)</li>

</ul>


</div>
<div class="eight columns omega">
<h3>Committees</h3>
<ul>
	<li>Leadership Succession (SPC) </li>

	<li>Leadership Succession (CSE)</li>
 
	<li>Leadership Succession (FC)</li>
 
	<li>Fundraising Chair</li>
 
	<li>Scholarship/Research Chair</li>
 
	<li>Website Coordinator </li>

	<li>Newsletter Editor</li>
</ul>


</div>
</div>', 'Officers', '', 'inherit', 'open', 'open', '', '49-revision-v1', '', '', '2014-08-12 01:55:22', '2014-08-12 01:55:22', '', 49, 'http://localhost:8888/muthetaatlarge.org/?p=50', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (51, 1, '2014-08-12 01:56:07', '2014-08-12 01:56:07', '<div class="sixteen clearfix">

<div class="eight columns alpha">
<h3>Officers</h3>
<ul class="square">
	<li>President</li>

	<li>President-Elect</li>
 
	<li>Vice President (SPC) </li>

	<li>Vice President (CSE)</li>
 
	<li>Vice President (FC)</li>
 
	<li>Recording Secretary</li>
 
	<li>Corresponding Secretary </li>

	<li>Treasurer </li>
	<li>Faculty Counselor (SPC)</li>
 
	<li>Faculty Counselor (CSE)</li>
 
	<li>Faculty Counselor (FC)</li>

	<li>Governance (chair)</li>

</ul>


</div>
<div class="eight columns omega">
<h3>Committees</h3>
<ul class="square">
	<li>Leadership Succession (SPC) </li>

	<li>Leadership Succession (CSE)</li>
 
	<li>Leadership Succession (FC)</li>
 
	<li>Fundraising Chair</li>
 
	<li>Scholarship/Research Chair</li>
 
	<li>Website Coordinator </li>

	<li>Newsletter Editor</li>
</ul>


</div>
</div>', 'Officers', '', 'inherit', 'open', 'open', '', '49-revision-v1', '', '', '2014-08-12 01:56:07', '2014-08-12 01:56:07', '', 49, 'http://localhost:8888/muthetaatlarge.org/?p=51', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (52, 1, '2014-08-12 01:57:28', '2014-08-12 01:57:28', 'Membership criteria
http://www.nursingsociety.org/membership/applyNow/Pages/mem_criteria.aspx                       

New Leader Membership criteria:      
http://www.nursingsociety.org/Membership/ApplyNow/Pages/nl_memcriteria.aspx

Member Benefits:
http://www.nursingsociety.org/Membership/Benefits/Pages/benefits.aspx

Member Get a Member Campaign:
http://www.nursingsociety.org/Membership/Campaigns/Pages/Member2Member.aspx

Newest members to Sigma Theta Tau International, Honor Society of Nurses, Mu Theta at Large Chapter Inducted April 27th, 2013.

New Members List 2013
New Members List Archives

New Members List 2011
Photos of Mu Theta at Large Chapter’s Events', 'Membership', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-08-12 01:57:28', '2014-08-12 01:57:28', '', 6, 'http://localhost:8888/muthetaatlarge.org/?p=52', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (53, 1, '2014-08-12 01:58:31', '2014-08-12 01:58:31', '<h3>Membership criteria</h3>
http://www.nursingsociety.org/membership/applyNow/Pages/mem_criteria.aspx                       

<h3>New Leader Membership criteria: </h3>     
http://www.nursingsociety.org/Membership/ApplyNow/Pages/nl_memcriteria.aspx

<h3>Member Benefits:</h3>
http://www.nursingsociety.org/Membership/Benefits/Pages/benefits.aspx

<h3>Member Get a Member Campaign:</h3>
http://www.nursingsociety.org/Membership/Campaigns/Pages/Member2Member.aspx

<p>Newest members to Sigma Theta Tau International, Honor Society of Nurses, Mu Theta at Large Chapter Inducted April 27th, 2013.</p>

New Members List 2013
New Members List Archives

New Members List 2011
Photos of Mu Theta at Large Chapter’s Events', 'Membership', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2014-08-12 01:58:31', '2014-08-12 01:58:31', '', 6, 'http://localhost:8888/muthetaatlarge.org/?p=53', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (54, 1, '2014-08-13 00:00:28', '2014-08-13 00:00:28', '<div class="sixteen clearfix">
<div class="eight columns alpha">
[contact]
</div>
<div class="eight columns omega">
<ul class="square">
<li>
For information and questions regarding the Chapter contact:
Sara Thompson at thompsons@felician.edu
</li>
<li>
 For suggestions and questions regarding the website, contact:
Beverley Wright at bhwright15@optonline.net
</li>
<li>For our Newsletter, contact 
Elaine M. Kopp at koppelaine@yahoo.com
</li>

<strong>Send us announcements, articles, stories, photos and reports you would like to share with other members.</strong>
</div>
</div>', 'Contact Us', '', 'publish', 'open', 'open', '', 'contact-us', '', '', '2014-08-13 00:07:25', '2014-08-13 00:07:25', '', 0, 'http://localhost:8888/muthetaatlarge.org/?page_id=54', 0, 'page', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (55, 1, '2014-08-13 00:00:28', '2014-08-13 00:00:28', '[contact]', 'Contact Us', '', 'inherit', 'open', 'open', '', '54-revision-v1', '', '', '2014-08-13 00:00:28', '2014-08-13 00:00:28', '', 54, 'http://localhost:8888/muthetaatlarge.org/?p=55', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (56, 1, '2014-08-13 00:03:19', '2014-08-13 00:03:19', '<div style="margin:0 auto;">[contact]</div>', 'Contact Us', '', 'inherit', 'open', 'open', '', '54-revision-v1', '', '', '2014-08-13 00:03:19', '2014-08-13 00:03:19', '', 54, 'http://localhost:8888/muthetaatlarge.org/?p=56', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (57, 1, '2014-08-13 00:03:39', '2014-08-13 00:03:39', '[contact]', 'Contact Us', '', 'inherit', 'open', 'open', '', '54-revision-v1', '', '', '2014-08-13 00:03:39', '2014-08-13 00:03:39', '', 54, 'http://localhost:8888/muthetaatlarge.org/?p=57', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (58, 1, '2014-08-13 00:05:40', '2014-08-13 00:05:40', '<div class="sixt">[contact]', 'Contact Us', '', 'inherit', 'open', 'open', '', '54-autosave-v1', '', '', '2014-08-13 00:05:40', '2014-08-13 00:05:40', '', 54, 'http://localhost:8888/muthetaatlarge.org/?p=58', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (59, 1, '2014-08-13 00:07:25', '2014-08-13 00:07:25', '<div class="sixteen clearfix">
<div class="eight columns alpha">
[contact]
</div>
<div class="eight columns omega">
<ul class="square">
<li>
For information and questions regarding the Chapter contact:
Sara Thompson at thompsons@felician.edu
</li>
<li>
 For suggestions and questions regarding the website, contact:
Beverley Wright at bhwright15@optonline.net
</li>
<li>For our Newsletter, contact 
Elaine M. Kopp at koppelaine@yahoo.com
</li>

<strong>Send us announcements, articles, stories, photos and reports you would like to share with other members.</strong>
</div>
</div>', 'Contact Us', '', 'inherit', 'open', 'open', '', '54-revision-v1', '', '', '2014-08-13 00:07:25', '2014-08-13 00:07:25', '', 54, 'http://localhost:8888/muthetaatlarge.org/?p=59', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (60, 1, '2014-08-13 00:23:15', '2014-08-13 00:23:15', '<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">History</h2>
				<div class="eight columns alpha">
				<p>In 1922, six students from the Indiana University Training School for Nurses in Indianapolis, Indiana founded the honor society of nursing. Read about the lives of these students and their faculty advisor, who recognized the value of scholarship and excellence in nursing practice. (more)</p>
				<p>
					Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.  In its pursuit of promoting nursing excellence, it helps prepare nurses to excel and function globally in all facets of nursing education, leadership, research, and scholarship.
				</p>
				</div>
				<div class="eight columns omega">
				<p>

					To that end, the Board of Directors, Committees, and Chapter members convene at alternating sites and rotate between the campuses of the schools that comprise its membership namely-St. Peter’s College (Englewood Cliffs), Felician College (Lodi), and College of St. Elizabeth (Morristown). General business meetings held regularly throughout the year provide opportunities to discuss, plan, and implement strategies for chapter-based programs or co-sponsored educational initiatives.  In order to meet the involving needs of our members as well as enhance the growth of the chapter, we encourage your active participation, and invite you to join us!
				</p>
				</div>
			</div>

<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">Chapter Mission Statement</h2>
				<div class="eight columns alpha">
				<p>Mu Theta Chapter at Large embraces the wider aims of Sigma Theta Tau International.  In doing so, the Chapter provides direction, fellowship, and financial support for nurses who seek community engagement, educational assistance, or intra-professional mentoring and who wish to acquire leadership skills for role expansion, peer recognition or career fulfillment.</p>
				</div>
				<div class="eight columns omega">
<h2 style="text-align:left; margin-bottom: 20px; ">Chapter Objectives</h2>
				<p><ol><li>Promote high professional standards</li>
<li>Provide scholarships for members/nursing students</li>
<li>Develop strategies for member retention</li>
<li>Develop community outreach programs</li>
<li>Promote and develop educational and research programs</li>
<li>Establish collaborative and mutually beneficial alliances</li>
				</p>
				</div>
			</div>', 'About Us', '', 'inherit', 'open', 'open', '', '39-autosave-v1', '', '', '2014-08-13 00:23:15', '2014-08-13 00:23:15', '', 39, 'http://localhost:8888/muthetaatlarge.org/?p=60', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (61, 1, '2014-08-13 00:21:52', '2014-08-13 00:21:52', '<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">History</h2>
				<div class="eight columns alpha">
				<p>In 1922, six students from the Indiana University Training School for Nurses in Indianapolis, Indiana founded the honor society of nursing. Read about the lives of these students and their faculty advisor, who recognized the value of scholarship and excellence in nursing practice. (more)</p>
				<p>
					Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.  In its pursuit of promoting nursing excellence, it helps prepare nurses to excel and function globally in all facets of nursing education, leadership, research, and scholarship.
				</p>
				</div>
				<div class="eight columns omega">
				<p>

					To that end, the Board of Directors, Committees, and Chapter members convene at alternating sites and rotate between the campuses of the schools that comprise its membership namely-St. Peter’s College (Englewood Cliffs), Felician College (Lodi), and College of St. Elizabeth (Morristown). General business meetings held regularly throughout the year provide opportunities to discuss, plan, and implement strategies for chapter-based programs or co-sponsored educational initiatives.  In order to meet the involving needs of our members as well as enhance the growth of the chapter, we encourage your active participation, and invite you to join us!
				</p>
				</div>
			</div>

<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">Chapter Mission Statement</h2>
				<div class="eight columns alpha">
				<p>Mu Theta Chapter at Large embraces the wider
aims of Sigma Theta Tau International.  In doing
so, the Chapter provides direction, fellowship,
and financial support for nurses who seek community engagement, educational assistance,
or intra-professional mentoring and who wish
to acquire leadership skills for role expansion, 
peer recognition or career fulfillment.</p>
				</div>
				<div class="eight columns omega">
<h2 style="text-align:left; margin-bottom: 20px; ">Chapter Objectives</h2>
				<p><ol><li>Promote high professional standards</li>
<li>Provide scholarships for members/nursing students</li>
<li>Develop strategies for member retention</li>
<li>Develop community outreach programs</li>
<li>Promote and develop educational and research programs</li>
<li>Establish collaborative and mutually beneficial alliances</li>
				</p>
				</div>
			</div>', 'About Us', '', 'inherit', 'open', 'open', '', '39-revision-v1', '', '', '2014-08-13 00:21:52', '2014-08-13 00:21:52', '', 39, 'http://localhost:8888/muthetaatlarge.org/?p=61', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (62, 1, '2014-08-13 00:23:20', '2014-08-13 00:23:20', '<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">History</h2>
				<div class="eight columns alpha">
				<p>In 1922, six students from the Indiana University Training School for Nurses in Indianapolis, Indiana founded the honor society of nursing. Read about the lives of these students and their faculty advisor, who recognized the value of scholarship and excellence in nursing practice. (more)</p>
				<p>
					Mu Theta Chapter At Large is one of 28 chapters in region 14 of Sigma Theta Tau International, The Nurses Honor Society.  As a constituent, Mu Theta is committed to support, sustain, and carry forward the ideas of the international organization.  In its pursuit of promoting nursing excellence, it helps prepare nurses to excel and function globally in all facets of nursing education, leadership, research, and scholarship.
				</p>
				</div>
				<div class="eight columns omega">
				<p>

					To that end, the Board of Directors, Committees, and Chapter members convene at alternating sites and rotate between the campuses of the schools that comprise its membership namely-St. Peter’s College (Englewood Cliffs), Felician College (Lodi), and College of St. Elizabeth (Morristown). General business meetings held regularly throughout the year provide opportunities to discuss, plan, and implement strategies for chapter-based programs or co-sponsored educational initiatives.  In order to meet the involving needs of our members as well as enhance the growth of the chapter, we encourage your active participation, and invite you to join us!
				</p>
				</div>
			</div>

<div class="sixteen clearfix">
				
				<h2 style="text-align:left; margin-bottom: 20px; ">Chapter Mission Statement</h2>
				<div class="eight columns alpha">
				<p>Mu Theta Chapter at Large embraces the wider aims of Sigma Theta Tau International.  In doing so, the Chapter provides direction, fellowship, and financial support for nurses who seek community engagement, educational assistance, or intra-professional mentoring and who wish to acquire leadership skills for role expansion, peer recognition or career fulfillment.</p>
				</div>
				<div class="eight columns omega">
<h4>Chapter Objectives</h4>
				<p><ol><li>Promote high professional standards</li>
<li>Provide scholarships for members/nursing students</li>
<li>Develop strategies for member retention</li>
<li>Develop community outreach programs</li>
<li>Promote and develop educational and research programs</li>
<li>Establish collaborative and mutually beneficial alliances</li>
				</p>
				</div>
			</div>', 'About Us', '', 'inherit', 'open', 'open', '', '39-revision-v1', '', '', '2014-08-13 00:23:20', '2014-08-13 00:23:20', '', 39, 'http://localhost:8888/muthetaatlarge.org/?p=62', 0, 'revision', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (63, 1, '2014-08-13 00:24:19', '2014-08-13 00:24:19', '', 'Officers', '', 'trash', 'open', 'open', '', 'officers-2', '', '', '2014-08-13 00:24:30', '2014-08-13 00:24:30', '', 0, 'http://localhost:8888/muthetaatlarge.org/?page_id=63', 0, 'page', '', 0) ; 
INSERT INTO `wpMTAL_posts` VALUES (64, 1, '2014-08-13 00:24:19', '2014-08-13 00:24:19', '', 'Officers', '', 'inherit', 'open', 'open', '', '63-revision-v1', '', '', '2014-08-13 00:24:19', '2014-08-13 00:24:19', '', 63, 'http://localhost:8888/muthetaatlarge.org/?p=64', 0, 'revision', '', 0) ;
#
# End of data contents of table wpMTAL_posts
# --------------------------------------------------------

# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_events`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_venuemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_term_relationships`
#

DROP TABLE IF EXISTS `wpMTAL_term_relationships`;


#
# Table structure of table `wpMTAL_term_relationships`
#

CREATE TABLE `wpMTAL_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_term_relationships (5 records)
#
 
INSERT INTO `wpMTAL_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wpMTAL_term_relationships` VALUES (27, 2, 0) ; 
INSERT INTO `wpMTAL_term_relationships` VALUES (28, 3, 0) ; 
INSERT INTO `wpMTAL_term_relationships` VALUES (32, 4, 0) ; 
INSERT INTO `wpMTAL_term_relationships` VALUES (33, 2, 0) ;
#
# End of data contents of table wpMTAL_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_events`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_venuemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_term_taxonomy`
#

DROP TABLE IF EXISTS `wpMTAL_term_taxonomy`;


#
# Table structure of table `wpMTAL_term_taxonomy`
#

CREATE TABLE `wpMTAL_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_term_taxonomy (4 records)
#
 
INSERT INTO `wpMTAL_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1) ; 
INSERT INTO `wpMTAL_term_taxonomy` VALUES (2, 2, 'event-venue', '', 0, 2) ; 
INSERT INTO `wpMTAL_term_taxonomy` VALUES (3, 3, 'event-venue', '', 0, 1) ; 
INSERT INTO `wpMTAL_term_taxonomy` VALUES (4, 4, 'event-venue', '', 0, 1) ;
#
# End of data contents of table wpMTAL_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_events`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_venuemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_terms`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_terms`
#

DROP TABLE IF EXISTS `wpMTAL_terms`;


#
# Table structure of table `wpMTAL_terms`
#

CREATE TABLE `wpMTAL_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_terms (4 records)
#
 
INSERT INTO `wpMTAL_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wpMTAL_terms` VALUES (2, 'Go to Meeting - Online Meeting Forum', 'go-to-meeting-online-meeting-forum', 0) ; 
INSERT INTO `wpMTAL_terms` VALUES (3, 'College of Saint Elizabeth', 'college-of-saint-elizabeth', 0) ; 
INSERT INTO `wpMTAL_terms` VALUES (4, 'Liberty House Restaurant', 'liberty-house-restaurant', 0) ;
#
# End of data contents of table wpMTAL_terms
# --------------------------------------------------------

# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_events`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_venuemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_usermeta`
#

DROP TABLE IF EXISTS `wpMTAL_usermeta`;


#
# Table structure of table `wpMTAL_usermeta`
#

CREATE TABLE `wpMTAL_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_usermeta (16 records)
#
 
INSERT INTO `wpMTAL_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (3, 1, 'nickname', 'lzhu01') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (10, 1, 'wpMTAL_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (11, 1, 'wpMTAL_user_level', '10') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (14, 1, 'wpMTAL_dashboard_quick_press_last_post_id', '3') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (15, 1, 'wpMTAL_user-settings', 'editor=html') ; 
INSERT INTO `wpMTAL_usermeta` VALUES (16, 1, 'wpMTAL_user-settings-time', '1407686885') ;
#
# End of data contents of table wpMTAL_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/muthetaatlarge.org MySQL database backup
#
# Generated: Saturday 16. August 2014 12:16 UTC
# Hostname: localhost
# Database: `wp_muthetaatlarge`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_events`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_eo_venuemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wpMTAL_users`
# --------------------------------------------------------


#
# Delete any existing table `wpMTAL_users`
#

DROP TABLE IF EXISTS `wpMTAL_users`;


#
# Table structure of table `wpMTAL_users`
#

CREATE TABLE `wpMTAL_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wpMTAL_users (1 records)
#
 
INSERT INTO `wpMTAL_users` VALUES (1, 'lzhu01', '$P$BeTmo1YM.MylG5NlatAexlPh..6Vt8.', 'lzhu01', 'sportzhulei@gmail.com', '', '2014-08-10 15:17:52', '', 0, 'lzhu01') ;
#
# End of data contents of table wpMTAL_users
# --------------------------------------------------------

